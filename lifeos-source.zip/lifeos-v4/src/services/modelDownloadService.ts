import * as FileSystem from "expo-file-system/legacy";

const MODEL_DIR          = `${FileSystem.documentDirectory}models/`;
export const ASSISTANT_MODEL_URI = `${MODEL_DIR}assistant.gguf`;
const BUNDLED_ASSET      = `${FileSystem.bundleDirectory ?? "asset:///"}models/assistant.gguf`;

export interface ModelOption {
  id:      string;
  name:    string;
  tagline: string;
  sizeMB:  number;
  tier:    "fast" | "balanced" | "smart" | "best";
  url:     string;
}

export const MODEL_OPTIONS: ModelOption[] = [
  {
    id:      "smollm2-135m",
    name:    "SmolLM2 135M",
    tagline: "Fastest — instant replies, lowest battery use",
    sizeMB:  105,
    tier:    "fast",
    url:     "https://huggingface.co/HuggingFaceTB/SmolLM2-135M-Instruct-GGUF/resolve/main/smollm2-135m-instruct-q4_k_m.gguf",
  },
  {
    id:      "smollm2-360m",
    name:    "SmolLM2 360M",
    tagline: "Balanced — noticeably smarter, still very fast",
    sizeMB:  230,
    tier:    "balanced",
    url:     "https://huggingface.co/HuggingFaceTB/SmolLM2-360M-Instruct-GGUF/resolve/main/smollm2-360m-instruct-q4_k_m.gguf",
  },
  {
    id:      "qwen2.5-0.5b",
    name:    "Qwen 2.5 0.5B",
    tagline: "Smart — strong reasoning, good for planning and advice",
    sizeMB:  400,
    tier:    "smart",
    url:     "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/qwen2.5-0.5b-instruct-q4_k_m.gguf",
  },
  {
    id:      "llama3.2-1b",
    name:    "Llama 3.2 1B",
    tagline: "Best overall — deep reasoning, long conversations",
    sizeMB:  700,
    tier:    "best",
    url:     "https://huggingface.co/bartowski/Llama-3.2-1B-Instruct-GGUF/resolve/main/Llama-3.2-1B-Instruct-Q4_K_M.gguf",
  },
];

/** Returns true if a valid model (>1 MB) already lives at ASSISTANT_MODEL_URI. */
export async function hasAssistantModel(): Promise<boolean> {
  try {
    const info = await FileSystem.getInfoAsync(ASSISTANT_MODEL_URI);
    return Boolean(
      info.exists &&
      (info as { size?: number }).size &&
      (info as { size: number }).size > 1_000_000,
    );
  } catch {
    return false;
  }
}

/**
 * Copy the model that was bundled inside the APK to the writable models dir.
 *
 * FIX: We check whether a valid model is already installed first.
 * Without this check, every cold start would re-copy the bundled model on top
 * of any model the user chose to download — causing the onboarding screen to
 * appear on every launch.
 */
export async function extractBundledModel(): Promise<boolean> {
  try {
    // ← KEY FIX: never overwrite an existing model the user may have chosen
    const alreadyInstalled = await hasAssistantModel();
    if (alreadyInstalled) return true;

    const bundledInfo = await FileSystem.getInfoAsync(BUNDLED_ASSET);
    if (!bundledInfo.exists) return false;

    await FileSystem.makeDirectoryAsync(MODEL_DIR, { intermediates: true });
    await FileSystem.copyAsync({ from: BUNDLED_ASSET, to: ASSISTANT_MODEL_URI });
    return await hasAssistantModel();
  } catch {
    return false;
  }
}

/**
 * Download a model from HuggingFace with live progress reporting.
 * Writes to a temp file first so a failed download never leaves a corrupt
 * partial file at ASSISTANT_MODEL_URI.
 */
export async function downloadModel(
  url:        string,
  onProgress: (pct: number) => void,
): Promise<void> {
  await FileSystem.makeDirectoryAsync(MODEL_DIR, { intermediates: true });
  const tmp = `${MODEL_DIR}downloading.tmp`;

  const prev = await FileSystem.getInfoAsync(tmp);
  if (prev.exists) await FileSystem.deleteAsync(tmp, { idempotent: true });

  const dl = FileSystem.createDownloadResumable(url, tmp, {}, (prog) => {
    if (prog.totalBytesExpectedToWrite > 0) {
      onProgress(
        Math.round((prog.totalBytesWritten / prog.totalBytesExpectedToWrite) * 100),
      );
    }
  });

  const result = await dl.downloadAsync();
  if (!result?.uri) throw new Error("Download returned no URI. Check internet connection.");

  const existing = await FileSystem.getInfoAsync(ASSISTANT_MODEL_URI);
  if (existing.exists) await FileSystem.deleteAsync(ASSISTANT_MODEL_URI, { idempotent: true });

  await FileSystem.moveAsync({ from: tmp, to: ASSISTANT_MODEL_URI });
}

export async function removeModel(): Promise<void> {
  const info = await FileSystem.getInfoAsync(ASSISTANT_MODEL_URI);
  if (info.exists) await FileSystem.deleteAsync(ASSISTANT_MODEL_URI, { idempotent: true });
}
