import * as Notifications from "expo-notifications";
import { Platform } from "react-native";
import type { PlanItem } from "../types";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

const REMINDER_CHANNEL_ID = "lifeos-reminders";
const ALARM_CHANNEL_ID = "lifeos-alarms";

export async function configureNotifications(): Promise<boolean> {
  if (Platform.OS === "android") {
    await Notifications.setNotificationChannelAsync(REMINDER_CHANNEL_ID, {
      name: "LifeOS Reminders",
      importance: Notifications.AndroidImportance.DEFAULT,
      vibrationPattern: [0, 250, 250, 250],
      lightColor: "#66E3FF",
    });
    await Notifications.setNotificationChannelAsync(ALARM_CHANNEL_ID, {
      name: "LifeOS Alarms",
      importance: Notifications.AndroidImportance.MAX,
      vibrationPattern: [0, 500, 250, 500, 250, 500],
      lightColor: "#FF6B35",
      enableLights: true,
      enableVibrate: true,
      sound: "default",
      bypassDnd: true,
    });
  }
  const existing = await Notifications.getPermissionsAsync();
  if (existing.granted) return true;
  const requested = await Notifications.requestPermissionsAsync();
  return requested.granted;
}

async function scheduleDateNotification(
  title: string,
  body: string,
  date: Date,
  channelId = REMINDER_CHANNEL_ID,
  sound = false,
): Promise<string | null> {
  if (date.getTime() <= Date.now()) return null;
  const granted = await configureNotifications();
  if (!granted) return null;
  return Notifications.scheduleNotificationAsync({
    content: {
      title,
      body,
      sound: sound ? "default" : undefined,
      priority: sound
        ? Notifications.AndroidNotificationPriority.MAX
        : Notifications.AndroidNotificationPriority.DEFAULT,
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.DATE,
      date,
      channelId,
    },
  });
}

/** Schedule a real alarm notification — fires at the given hour:minute today (or tomorrow if past). */
export async function scheduleAlarm(
  hour: number,
  minute: number,
  label = "Alarm",
): Promise<{ id: string | null; firesAt: Date }> {
  await configureNotifications();
  const now = new Date();
  const alarm = new Date(now);
  alarm.setHours(hour, minute, 0, 0);
  // If time is in the past, schedule for tomorrow
  if (alarm.getTime() <= now.getTime()) {
    alarm.setDate(alarm.getDate() + 1);
  }
  const hh = String(hour).padStart(2, "0");
  const mm = String(minute).padStart(2, "0");
  const id = await scheduleDateNotification(
    `⏰ ${label}`,
    `Alarm set for ${hh}:${mm} — ${label}`,
    alarm,
    ALARM_CHANNEL_ID,
    true,
  );
  return { id, firesAt: alarm };
}

/** Schedule a reminder N minutes from now. */
export async function scheduleReminderIn(
  minutes: number,
  label = "Reminder",
): Promise<{ id: string | null; firesAt: Date }> {
  await configureNotifications();
  const firesAt = new Date(Date.now() + minutes * 60 * 1000);
  const id = await scheduleDateNotification(
    `🔔 ${label}`,
    label,
    firesAt,
    ALARM_CHANNEL_ID,
    true,
  );
  return { id, firesAt };
}

export async function scheduleFocusNudge(minutesFromNow = 25): Promise<string | null> {
  const granted = await configureNotifications();
  if (!granted) return null;
  const trigger = new Date(Date.now() + minutesFromNow * 60 * 1000);
  return Notifications.scheduleNotificationAsync({
    content: {
      title: "Focus check-in",
      body: "Log what happened and choose the next best action.",
      sound: undefined,
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.DATE,
      date: trigger,
      channelId: REMINDER_CHANNEL_ID,
    },
  });
}

export async function schedulePlanStartReminders(items: PlanItem[]): Promise<number> {
  let count = 0;
  for (const item of items) {
    if (!item.startAt || item.status !== "planned") continue;
    const date = new Date(item.startAt);
    const id = await scheduleDateNotification(
      "Time to prove the plan",
      `You said "${item.title}" starts now. Are you doing it?`,
      date,
      REMINDER_CHANNEL_ID,
    );
    if (id) count += 1;
  }
  return count;
}

export async function scheduleDailyAccountabilityNudges(items: PlanItem[]): Promise<number> {
  await cancelAllNudges();
  let count = await schedulePlanStartReminders(items);
  const now = new Date();
  const checkInHours = [10, 13, 16, 19];
  for (const hour of checkInHours) {
    const checkIn = new Date(now);
    checkIn.setHours(hour, 0, 0, 0);
    const id = await scheduleDateNotification(
      "Accountability check-in",
      "What are you doing right now, and is it what you planned?",
      checkIn,
    );
    if (id) count += 1;
  }
  const review = new Date(now);
  review.setHours(21, 0, 0, 0);
  const reviewId = await scheduleDateNotification(
    "End-of-day review",
    "What did you finish, what slipped, and what is tomorrow's first move?",
    review,
  );
  if (reviewId) count += 1;
  return count;
}

export async function cancelAllNudges(): Promise<void> {
  await Notifications.cancelAllScheduledNotificationsAsync();
}
