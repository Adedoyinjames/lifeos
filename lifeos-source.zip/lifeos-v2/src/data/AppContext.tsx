import AsyncStorage from "@react-native-async-storage/async-storage";
import { useRouter } from "expo-router";
import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { Alert } from "react-native";
import { initializeDatabase, resetDatabase } from "../db/client";
import { getPreference, setPreference } from "../db/repository";
import { hasAssistantModel, extractBundledModel } from "../services/modelDownloadService";
import { configureNotifications } from "../services/notificationService";
import {
  startBackgroundAssistant,
  stopBackgroundAssistant,
  nativeBridgeAvailable,
} from "../services/backgroundAssistant";

interface AppContextValue {
  ready: boolean;
  darkMode: boolean;
  privacyLock: boolean;
  backgroundActive: boolean;
  setDarkMode: (v: boolean) => Promise<void>;
  setPrivacyLock: (v: boolean) => Promise<void>;
  setBackgroundActive: (v: boolean) => Promise<void>;
  resetAllData: () => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [ready, setReady] = useState(false);
  const [darkMode, setDarkModeState] = useState(true);
  const [privacyLock, setPrivacyLockState] = useState(false);
  const [backgroundActive, setBackgroundActiveState] = useState(false);
  const router = useRouter();

  useEffect(() => {
    let mounted = true;
    async function startup() {
      // 1. Database
      await initializeDatabase();

      // 2. Preferences
      const [theme, lock, bgPref, hotword] = await Promise.all([
        getPreference("darkMode", "true"),
        getPreference("privacyLock", "false"),
        getPreference("backgroundAssistant", "true"),
        getPreference("hotword", "james"),
      ]);
      if (!mounted) return;
      setDarkModeState(theme !== "false");
      setPrivacyLockState(lock === "true");

      // 3. Notification channels
      await configureNotifications().catch(() => {});

      // 4. Model — try bundled asset first, then check disk
      const bundleOk = await extractBundledModel().catch(() => false);
      const modelReady = bundleOk || (await hasAssistantModel().catch(() => false));

      if (!mounted) return;

      // 5. Route to onboarding if no model
      if (!modelReady) {
        setReady(true);
        router.replace("/onboarding");
        return;
      }

      // 6. Start background assistant if enabled
      if (bgPref !== "false" && nativeBridgeAvailable()) {
        setBackgroundActiveState(true);
        startBackgroundAssistant(hotword).catch(() => {});
      }
    }

    startup()
      .catch((err) =>
        Alert.alert("LifeOS could not start", err instanceof Error ? err.message : String(err)),
      )
      .finally(() => mounted && setReady(true));

    return () => { mounted = false; };
  }, []);

  const setDarkMode = useCallback(async (v: boolean) => {
    setDarkModeState(v);
    await setPreference("darkMode", String(v));
  }, []);

  const setPrivacyLock = useCallback(async (v: boolean) => {
    setPrivacyLockState(v);
    await setPreference("privacyLock", String(v));
  }, []);

  const setBackgroundActive = useCallback(
    async (v: boolean) => {
      setBackgroundActiveState(v);
      await setPreference("backgroundAssistant", String(v));
      const hotword = await getPreference("hotword", "james");
      if (v) {
        await startBackgroundAssistant(hotword).catch(() => {});
      } else {
        await stopBackgroundAssistant().catch(() => {});
      }
    },
    [],
  );

  const resetAllData = useCallback(async () => {
    await resetDatabase();
    const keys = await AsyncStorage.getAllKeys();
    await AsyncStorage.multiRemove(keys.filter((k) => k.startsWith("lifeos:")));
    router.replace("/");
  }, [router]);

  const value = useMemo(
    () => ({
      ready,
      darkMode,
      privacyLock,
      backgroundActive,
      setDarkMode,
      setPrivacyLock,
      setBackgroundActive,
      resetAllData,
    }),
    [ready, darkMode, privacyLock, backgroundActive, setDarkMode, setPrivacyLock, setBackgroundActive, resetAllData],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useAppContext(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useAppContext must be inside AppProvider");
  return ctx;
}
