/**
 * Background assistant bridge.
 * Connects the native Android foreground service (AssistantForegroundService)
 * to the JS assistant engine.  All processing happens here so the native layer
 * only handles audio I/O; the full brain runs in JS.
 */
import { NativeEventEmitter, NativeModules, Platform } from "react-native";
import { runAssistantCommand } from "../ai/assistantEngine";
import { getPreference } from "../db/repository";

const Bridge = NativeModules.AssistantBridge as {
  startService: (hotword: string) => Promise<boolean>;
  stopService: () => Promise<boolean>;
  setHotword: (hotword: string) => Promise<boolean>;
  speakBackground: (text: string) => Promise<boolean>;
} | null;

let emitter: NativeEventEmitter | null = null;
let commandSub: { remove(): void } | null = null;
let hotwordSub: { remove(): void } | null = null;
let currentHotword = "james";

export function nativeBridgeAvailable(): boolean {
  return Platform.OS === "android" && Bridge !== null;
}

/**
 * Start the always-on background assistant.
 * Safe to call multiple times — idempotent.
 */
export async function startBackgroundAssistant(hotword: string): Promise<void> {
  if (!nativeBridgeAvailable()) return;

  currentHotword = hotword;

  // Wire up event subscriptions exactly once
  if (!emitter) {
    emitter = new NativeEventEmitter(NativeModules.AssistantBridge);
  }
  commandSub?.remove();
  hotwordSub?.remove();

  hotwordSub = emitter.addListener("onHotwordDetected", () => {
    // The native service already says "Yes?" — nothing extra needed here.
  });

  commandSub = emitter.addListener("onBackgroundCommand", async ({ command }: { command: string }) => {
    try {
      const result = await runAssistantCommand(command, currentHotword);
      if (result.spokenText) {
        await Bridge!.speakBackground(result.spokenText);
      }
    } catch {
      await Bridge!.speakBackground("Sorry, I could not process that.").catch(() => {});
    }
  });

  await Bridge!.startService(hotword);
}

export async function stopBackgroundAssistant(): Promise<void> {
  if (!nativeBridgeAvailable()) return;
  commandSub?.remove(); commandSub = null;
  hotwordSub?.remove(); hotwordSub = null;
  await Bridge!.stopService();
}

export async function updateBackgroundHotword(hotword: string): Promise<void> {
  if (!nativeBridgeAvailable()) return;
  currentHotword = hotword;
  await Bridge!.setHotword(hotword);
}

/** Speak text via the background service TTS — works even with screen off. */
export async function speakBackground(text: string): Promise<void> {
  if (!nativeBridgeAvailable()) return;
  await Bridge!.speakBackground(text);
}
