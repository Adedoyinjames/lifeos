package PACKAGE_PLACEHOLDER

import android.content.Intent
import android.os.Build
import android.util.Log
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.WritableMap
import com.facebook.react.modules.core.DeviceEventManagerModule

class AssistantBridgeModule(reactContext: ReactApplicationContext)
    : ReactContextBaseJavaModule(reactContext) {

    companion object { const val NAME = "AssistantBridge" }
    override fun getName() = NAME

    init {
        AssistantForegroundService.onCommandReceived = { command ->
            emit("onBackgroundCommand", Arguments.createMap().apply { putString("command", command) })
        }
        AssistantForegroundService.onHotwordDetected = { hw ->
            emit("onHotwordDetected", Arguments.createMap().apply { putString("hotword", hw) })
        }
    }

    @ReactMethod
    fun startService(hotword: String, promise: Promise) {
        try {
            AssistantForegroundService.startInContext(reactApplicationContext, hotword)
            promise.resolve(true)
        } catch (e: Exception) { promise.reject("ERR_START", e.message) }
    }

    @ReactMethod
    fun stopService(promise: Promise) {
        try {
            AssistantForegroundService.stopInContext(reactApplicationContext)
            promise.resolve(true)
        } catch (e: Exception) { promise.reject("ERR_STOP", e.message) }
    }

    @ReactMethod
    fun setHotword(hotword: String, promise: Promise) {
        try {
            AssistantForegroundService.hotword = hotword
            val intent = Intent(reactApplicationContext, AssistantForegroundService::class.java)
                .setAction(AssistantForegroundService.ACTION_UPDATE_HOTWORD)
                .putExtra(AssistantForegroundService.EXTRA_HOTWORD, hotword)
            reactApplicationContext.startService(intent)
            promise.resolve(true)
        } catch (e: Exception) { promise.reject("ERR_HOTWORD", e.message) }
    }

    @ReactMethod
    fun speakBackground(text: String, promise: Promise) {
        try {
            val intent = Intent(reactApplicationContext, AssistantForegroundService::class.java)
                .setAction(AssistantForegroundService.ACTION_SPEAK)
                .putExtra(AssistantForegroundService.EXTRA_TEXT, text)
            reactApplicationContext.startService(intent)
            promise.resolve(true)
        } catch (e: Exception) { promise.reject("ERR_TTS", e.message) }
    }

    @ReactMethod fun addListener(eventName: String) {}
    @ReactMethod fun removeListeners(count: Int) {}

    private fun emit(event: String, params: WritableMap) {
        try {
            reactApplicationContext
                .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                .emit(event, params)
        } catch (e: Exception) { Log.e("AssistantBridge", "emit failed: ${e.message}") }
    }
}
