package PACKAGE_PLACEHOLDER

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Receives BOOT_COMPLETED and restarts the always-on assistant service so
 * hotword listening survives a device reboot without the user needing to
 * open the app.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == "android.intent.action.QUICKBOOT_POWERON" ||
            action == "com.htc.intent.action.QUICKBOOT_POWERON") {
            Log.d("LifeOS/Boot", "Boot completed — starting assistant service")
            AssistantForegroundService.startInContext(context)
        }
    }
}
