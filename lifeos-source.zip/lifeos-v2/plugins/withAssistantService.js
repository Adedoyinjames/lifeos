/**
 * Expo config plugin — injects the always-on background assistant service.
 * Writes three Kotlin files into the Android project, registers the native
 * module in MainApplication, and adds the required manifest entries.
 */
const {
  withAndroidManifest,
  withMainApplication,
  withDangerousMod,
} = require("@expo/config-plugins");
const fs = require("fs");
const path = require("path");

const TEMPLATES = path.join(__dirname, "templates");
const PKG_PLACEHOLDER = "PACKAGE_PLACEHOLDER";

// ── 1. Write Kotlin source files after prebuild generates the android dir ──
function withKotlinFiles(config) {
  return withDangerousMod(config, [
    "android",
    async (config) => {
      const pkg = config.android?.package ?? "com.lifeos.personalassistant";
      const pkgPath = pkg.replace(/\./g, "/");
      const dest = path.join(
        config.modRequest.platformProjectRoot,
        "app/src/main/java",
        pkgPath
      );
      fs.mkdirSync(dest, { recursive: true });

      for (const name of [
        "AssistantForegroundService.kt",
        "AssistantBridgeModule.kt",
        "AssistantBridgePackage.kt",
      ]) {
        const src = path.join(TEMPLATES, name);
        if (!fs.existsSync(src)) {
          throw new Error(`[withAssistantService] Template missing: ${src}`);
        }
        const code = fs.readFileSync(src, "utf8").replace(new RegExp(PKG_PLACEHOLDER, "g"), pkg);
        fs.writeFileSync(path.join(dest, name), code, "utf8");
      }
      return config;
    },
  ]);
}

// ── 2. Add foreground service + permissions to AndroidManifest.xml ──────────
function withManifest(config) {
  return withAndroidManifest(config, (config) => {
    const manifest = config.modResults.manifest;

    // Permissions to add (merge without duplicating)
    const neededPerms = [
      "android.permission.FOREGROUND_SERVICE",
      "android.permission.FOREGROUND_SERVICE_MICROPHONE",
      "android.permission.RECORD_AUDIO",
      "android.permission.WAKE_LOCK",
      "android.permission.RECEIVE_BOOT_COMPLETED",
    ];
    if (!manifest["uses-permission"]) manifest["uses-permission"] = [];
    const existing = new Set(
      manifest["uses-permission"].map((p) => p.$["android:name"])
    );
    for (const p of neededPerms) {
      if (!existing.has(p)) manifest["uses-permission"].push({ $: { "android:name": p } });
    }

    // Add the foreground service declaration
    const app = manifest.application[0];
    if (!app.service) app.service = [];
    const svcName = ".AssistantForegroundService";
    if (!app.service.find((s) => s.$?.["android:name"] === svcName)) {
      app.service.push({
        $: {
          "android:name": svcName,
          "android:enabled": "true",
          "android:exported": "false",
          "android:foregroundServiceType": "microphone",
          "android:stopWithTask": "false",
        },
      });
    }

    return config;
  });
}

// ── 3. Register AssistantBridgePackage in MainApplication.kt ────────────────
function withPackageRegistration(config) {
  return withMainApplication(config, (config) => {
    let src = config.modResults.contents;
    if (src.includes("AssistantBridgePackage")) return config; // already registered

    // Insert package registration right after PackageList line
    src = src.replace(
      /val packages = PackageList\(this\)\.packages/,
      "val packages = PackageList(this).packages\n          packages.add(AssistantBridgePackage())"
    );

    config.modResults.contents = src;
    return config;
  });
}

// ── Compose ──────────────────────────────────────────────────────────────────
const withAssistantService = (config) => {
  config = withKotlinFiles(config);
  config = withManifest(config);
  config = withPackageRegistration(config);
  return config;
};

module.exports = withAssistantService;
