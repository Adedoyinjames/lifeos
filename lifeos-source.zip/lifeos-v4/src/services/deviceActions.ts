import * as Contacts from "expo-contacts";
import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";
import * as IntentLauncher from "expo-intent-launcher";
import * as Linking from "expo-linking";
import * as Speech from "expo-speech";
import { Platform } from "react-native";

const APP_PACKAGES: Record<string, string> = {
  chrome:         "com.android.chrome",
  gmail:          "com.google.android.gm",
  maps:           "com.google.android.apps.maps",
  messages:       "com.google.android.apps.messaging",
  phone:          "com.google.android.dialer",
  spotify:        "com.spotify.music",
  whatsapp:       "com.whatsapp",
  youtube:        "com.google.android.youtube",
  "youtube music":"com.google.android.apps.youtube.music",
  instagram:      "com.instagram.android",
  twitter:        "com.twitter.android",
  x:              "com.twitter.android",
  facebook:       "com.facebook.katana",
  telegram:       "org.telegram.messenger",
  clock:          "com.google.android.deskclock",
  calendar:       "com.google.android.calendar",
  camera:         "com.android.camera2",
  settings:       "com.android.settings",
  files:          "com.google.android.apps.nbu.files",
  calculator:     "com.google.android.calculator",
  photos:         "com.google.android.apps.photos",
};

// ─── Speech (TTS) ─────────────────────────────────────────────────────────────

export async function speak(text: string, voiceIdentifier: string | null): Promise<void> {
  Speech.stop();
  await new Promise<void>((resolve) => {
    Speech.speak(text, {
      voice:   voiceIdentifier ?? undefined,
      pitch:   0.95,
      rate:    0.88,      // slightly slower = more natural
      onDone:  resolve,
      onError: () => resolve(),
    });
  });
}

export async function listVoices(): Promise<Array<{ identifier: string; name: string; language?: string }>> {
  try {
    return (await Speech.getAvailableVoicesAsync()) as Array<{
      identifier: string; name: string; language?: string;
    }>;
  } catch {
    return [];
  }
}

// ─── Speech-to-text (Android STT dialog) ─────────────────────────────────────

export async function listenOnce(): Promise<string> {
  if (Platform.OS !== "android") {
    throw new Error("Voice commands use Android speech recognition.");
  }
  const result = await IntentLauncher.startActivityAsync(
    "android.speech.action.RECOGNIZE_SPEECH",
    {
      extra: {
        "android.speech.extra.LANGUAGE_MODEL": "free_form",
        "android.speech.extra.PROMPT":         "Speak to LifeOS",
        "android.speech.extra.MAX_RESULTS":    3,
        "android.speech.extra.LANGUAGE":       "en-US",
      },
    },
  );
  const extra      = result.extra as Record<string, unknown> | undefined;
  const candidates =
    (extra?.["android.speech.extra.RESULTS"] as string[] | undefined) ??
    (extra?.["results_recognition"]          as string[] | undefined) ??
    [];
  const best = candidates[0]?.trim();
  if (!best) throw new Error("I did not catch that. Try again or type the command.");
  return best;
}

// ─── Calls ────────────────────────────────────────────────────────────────────

export async function callNumber(numberOrCode: string): Promise<void> {
  const cleaned = numberOrCode.replace(/[^\d+#*]/g, "");
  if (cleaned.length < 3) throw new Error("Give me a phone number or USSD code.");
  await Linking.openURL(`tel:${cleaned}`);
}

export async function callContactOrNumber(nameOrNumber: string): Promise<string> {
  const direct = nameOrNumber.replace(/[^\d+#*]/g, "");
  if (direct.length >= 3) { await callNumber(direct); return nameOrNumber; }

  const permission = await Contacts.requestPermissionsAsync();
  if (permission.status !== "granted") {
    throw new Error("Contact permission needed to call by name.");
  }
  const response = await Contacts.getContactsAsync({
    name:     nameOrNumber,
    fields:   [Contacts.Fields.PhoneNumbers],
    pageSize: 5,
  });
  const contact = response.data.find((c) => c.phoneNumbers?.[0]?.number);
  const number  = contact?.phoneNumbers?.[0]?.number;
  if (!contact || !number) throw new Error(`No phone number found for "${nameOrNumber}".`);
  await callNumber(number);
  return contact.name ?? nameOrNumber;
}

// ─── SMS ──────────────────────────────────────────────────────────────────────

/**
 * Opens the default SMS app pre-filled with recipient and body.
 * Works even when the app is in the background (opens SMS composer).
 */
export async function sendSms(to: string, body: string): Promise<void> {
  const number  = to.replace(/[^\d+]/g, "");
  const encoded = encodeURIComponent(body);
  // RFC 5724 URI — works on all Android versions
  await Linking.openURL(`sms:${number}?body=${encoded}`);
}

/**
 * Look up a contact by name and open SMS composer to them.
 */
export async function sendSmsToContact(name: string, body: string): Promise<string> {
  // Direct number?
  const direct = name.replace(/[^\d+]/g, "");
  if (direct.length >= 6) { await sendSms(direct, body); return name; }

  const perm = await Contacts.requestPermissionsAsync();
  if (perm.status !== "granted") {
    // Fall back to opening SMS without a number
    const encoded = encodeURIComponent(body);
    await Linking.openURL(`sms:?body=${encoded}`);
    return name;
  }
  const resp    = await Contacts.getContactsAsync({
    name, fields: [Contacts.Fields.PhoneNumbers], pageSize: 5,
  });
  const contact = resp.data.find((c) => c.phoneNumbers?.[0]?.number);
  const number  = contact?.phoneNumbers?.[0]?.number;
  if (!number) {
    const encoded = encodeURIComponent(body);
    await Linking.openURL(`sms:?body=${encoded}`);
    return name;
  }
  await sendSms(number, body);
  return contact?.name ?? name;
}

/**
 * Send a WhatsApp message via WhatsApp's URL scheme.
 */
export async function sendWhatsApp(to: string, body: string): Promise<void> {
  const number  = to.replace(/[^\d]/g, "");
  const encoded = encodeURIComponent(body);
  try {
    await Linking.openURL(`whatsapp://send?phone=${number}&text=${encoded}`);
  } catch {
    await Linking.openURL(`https://wa.me/${number}?text=${encoded}`);
  }
}

// ─── Navigation / Maps ────────────────────────────────────────────────────────

/**
 * Opens Google Maps turn-by-turn navigation to [destination].
 */
export async function navigateTo(destination: string): Promise<void> {
  const encoded = encodeURIComponent(destination);
  try {
    // Preferred: native Google Maps navigation intent
    await Linking.openURL(`google.navigation:q=${encoded}`);
  } catch {
    // Fallback: browser-based Maps search
    await Linking.openURL(`https://www.google.com/maps/dir/?api=1&destination=${encoded}`);
  }
}

/**
 * Opens Google Maps search for [query] (e.g. "nearest petrol station").
 */
export async function searchMaps(query: string): Promise<void> {
  const encoded = encodeURIComponent(query);
  try {
    await Linking.openURL(`geo:0,0?q=${encoded}`);
  } catch {
    await Linking.openURL(`https://www.google.com/maps/search/${encoded}`);
  }
}

// ─── Web search ───────────────────────────────────────────────────────────────

export async function searchWeb(query: string): Promise<void> {
  const encoded = encodeURIComponent(query);
  await Linking.openURL(`https://www.google.com/search?q=${encoded}`);
}

// ─── Weather ──────────────────────────────────────────────────────────────────

export async function openWeather(location?: string): Promise<void> {
  const q = encodeURIComponent(location ? `weather ${location}` : "weather today");
  await Linking.openURL(`https://www.google.com/search?q=${q}`);
}

// ─── Alarm (system clock) ────────────────────────────────────────────────────

export async function setSystemAlarm(
  hour: number, minute: number, label = "Alarm",
): Promise<boolean> {
  try {
    await IntentLauncher.startActivityAsync("android.intent.action.SET_ALARM", {
      extra: {
        "android.intent.extra.alarm.HOUR":     hour,
        "android.intent.extra.alarm.MINUTES":  minute,
        "android.intent.extra.alarm.MESSAGE":  label,
        "android.intent.extra.alarm.SKIP_UI":  true,
      },
    });
    return true;
  } catch {
    return true;   // Intent may return RESULT_CANCELED even on success
  }
}

export async function openClockApp(): Promise<void> {
  try {
    await IntentLauncher.openApplication(APP_PACKAGES.clock);
  } catch {
    await Linking.openURL(
      "intent:#Intent;action=android.intent.action.MAIN;c=android.intent.category.LAUNCHER;p=com.google.android.deskclock;end",
    );
  }
}

// ─── Calculation (pure JS — no native needed) ─────────────────────────────────

/**
 * Safely evaluates simple arithmetic from a spoken string.
 * Accepts: "25 times 4", "100 divided by 5", "12 plus 8 minus 3"
 * Returns the numeric result or null if it can't parse.
 */
export function evaluateMath(expression: string): number | null {
  try {
    const norm = expression
      .toLowerCase()
      .replace(/\btimes\b/g, "*")
      .replace(/\bmultiplied by\b/g, "*")
      .replace(/\bdivided by\b/g, "/")
      .replace(/\bover\b/g, "/")
      .replace(/\bplus\b/g, "+")
      .replace(/\bminus\b/g, "-")
      .replace(/\bsquared\b/g, "**2")
      .replace(/\bcubed\b/g, "**3")
      .replace(/[^0-9+\-*/.()\s**]/g, "");   // strip anything non-numeric

    if (!norm.trim()) return null;
    // eslint-disable-next-line no-new-func
    const result = Function(`"use strict"; return (${norm})`)() as unknown;
    if (typeof result === "number" && isFinite(result)) return result;
    return null;
  } catch {
    return null;
  }
}

// ─── Apps ─────────────────────────────────────────────────────────────────────

export async function openKnownApp(name: string): Promise<void> {
  const key         = name.toLowerCase().trim();
  const packageName = APP_PACKAGES[key];
  if (!packageName) {
    throw new Error(
      `I don't know the package for "${name}" yet. Apps I know: ${Object.keys(APP_PACKAGES).join(", ")}.`,
    );
  }
  await IntentLauncher.openApplication(packageName);
}

export async function playMusic(query?: string): Promise<void> {
  try {
    await IntentLauncher.openApplication(APP_PACKAGES.spotify);
  } catch {
    const encoded = encodeURIComponent(query ?? "music");
    await Linking.openURL(`https://music.youtube.com/search?q=${encoded}`);
  }
}

export async function openAssistantSystemSettings(): Promise<void> {
  await IntentLauncher.startActivityAsync(IntentLauncher.ActivityAction.TTS_SETTINGS);
}

export function knownApps(): string[] {
  return Object.keys(APP_PACKAGES);
}

// ─── Files ────────────────────────────────────────────────────────────────────

export async function pickFile(): Promise<{
  name: string; uri: string; mimeType?: string; size?: number;
} | null> {
  const result = await DocumentPicker.getDocumentAsync({
    copyToCacheDirectory: true, multiple: false, type: "*/*",
  });
  if (result.canceled) return null;
  const asset = result.assets[0];
  if (!asset?.uri || !asset?.name) return null;
  return { name: asset.name, uri: asset.uri, mimeType: asset.mimeType, size: asset.size };
}

export async function readTextFileMaybe(uri: string): Promise<string | null> {
  try {
    const info = await FileSystem.getInfoAsync(uri);
    if (!info.exists) return null;
    if (info.size && info.size > 200_000) return null;
    const text = await FileSystem.readAsStringAsync(uri, {
      encoding: FileSystem.EncodingType.UTF8,
    });
    return text.trim() || null;
  } catch {
    return null;
  }
}
