/**
 * Expo config plugin — injects the always-on background assistant.
 *
 * What this does:
 *  1. Writes four Kotlin files into the Android project
 *     (ForegroundService, BridgeModule, BridgePackage, BootReceiver)
 *  2. Adds all required permissions to AndroidManifest.xml
 *  3. Registers the ForegroundService + BootReceiver in AndroidManifest.xml
 *  4. Registers AssistantBridgePackage in MainApplication.kt
 */
const {
  withAndroidManifest,
  withMainApplication,
  withDangerousMod,
} = require("@expo/config-plugins");
const fs   = require("fs");
const path = require("path");

const TEMPLATES       = path.join(__dirname, "templates");
const PKG_PLACEHOLDER = "PACKAGE_PLACEHOLDER";

// ── 1. Kotlin source files ───────────────────────────────────────────────────
function withKotlinFiles(config) {
  return withDangerousMod(config, [
    "android",
    async (config) => {
      const pkg     = config.android?.package ?? "com.lifeos.personalassistant";
      const pkgPath = pkg.replace(/\./g, "/");
      const dest    = path.join(
        config.modRequest.platformProjectRoot,
        "app/src/main/java",
        pkgPath
      );
      fs.mkdirSync(dest, { recursive: true });

      const files = [
        "AssistantForegroundService.kt",
        "AssistantBridgeModule.kt",
        "AssistantBridgePackage.kt",
        "BootReceiver.kt",
      ];

      for (const name of files) {
        const src = path.join(TEMPLATES, name);
        if (!fs.existsSync(src)) {
          throw new Error(`[withAssistantService] Template missing: ${src}`);
        }
        const code = fs
          .readFileSync(src, "utf8")
          .replace(new RegExp(PKG_PLACEHOLDER, "g"), pkg);
        fs.writeFileSync(path.join(dest, name), code, "utf8");
      }
      return config;
    },
  ]);
}

// ── 2. AndroidManifest.xml — permissions + service + receiver ────────────────
function withManifest(config) {
  return withAndroidManifest(config, (config) => {
    const manifest = config.modResults.manifest;

    // Permissions required for always-on background listening
    const neededPerms = [
      "android.permission.FOREGROUND_SERVICE",
      "android.permission.FOREGROUND_SERVICE_MICROPHONE",
      "android.permission.RECORD_AUDIO",
      "android.permission.WAKE_LOCK",
      "android.permission.RECEIVE_BOOT_COMPLETED",
      "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS",
      "android.permission.SEND_SMS",
    ];

    if (!manifest["uses-permission"]) manifest["uses-permission"] = [];
    const existing = new Set(
      manifest["uses-permission"].map((p) => p.$["android:name"])
    );
    for (const p of neededPerms) {
      if (!existing.has(p)) {
        manifest["uses-permission"].push({ $: { "android:name": p } });
      }
    }

    const app = manifest.application[0];

    // ── Foreground service ───────────────────────────────────────────────────
    if (!app.service) app.service = [];
    const svcName = ".AssistantForegroundService";
    if (!app.service.find((s) => s.$?.["android:name"] === svcName)) {
      app.service.push({
        $: {
          "android:name":                svcName,
          "android:enabled":             "true",
          "android:exported":            "false",
          "android:foregroundServiceType":"microphone",
          "android:stopWithTask":        "false",   // survives task removal
        },
      });
    }

    // ── Boot receiver ────────────────────────────────────────────────────────
    if (!app.receiver) app.receiver = [];
    const rcvName = ".BootReceiver";
    if (!app.receiver.find((r) => r.$?.["android:name"] === rcvName)) {
      app.receiver.push({
        $: {
          "android:name":     rcvName,
          "android:enabled":  "true",
          "android:exported": "true",       // must be exported to receive boot broadcast
        },
        "intent-filter": [
          {
            action: [
              { $: { "android:name": "android.intent.action.BOOT_COMPLETED" } },
              { $: { "android:name": "android.intent.action.QUICKBOOT_POWERON" } },
              { $: { "android:name": "com.htc.intent.action.QUICKBOOT_POWERON" } },
            ],
          },
        ],
      });
    }

    return config;
  });
}

// ── 3. MainApplication.kt — register the native module package ───────────────
function withPackageRegistration(config) {
  return withMainApplication(config, (config) => {
    let src = config.modResults.contents;
    if (src.includes("AssistantBridgePackage")) return config; // idempotent

    src = src.replace(
      /val packages = PackageList\(this\)\.packages/,
      "val packages = PackageList(this).packages\n          packages.add(AssistantBridgePackage())"
    );

    config.modResults.contents = src;
    return config;
  });
}

// ── Compose ──────────────────────────────────────────────────────────────────
const withAssistantService = (config) => {
  config = withKotlinFiles(config);
  config = withManifest(config);
  config = withPackageRegistration(config);
  return config;
};

module.exports = withAssistantService;
