package PACKAGE_PLACEHOLDER

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import android.util.Log

/**
 * Persistence Method 3 — JobScheduler periodic job every 15 minutes.
 * JobScheduler is battery-aware and survives Doze mode.
 * Complements the AlarmManager watchdog (Method 2).
 */
class AssistantWatchdogJob : JobService() {

    override fun onStartJob(params: JobParameters?): Boolean {
        Log.d("LifeOS/Job", "Watchdog job fired")
        if (!AssistantForegroundService.isRunning(this)) {
            Log.d("LifeOS/Job", "Service not running — restarting")
            AssistantForegroundService.start(this)
        }
        jobFinished(params, false)
        return false
    }

    override fun onStopJob(params: JobParameters?): Boolean = true  // reschedule

    companion object {
        private const val JOB_ID = 4242

        fun schedule(context: Context) {
            val scheduler = context.getSystemService(JobScheduler::class.java) ?: return
            if (scheduler.getPendingJob(JOB_ID) != null) return   // already scheduled

            val job = JobInfo.Builder(JOB_ID,
                ComponentName(context, AssistantWatchdogJob::class.java))
                .setPeriodic(15 * 60_000L)        // every 15 minutes
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_NONE)
                .setPersisted(true)               // survives reboot
                .build()

            scheduler.schedule(job)
            Log.d("LifeOS/Job", "Watchdog job scheduled")
        }
    }
}
