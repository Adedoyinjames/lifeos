import type { DaySnapshot } from "../types";
import { assistantModelUri, hasAssistantModel } from "../services/llmModelService";
import { buildDaySnapshot } from "../services/timelineBuilder";
import { listEvents, listFocusSessions, listPlanItems } from "../db/repository";
import { dateKey } from "../utils/time";

let llama: typeof import("llama.rn") | null = null;
let context: any | null = null;
let lastModelUri: string | null = null;
let initializing: Promise<void> | null = null;

async function loadModule(): Promise<typeof import("llama.rn")> {
  if (llama) return llama;
  llama = await import("llama.rn");
  return llama;
}

async function ensureContext(): Promise<boolean> {
  if (!(await hasAssistantModel())) return false;
  const uri = assistantModelUri();
  if (context && lastModelUri === uri) return true;
  if (initializing) {
    await initializing;
    return Boolean(context);
  }
  initializing = (async () => {
    const mod = await loadModule();
    lastModelUri = uri;
    context = await mod.initLlama({
      model: uri,
      n_ctx: 2048,
      n_batch: 128,
      n_threads: 4,
      embedding: false,
    });
  })();
  try {
    await initializing;
  } finally {
    initializing = null;
  }
  return Boolean(context);
}

export async function llmAvailable(): Promise<boolean> {
  try {
    return await ensureContext();
  } catch {
    context = null;
    return false;
  }
}

export async function getTodaySnapshot(): Promise<DaySnapshot> {
  const day = dateKey();
  return buildDaySnapshot(day, await listPlanItems(day), await listEvents(day), await listFocusSessions(day));
}

export async function llmChat(prompt: string, snapshot: DaySnapshot, hotword: string): Promise<string | null> {
  const ok = await ensureContext();
  if (!ok) return null;
  const system = [
    "You are a proactive personal phone assistant living inside the LifeOS app.",
    "You help the user plan their day, stay accountable, and avoid wasting time.",
    "Be concise, direct, and ask one clarifying question when needed.",
    "Never suggest deleting files. Never invent phone features you cannot do.",
    `The user's hotword is: ${hotword}.`,
  ].join("\n");

  const contextLine = [
    `Today date: ${snapshot.date}`,
    `Planned items: ${snapshot.planItems.length}`,
    `Completed tasks: ${snapshot.planItems.filter((t) => t.status === "completed").length}`,
    `Untracked minutes: ${snapshot.timeline.filter((s) => s.type === "gap").reduce((a, b) => a + b.minutes, 0)}`,
    `Focused minutes: ${snapshot.focusSessions.reduce((sum, s) => sum + (s.endAt ? Math.max(0, Math.round((new Date(s.endAt).getTime() - new Date(s.startAt).getTime()) / 60000)) : 0), 0)}`,
  ].join("\n");

  const result = await context.completion({
    temperature: 0.7,
    top_p: 0.95,
    max_tokens: 220,
    messages: [
      { role: "system", content: system },
      { role: "system", content: `Context:\n${contextLine}` },
      { role: "user", content: prompt },
    ],
  });
  const text = (result?.text ?? "").trim();
  return text || null;
}

