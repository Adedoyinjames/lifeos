import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";

const MODEL_DIR = `${FileSystem.documentDirectory}models/`;
const ASSISTANT_MODEL_URI = `${MODEL_DIR}assistant.gguf`;

export function assistantModelUri(): string {
  return ASSISTANT_MODEL_URI;
}

export async function ensureModelDir(): Promise<void> {
  const info = await FileSystem.getInfoAsync(MODEL_DIR);
  if (!info.exists) {
    await FileSystem.makeDirectoryAsync(MODEL_DIR, { intermediates: true });
  }
}

export async function hasAssistantModel(): Promise<boolean> {
  const info = await FileSystem.getInfoAsync(ASSISTANT_MODEL_URI);
  return Boolean(info.exists && info.size && info.size > 1024 * 1024);
}

export async function importAssistantModel(): Promise<void> {
  await ensureModelDir();
  const result = await DocumentPicker.getDocumentAsync({
    copyToCacheDirectory: true,
    multiple: false,
    type: "*/*",
  });
  if (result.canceled) return;
  const uri = result.assets[0]?.uri;
  const name = (result.assets[0]?.name ?? "").toLowerCase();
  if (!uri) throw new Error("No model file selected.");
  if (!name.endsWith(".gguf")) throw new Error("Select a GGUF model file ending in .gguf");
  await FileSystem.copyAsync({ from: uri, to: ASSISTANT_MODEL_URI });
}

export async function removeAssistantModel(): Promise<void> {
  const info = await FileSystem.getInfoAsync(ASSISTANT_MODEL_URI);
  if (info.exists) {
    await FileSystem.deleteAsync(ASSISTANT_MODEL_URI, { idempotent: true });
  }
}

