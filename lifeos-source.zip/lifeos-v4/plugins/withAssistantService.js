/**
 * Expo config plugin for LifeOS always-on voice assistant.
 *
 * Adds to the Android project:
 *  • Kotlin native files (service, bridge, watchdogs, receivers)
 *  • All required permissions (mic, overlay, boot, alarm, battery, SMS, etc.)
 *  • Vosk + Sherpa-ONNX Gradle dependencies
 *  • Manifest entries for service, receivers, job
 */
const {
  withAndroidManifest,
  withMainApplication,
  withAppBuildGradle,
  withDangerousMod,
} = require("@expo/config-plugins");
const fs   = require("fs");
const path = require("path");

const TEMPLATES = path.join(__dirname, "templates");
const PKG_PH    = "PACKAGE_PLACEHOLDER";

// ── 1. Copy all Kotlin template files ────────────────────────────────────────

const KOTLIN_FILES = [
  "AssistantForegroundService.kt",
  "AssistantBridgeModule.kt",
  "AssistantBridgePackage.kt",
  "WatchdogReceiver.kt",
  "AssistantWatchdogJob.kt",
  "AlarmTriggerReceiver.kt",
  "BootReceiver.kt",
];

function withKotlinFiles(config) {
  return withDangerousMod(config, ["android", async (cfg) => {
    const pkg     = cfg.android?.package ?? "com.lifeos.app";
    const pkgPath = pkg.replace(/\./g, "/");
    const dest    = path.join(
      cfg.modRequest.platformProjectRoot,
      "app/src/main/java", pkgPath
    );
    fs.mkdirSync(dest, { recursive: true });

    for (const name of KOTLIN_FILES) {
      const src = path.join(TEMPLATES, name);
      if (!fs.existsSync(src))
        throw new Error(`[withAssistantService] Missing template: ${src}`);
      const code = fs.readFileSync(src, "utf8")
        .replace(new RegExp(PKG_PH, "g"), pkg);
      fs.writeFileSync(path.join(dest, name), code, "utf8");
    }
    return cfg;
  }]);
}

// ── 2. AndroidManifest — permissions + components ─────────────────────────────

const PERMISSIONS = [
  // Microphone + foreground service
  "android.permission.RECORD_AUDIO",
  "android.permission.FOREGROUND_SERVICE",
  "android.permission.FOREGROUND_SERVICE_MICROPHONE",
  // CPU / screen-off
  "android.permission.WAKE_LOCK",
  "android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS",
  // Overlay — lets activities launch from background when screen is on
  "android.permission.SYSTEM_ALERT_WINDOW",
  // Boot
  "android.permission.RECEIVE_BOOT_COMPLETED",
  // Alarms
  "android.permission.SCHEDULE_EXACT_ALARM",
  "android.permission.USE_EXACT_ALARM",
  "android.permission.SET_ALARM",
  // Notifications (Android 13+)
  "android.permission.POST_NOTIFICATIONS",
  // Communications
  "android.permission.CALL_PHONE",
  "android.permission.SEND_SMS",
  "android.permission.READ_CONTACTS",
  // Misc
  "android.permission.VIBRATE",
  "android.permission.INTERNET",
  "android.permission.ACCESS_NETWORK_STATE",
  // JobScheduler persistence
  "android.permission.RECEIVE_BOOT_COMPLETED",
];

function withManifest(config) {
  return withAndroidManifest(config, (cfg) => {
    const manifest = cfg.modResults.manifest;

    // Permissions
    if (!manifest["uses-permission"]) manifest["uses-permission"] = [];
    const have = new Set(
      manifest["uses-permission"].map((p) => p.$?.["android:name"])
    );
    for (const p of PERMISSIONS) {
      if (!have.has(p)) manifest["uses-permission"].push({ $: { "android:name": p } });
    }

    const app = manifest.application[0];

    // ── Foreground service ───────────────────────────────────────────────────
    if (!app.service) app.service = [];
    if (!app.service.find((s) => s.$?.["android:name"] === ".AssistantForegroundService")) {
      app.service.push({
        $: {
          "android:name":                ".AssistantForegroundService",
          "android:enabled":             "true",
          "android:exported":            "false",
          "android:foregroundServiceType":"microphone",
          "android:stopWithTask":        "false",
        },
      });
    }

    // ── JobService ───────────────────────────────────────────────────────────
    if (!app.service.find((s) => s.$?.["android:name"] === ".AssistantWatchdogJob")) {
      app.service.push({
        $: {
          "android:name":     ".AssistantWatchdogJob",
          "android:exported": "true",
          "android:permission": "android.permission.BIND_JOB_SERVICE",
        },
      });
    }

    // ── Broadcast receivers ──────────────────────────────────────────────────
    if (!app.receiver) app.receiver = [];

    const addReceiver = (name, actions, exported = true) => {
      if (!app.receiver.find((r) => r.$?.["android:name"] === name)) {
        app.receiver.push({
          $: {
            "android:name":     name,
            "android:enabled":  "true",
            "android:exported": String(exported),
          },
          "intent-filter": [{ action: actions.map((a) => ({ $: { "android:name": a } })) }],
        });
      }
    };

    addReceiver(".WatchdogReceiver", []);   // fires from AlarmManager (no intent-filter needed)

    addReceiver(".BootReceiver", [
      "android.intent.action.BOOT_COMPLETED",
      "android.intent.action.QUICKBOOT_POWERON",
      "com.htc.intent.action.QUICKBOOT_POWERON",
    ]);

    addReceiver(".AlarmTriggerReceiver", []);  // fires from AlarmManager

    return cfg;
  });
}

// ── 3. App build.gradle — Vosk dependency + package options ──────────────────

function withGradleDeps(config) {
  return withAppBuildGradle(config, (cfg) => {
    let gradle = cfg.modResults.contents;

    // Vosk offline STT
    if (!gradle.includes("vosk-android")) {
      gradle = gradle.replace(
        "dependencies {",
        [
          "dependencies {",
          "    // LifeOS: Vosk offline speech recognition",
          "    implementation 'com.alphacephei:vosk-android:0.3.47'",
          "",
        ].join("\n")
      );
    }

    // Prevent duplicate .so conflicts between Vosk (JNA) and other native libs
    if (!gradle.includes("packagingOptions") && !gradle.includes("packaging {")) {
      gradle = gradle.replace(
        "android {",
        [
          "android {",
          "    packagingOptions {",
          "        pickFirst '**/libonnxruntime.so'",
          "        pickFirst '**/libjnidispatch.so'",
          "        pickFirst '**/libc++_shared.so'",
          "    }",
          "",
        ].join("\n")
      );
    }

    cfg.modResults.contents = gradle;
    return cfg;
  });
}

// ── 4. Project build.gradle — Vosk Maven repo ────────────────────────────────

function withMavenRepos(config) {
  return withDangerousMod(config, ["android", async (cfg) => {
    const buildGradle = path.join(
      cfg.modRequest.platformProjectRoot, "build.gradle"
    );
    if (!fs.existsSync(buildGradle)) return cfg;

    let content = fs.readFileSync(buildGradle, "utf8");
    if (content.includes("alphacephei")) return cfg;   // idempotent

    // Inject Vosk Maven repo into every repositories { } block
    content = content.replace(
      /repositories\s*\{/g,
      "repositories {\n        maven { url 'https://alphacephei.com/maven' }"
    );
    fs.writeFileSync(buildGradle, content, "utf8");
    return cfg;
  }]);
}

// ── 5. MainApplication.kt — register native module package ───────────────────

function withPackageRegistration(config) {
  return withMainApplication(config, (cfg) => {
    let src = cfg.modResults.contents;
    if (src.includes("AssistantBridgePackage")) return cfg;

    // Try several patterns produced by different Expo SDK versions
    const patterns = [
      [/(\s*val packages = PackageList\(this\)\.packages)/,
       "$1\n          packages.add(AssistantBridgePackage())"],
      [/(PackageList\(this\)\.packages\.also\s*\{)/,
       "$1\n          it.add(AssistantBridgePackage())"],
    ];

    let replaced = false;
    for (const [rx, repl] of patterns) {
      if (rx.test(src)) { src = src.replace(rx, repl); replaced = true; break; }
    }
    if (!replaced)
      console.warn("[withAssistantService] Could not auto-register AssistantBridgePackage. Add it manually.");

    cfg.modResults.contents = src;
    return cfg;
  });
}

// ── Compose all modifiers ─────────────────────────────────────────────────────

module.exports = (config) => {
  config = withKotlinFiles(config);
  config = withManifest(config);
  config = withMavenRepos(config);
  config = withGradleDeps(config);
  config = withPackageRegistration(config);
  return config;
};
