import { useRouter } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { colors, spacing } from "../src/components/theme";
import {
  MODEL_OPTIONS,
  ModelOption,
  downloadModel,
  extractBundledModel,
  hasAssistantModel,
} from "../src/services/modelDownloadService";

const TIER_COLOR: Record<string, string> = {
  fast: "#66E3FF",
  balanced: "#74FF90",
  smart: "#FFD166",
  best: "#FF6B35",
};

const TIER_LABEL: Record<string, string> = {
  fast: "FAST",
  balanced: "BALANCED",
  smart: "SMART",
  best: "BEST",
};

export default function OnboardingScreen() {
  const router = useRouter();
  const [checking, setChecking] = useState(true);
  const [selected, setSelected] = useState<ModelOption | null>(null);
  const [progress, setProgress] = useState(0);
  const [downloading, setDownloading] = useState(false);
  const [statusMsg, setStatusMsg] = useState("");

  useEffect(() => {
    async function checkBundled() {
      setStatusMsg("Checking for preinstalled brain…");
      const bundleOk = await extractBundledModel();
      if (bundleOk) {
        router.replace("/");
        return;
      }
      const alreadyHas = await hasAssistantModel();
      if (alreadyHas) {
        router.replace("/");
        return;
      }
      setChecking(false);
      setStatusMsg("");
    }
    void checkBundled();
  }, []);

  async function install() {
    if (!selected || downloading) return;
    try {
      setDownloading(true);
      setProgress(0);
      setStatusMsg(`Downloading ${selected.name}…`);
      await downloadModel(selected.url, (pct) => {
        setProgress(pct);
        setStatusMsg(`Downloading ${selected.name}… ${pct}%`);
      });
      setStatusMsg("Installing…");
      Alert.alert(
        "Brain installed ✓",
        `${selected.name} is ready. LifeOS will start now.`,
        [{ text: "Let's go", onPress: () => router.replace("/") }],
      );
    } catch (err) {
      setDownloading(false);
      setStatusMsg("");
      Alert.alert(
        "Download failed",
        err instanceof Error ? err.message : "Check your internet connection and try again.",
      );
    }
  }

  if (checking) {
    return (
      <SafeAreaView style={styles.center}>
        <ActivityIndicator color={colors.accent} size="large" />
        <Text style={styles.status}>{statusMsg}</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.root}>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.h1}>Choose Your AI Brain</Text>
          <Text style={styles.sub}>
            Select a model to install over Wi-Fi or mobile data. This is your private, on-device
            assistant — no cloud, no account, no data leaves your phone.
          </Text>
        </View>

        {/* Model cards */}
        {MODEL_OPTIONS.map((m) => {
          const active = selected?.id === m.id;
          return (
            <Pressable
              key={m.id}
              style={[styles.card, active && styles.cardActive]}
              onPress={() => setSelected(m)}
            >
              <View style={styles.cardTop}>
                <Text style={styles.modelName}>{m.name}</Text>
                <View style={[styles.badge, { backgroundColor: TIER_COLOR[m.tier] + "30" }]}>
                  <Text style={[styles.badgeText, { color: TIER_COLOR[m.tier] }]}>
                    {TIER_LABEL[m.tier]}
                  </Text>
                </View>
              </View>
              <Text style={styles.tagline}>{m.tagline}</Text>
              <Text style={styles.size}>{m.sizeMB >= 1000 ? `${(m.sizeMB / 1000).toFixed(1)} GB` : `${m.sizeMB} MB`}</Text>
              {active && <View style={styles.checkDot} />}
            </Pressable>
          );
        })}

        {/* Progress bar */}
        {downloading ? (
          <View style={styles.progressWrap}>
            <View style={[styles.progressBar, { width: `${progress}%` }]} />
            <Text style={styles.status}>{statusMsg}</Text>
          </View>
        ) : null}

        {/* Install button */}
        <Pressable
          style={[styles.installBtn, (!selected || downloading) && styles.installBtnDisabled]}
          onPress={() => void install()}
          disabled={!selected || downloading}
        >
          {downloading ? (
            <ActivityIndicator color="#000" />
          ) : (
            <Text style={styles.installBtnText}>
              {selected ? `Install ${selected.name}` : "Select a model above"}
            </Text>
          )}
        </Pressable>

        <Text style={styles.footnote}>
          You can change or upgrade the model anytime in Settings → Brain.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: colors.background },
  center: { flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: colors.background, gap: 16 },
  scroll: { padding: spacing.lg, gap: spacing.md, paddingBottom: 48 },
  header: { gap: spacing.sm, marginBottom: spacing.sm },
  h1: { color: colors.text, fontSize: 26, fontWeight: "900" },
  sub: { color: colors.muted, fontSize: 14, lineHeight: 22 },
  card: {
    backgroundColor: colors.surface,
    borderRadius: 12,
    padding: spacing.md,
    borderWidth: 1.5,
    borderColor: "transparent",
    gap: 6,
    position: "relative",
  },
  cardActive: { borderColor: colors.accent },
  cardTop: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  modelName: { color: colors.text, fontWeight: "800", fontSize: 16 },
  badge: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 20 },
  badgeText: { fontWeight: "700", fontSize: 11 },
  tagline: { color: colors.muted, fontSize: 13, lineHeight: 18 },
  size: { color: colors.muted, fontSize: 12 },
  checkDot: {
    position: "absolute",
    top: spacing.sm,
    right: spacing.sm,
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: colors.accent,
  },
  progressWrap: {
    backgroundColor: colors.surface,
    borderRadius: 8,
    overflow: "hidden",
    height: 36,
    justifyContent: "center",
  },
  progressBar: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: colors.accent + "50",
    right: undefined,
  },
  status: { color: colors.text, textAlign: "center", fontSize: 13, paddingHorizontal: spacing.md },
  installBtn: {
    backgroundColor: colors.accent,
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: "center",
    marginTop: spacing.sm,
  },
  installBtnDisabled: { opacity: 0.4 },
  installBtnText: { color: "#000", fontWeight: "800", fontSize: 16 },
  footnote: { color: colors.muted, textAlign: "center", fontSize: 12 },
});
