import {
  createEvent,
  createPlanItem,
  finishFocusSession,
  getActiveFocusSession,
  listEvents,
  listFocusSessions,
  listPlanItems,
  startFocusSession,
} from "../db/repository";
import { getAccountabilityState } from "../services/accountabilityService";
import { buildDaySnapshot } from "../services/timelineBuilder";
import {
  callContactOrNumber,
  knownApps,
  listenOnce,
  openAssistantSystemSettings,
  openKnownApp,
  pickFile,
  playMusic,
  readTextFileMaybe,
  setSystemAlarm,
} from "../services/deviceActions";
import { scheduleAlarm, scheduleReminderIn } from "../services/notificationService";
import type { AssistantCommandResult, EventType } from "../types";
import { dateKey, formatDuration } from "../utils/time";
import { assertTitle } from "../utils/validation";
import { analyzeDay } from "./offlineEngine";
import { getTodaySnapshot, llmAvailable, llmChat } from "./llmAssistant";

function cleanCommand(command: string, hotword: string): string {
  const trimmed = command.trim();
  const lower = trimmed.toLowerCase();
  const hot = hotword.toLowerCase();
  if (lower.startsWith(hot)) return trimmed.slice(hotword.length).replace(/^[,\s]+/, "");
  return trimmed;
}

function timeGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 17) return "Good afternoon";
  return "Good evening";
}

function eventTypeFor(command: string): EventType {
  if (command.includes("break")) return "break";
  if (command.includes("meeting")) return "meeting";
  if (command.includes("distract")) return "distraction";
  if (command.includes("switch")) return "context_switch";
  if (command.includes("note")) return "note";
  return "log";
}

function extractAfter(command: string, patterns: RegExp[]): string | null {
  for (const pattern of patterns) {
    const match = command.match(pattern);
    if (match?.[1]?.trim()) return match[1].trim();
  }
  return null;
}

// ─── Time parsing helpers ────────────────────────────────────────────────────

interface ParsedTime {
  hour: number;
  minute: number;
}

/**
 * Parses human time strings like "7am", "7:30am", "7:30 PM", "07:30", "7 30", "half past 7".
 * Returns null if it cannot parse.
 */
function parseClockTime(text: string): ParsedTime | null {
  const t = text.trim().toLowerCase();

  // "half past 7" / "quarter past 8" / "quarter to 9"
  const halfPast = t.match(/half\s+past\s+(\d{1,2})/);
  if (halfPast) return { hour: parseInt(halfPast[1], 10) % 24, minute: 30 };
  const quarterPast = t.match(/quarter\s+past\s+(\d{1,2})/);
  if (quarterPast) return { hour: parseInt(quarterPast[1], 10) % 24, minute: 15 };
  const quarterTo = t.match(/quarter\s+to\s+(\d{1,2})/);
  if (quarterTo) {
    let h = parseInt(quarterTo[1], 10);
    return { hour: h === 0 ? 23 : (h - 1) % 24, minute: 45 };
  }

  // Standard: 7am / 7:30am / 7:30 pm / 19:30 / 7 30 am
  const match = t.match(/^(\d{1,2})(?:[:\s](\d{2}))?\s*(am|pm)?$/);
  if (!match) return null;
  let hour = parseInt(match[1], 10);
  const minute = match[2] ? parseInt(match[2], 10) : 0;
  const ampm = match[3];
  if (ampm === "pm" && hour < 12) hour += 12;
  if (ampm === "am" && hour === 12) hour = 0;
  if (hour < 0 || hour > 23 || minute < 0 || minute > 59) return null;
  return { hour, minute };
}

/**
 * Parses "in X minutes/hours" style strings.
 * Returns total minutes, or null if no match.
 */
function parseRelativeMinutes(text: string): number | null {
  const t = text.toLowerCase();
  const minMatch = t.match(/(\d+)\s*(?:minutes?|mins?)/);
  const hourMatch = t.match(/(\d+)\s*(?:hours?|hrs?)/);
  if (minMatch && hourMatch) {
    return parseInt(hourMatch[1], 10) * 60 + parseInt(minMatch[1], 10);
  }
  if (minMatch) return parseInt(minMatch[1], 10);
  if (hourMatch) return parseInt(hourMatch[1], 10) * 60;
  return null;
}

function formatAlarmTime(hour: number, minute: number): string {
  const suffix = hour < 12 ? "AM" : "PM";
  const h = hour % 12 === 0 ? 12 : hour % 12;
  return `${h}:${String(minute).padStart(2, "0")} ${suffix}`;
}

// ─── Main command dispatcher ─────────────────────────────────────────────────

export async function runAssistantCommand(
  rawCommand: string,
  hotword: string,
): Promise<AssistantCommandResult> {
  const command = cleanCommand(rawCommand, hotword);
  const lower = command.toLowerCase();
  const today = dateKey();

  if (!command) {
    return {
      actionType: "answer",
      success: true,
      spokenText: `${timeGreeting()}. I am listening. Tell me what to do, log, open, or remember.`,
    };
  }

  // ─── Greeting / status ────────────────────────────────────────────────────
  if (/(hello|hi|good morning|good afternoon|good evening|wake up)/i.test(lower)) {
    const snapshot = buildDaySnapshot(
      today,
      await listPlanItems(today),
      await listEvents(today),
      await listFocusSessions(today),
    );
    const state = getAccountabilityState(snapshot);
    return {
      actionType: "answer",
      success: true,
      spokenText: `${timeGreeting()}. You have ${state.promised.length} commitment${state.promised.length !== 1 ? "s" : ""} today. ${state.questions[0]?.question ?? "What are you working on?"}`,
    };
  }

  // ─── Accountability / next action ─────────────────────────────────────────
  if (/(what should i do|next action|what now|hold me accountable)/i.test(lower)) {
    const snapshot = buildDaySnapshot(
      today,
      await listPlanItems(today),
      await listEvents(today),
      await listFocusSessions(today),
    );
    const state = getAccountabilityState(snapshot);
    return {
      actionType: "answer",
      success: true,
      spokenText:
        state.questions[0]?.question ?? "Choose the smallest useful next action and start a focus session.",
    };
  }

  // ─── Day summary ──────────────────────────────────────────────────────────
  if (/(summary|how did i do|report|today so far)/i.test(lower)) {
    const snapshot = buildDaySnapshot(
      today,
      await listPlanItems(today),
      await listEvents(today),
      await listFocusSessions(today),
    );
    const insight = await analyzeDay(snapshot);
    return { actionType: "answer", success: true, spokenText: insight.summary };
  }

  // ─── Alarms ───────────────────────────────────────────────────────────────
  // "set alarm for 7am" / "wake me up at 7:30" / "alarm at 8 30 am"
  const alarmTimeMatch = command.match(
    /(?:set\s+(?:an?\s+)?alarm(?:\s+for)?|wake\s+me(?:\s+up)?(?:\s+at)?|alarm\s+(?:at|for))\s+(.+)/i,
  );
  if (alarmTimeMatch) {
    const parsed = parseClockTime(alarmTimeMatch[1].trim());
    if (parsed) {
      const label = extractAfter(command, [/(?:called|labelled|named|for)\s+["']?(.+?)["']?$/i]) ?? "Alarm";
      // Schedule in-app alarm notification
      const { firesAt } = await scheduleAlarm(parsed.hour, parsed.minute, label);
      // Also try to set system clock alarm
      await setSystemAlarm(parsed.hour, parsed.minute, label);
      const tomorrow = firesAt.toDateString() !== new Date().toDateString();
      return {
        actionType: "answer",
        success: true,
        spokenText: `Alarm set for ${formatAlarmTime(parsed.hour, parsed.minute)}${tomorrow ? " tomorrow" : " today"}. I will notify you.`,
      };
    }
  }

  // ─── Timers / reminders in X minutes ─────────────────────────────────────
  // "remind me in 30 minutes" / "timer for 20 minutes" / "set timer 1 hour"
  const relativeReminderMatch = command.match(
    /(?:remind(?:\s+me)?|timer|alert\s+me|notify\s+me)\s+(?:in|after)\s+(.+)/i,
  );
  if (relativeReminderMatch) {
    const minutes = parseRelativeMinutes(relativeReminderMatch[1]);
    if (minutes && minutes > 0) {
      const labelMatch = command.match(/(?:to|about|for)\s+(.+?)(?:\s+in\s+|$)/i);
      const label = labelMatch?.[1]?.trim() ?? "Reminder";
      const { firesAt } = await scheduleReminderIn(minutes, label);
      const display = minutes < 60 ? `${minutes} minute${minutes !== 1 ? "s" : ""}` : formatDuration(minutes);
      return {
        actionType: "answer",
        success: true,
        spokenText: `Reminder set. I will notify you in ${display}.`,
      };
    }
  }

  // ─── Add task ─────────────────────────────────────────────────────────────
  const taskTitle = extractAfter(command, [
    /^(?:add|create|remember|plan)\s+(?:a\s+)?(?:task|todo|commitment)\s+(?:to\s+)?(.+)$/i,
    /^remind me to\s+(.+)$/i,
  ]);
  if (taskTitle) {
    const item = await createPlanItem({
      date: today,
      title: assertTitle(taskTitle),
      priority: lower.includes("important") || lower.includes("urgent") ? "high" : "medium",
      kind: "task",
      durationMinutes: 30,
      sortOrder: Date.now(),
    });
    return {
      actionType: "add_task",
      success: true,
      spokenText: `Added "${item.title}" to today's plan. I will ask you about it later.`,
    };
  }

  // ─── Focus session ────────────────────────────────────────────────────────
  const focusTitle = extractAfter(command, [
    /^start\s+(?:a\s+)?focus\s+(?:session\s+)?(?:on\s+)?(.+)$/i,
    /^focus on\s+(.+)$/i,
  ]);
  if (focusTitle || /^start focus$/i.test(command)) {
    const session = await startFocusSession(focusTitle ?? "Focused work", 25);
    return {
      actionType: "start_focus",
      success: true,
      spokenText: `Focus started for "${session.title}". I will check back in 25 minutes.`,
    };
  }

  if (/^(stop|end|finish)\s+focus/i.test(lower)) {
    const active = await getActiveFocusSession();
    if (!active) {
      return { actionType: "stop_focus", success: false, spokenText: "There is no active focus session right now." };
    }
    await finishFocusSession(active.id, true);
    return { actionType: "stop_focus", success: true, spokenText: `Focus session "${active.title}" is complete.` };
  }

  // ─── Log event ────────────────────────────────────────────────────────────
  const logText = extractAfter(command, [
    /^(?:log|record)\s+(.+)$/i,
    /^i am\s+(.+)$/i,
    /^i'm\s+(.+)$/i,
    /^note\s+(.+)$/i,
  ]);
  if (logText) {
    const type = eventTypeFor(lower);
    await createEvent({ type, title: type === "note" ? "Voice note" : logText, note: type === "note" ? logText : "" });
    return { actionType: "log_event", success: true, spokenText: `Logged: ${logText}.` };
  }

  // ─── Call ─────────────────────────────────────────────────────────────────
  const callTarget = extractAfter(command, [/^call\s+(.+)$/i, /^dial\s+(.+)$/i]);
  if (callTarget) {
    const label = await callContactOrNumber(callTarget);
    return { actionType: "call", success: true, spokenText: `Opening the dialer for ${label}.` };
  }

  // ─── Open app ─────────────────────────────────────────────────────────────
  const appName = extractAfter(command, [/^open\s+(.+)$/i, /^launch\s+(.+)$/i]);
  if (appName) {
    await openKnownApp(appName);
    return { actionType: "open_app", success: true, spokenText: `Opening ${appName}.` };
  }

  // ─── Camera ───────────────────────────────────────────────────────────────
  if (/(take (a )?picture|take (a )?photo|open camera|camera)/i.test(lower)) {
    return {
      actionType: "open_camera",
      success: true,
      route: "/camera",
      spokenText: "Opening the camera.",
    };
  }

  // ─── File pick ────────────────────────────────────────────────────────────
  if (/(find file|look for file|open file|pick file|choose file)/i.test(lower)) {
    const file = await pickFile();
    if (!file) return { actionType: "pick_file", success: false, spokenText: "No file selected." };
    const text = await readTextFileMaybe(file.uri);
    if (text) {
      await createEvent({ type: "note", title: "Imported file", note: `${file.name}\n\n${text.slice(0, 1800)}` });
      return { actionType: "pick_file", success: true, spokenText: `Imported ${file.name}. Saved its text as a note.` };
    }
    await createEvent({ type: "note", title: "Picked file", note: `${file.name}\n${file.uri}` });
    return {
      actionType: "pick_file",
      success: true,
      spokenText: `Noted the file ${file.name}. I cannot read its contents but saved the reference.`,
    };
  }

  // ─── Music ────────────────────────────────────────────────────────────────
  const musicQuery = extractAfter(command, [/^play\s+(.+)$/i]);
  if (musicQuery || /^(play music|music)$/i.test(lower)) {
    await playMusic(musicQuery ?? undefined);
    return {
      actionType: "play_music",
      success: true,
      spokenText: musicQuery ? `Opening music for ${musicQuery}.` : "Opening music.",
    };
  }

  // ─── Voice settings ───────────────────────────────────────────────────────
  if (/voice settings|change voice|tts settings/i.test(lower)) {
    await openAssistantSystemSettings();
    return { actionType: "open_settings", success: true, spokenText: "Opening Android text to speech settings." };
  }

  // ─── LLM free-form fallback ───────────────────────────────────────────────
  if (await llmAvailable()) {
    const snapshot = await getTodaySnapshot();
    const response = await llmChat(command, snapshot, hotword);
    if (response) {
      return { actionType: "answer", success: true, spokenText: response };
    }
  }

  return {
    actionType: "answer",
    success: true,
    detail: knownApps().join(", "),
    spokenText: `I can help with planning, focus, alarms, logging, calls, music, and opening apps. Try: "${hotword}, set alarm for 7am" or "${hotword}, what should I do now?"`,
  };
}
