import { createEvent, createPlanItem, finishFocusSession, getActiveFocusSession, listEvents, listFocusSessions, listPlanItems, startFocusSession } from "../db/repository";
import { getAccountabilityState } from "../services/accountabilityService";
import { buildDaySnapshot } from "../services/timelineBuilder";
import { callContactOrNumber, knownApps, openAssistantSystemSettings, openKnownApp, pickFile, playMusic, readTextFileMaybe } from "../services/deviceActions";
import type { AssistantCommandResult, EventType } from "../types";
import { dateKey, formatDuration } from "../utils/time";
import { assertTitle } from "../utils/validation";
import { analyzeDay } from "./offlineEngine";
import { getTodaySnapshot, llmAvailable, llmChat } from "./llmAssistant";

function cleanCommand(command: string, hotword: string): string {
  const trimmed = command.trim();
  const lower = trimmed.toLowerCase();
  const hot = hotword.toLowerCase();
  if (lower.startsWith(hot)) return trimmed.slice(hotword.length).replace(/^[,\s]+/, "");
  return trimmed;
}

function timeGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return "Good morning";
  if (hour < 17) return "Good afternoon";
  return "Good evening";
}

function eventTypeFor(command: string): EventType {
  if (command.includes("break")) return "break";
  if (command.includes("meeting")) return "meeting";
  if (command.includes("distract")) return "distraction";
  if (command.includes("switch")) return "context_switch";
  if (command.includes("note")) return "note";
  return "log";
}

function extractAfter(command: string, patterns: RegExp[]): string | null {
  for (const pattern of patterns) {
    const match = command.match(pattern);
    if (match?.[1]?.trim()) return match[1].trim();
  }
  return null;
}

export async function runAssistantCommand(rawCommand: string, hotword: string): Promise<AssistantCommandResult> {
  const command = cleanCommand(rawCommand, hotword);
  const lower = command.toLowerCase();
  const today = dateKey();

  if (!command) {
    return {
      actionType: "answer",
      success: true,
      spokenText: `${timeGreeting()}. I am listening. Tell me what you want to do, log, open, or remember.`,
    };
  }

  if (/(hello|hi|good morning|good afternoon|good evening|wake up)/i.test(lower)) {
    const snapshot = buildDaySnapshot(today, await listPlanItems(today), await listEvents(today), await listFocusSessions(today));
    const state = getAccountabilityState(snapshot);
    return {
      actionType: "answer",
      success: true,
      spokenText: `${timeGreeting()}. You have ${state.promised.length} commitments today. ${state.questions[0]?.question}`,
    };
  }

  if (/(what should i do|next action|what now|hold me accountable)/i.test(lower)) {
    const snapshot = buildDaySnapshot(today, await listPlanItems(today), await listEvents(today), await listFocusSessions(today));
    const state = getAccountabilityState(snapshot);
    return {
      actionType: "answer",
      success: true,
      spokenText: state.questions[0]?.question ?? "Choose the smallest useful next action and start a focus session.",
    };
  }

  if (/(summary|how did i do|report|today so far)/i.test(lower)) {
    const snapshot = buildDaySnapshot(today, await listPlanItems(today), await listEvents(today), await listFocusSessions(today));
    const insight = await analyzeDay(snapshot);
    return {
      actionType: "answer",
      success: true,
      spokenText: insight.summary,
    };
  }

  const taskTitle = extractAfter(command, [/^(?:add|create|remember|plan)\s+(?:a\s+)?(?:task|todo|commitment)\s+(?:to\s+)?(.+)$/i, /^remind me to\s+(.+)$/i]);
  if (taskTitle) {
    const item = await createPlanItem({
      date: today,
      title: assertTitle(taskTitle),
      priority: lower.includes("important") || lower.includes("urgent") ? "high" : "medium",
      kind: "task",
      durationMinutes: 30,
      sortOrder: Date.now(),
    });
    return {
      actionType: "add_task",
      success: true,
      spokenText: `Added "${item.title}" to today's plan. I will ask you about it later.`,
    };
  }

  const focusTitle = extractAfter(command, [/^start\s+(?:a\s+)?focus\s+(?:session\s+)?(?:on\s+)?(.+)$/i, /^focus on\s+(.+)$/i]);
  if (focusTitle || /^start focus$/i.test(command)) {
    const session = await startFocusSession(focusTitle || "Focused work", 25);
    return {
      actionType: "start_focus",
      success: true,
      spokenText: `Focus started for "${session.title}". I will check back in 25 minutes.`,
    };
  }

  if (/^(stop|end|finish)\s+focus/i.test(lower)) {
    const active = await getActiveFocusSession();
    if (!active) {
      return { actionType: "stop_focus", success: false, spokenText: "There is no active focus session right now." };
    }
    await finishFocusSession(active.id, true);
    return { actionType: "stop_focus", success: true, spokenText: `Focus session "${active.title}" is complete.` };
  }

  const logText = extractAfter(command, [/^(?:log|record)\s+(.+)$/i, /^i am\s+(.+)$/i, /^i'm\s+(.+)$/i, /^note\s+(.+)$/i]);
  if (logText) {
    const type = eventTypeFor(lower);
    await createEvent({ type, title: type === "note" ? "Voice note" : logText, note: type === "note" ? logText : "" });
    return {
      actionType: "log_event",
      success: true,
      spokenText: `Logged: ${logText}.`,
    };
  }

  const callTarget = extractAfter(command, [/^call\s+(.+)$/i, /^dial\s+(.+)$/i]);
  if (callTarget) {
    const label = await callContactOrNumber(callTarget);
    return {
      actionType: "call",
      success: true,
      spokenText: `Opening the dialer for ${label}.`,
    };
  }

  const appName = extractAfter(command, [/^open\s+(.+)$/i, /^launch\s+(.+)$/i]);
  if (appName) {
    await openKnownApp(appName);
    return {
      actionType: "open_app",
      success: true,
      spokenText: `Opening ${appName}.`,
    };
  }

  if (/(take (a )?picture|take (a )?photo|open camera|camera)/i.test(lower)) {
    return {
      actionType: "open_camera",
      success: true,
      route: "/camera",
      spokenText: "Opening the camera. Take a picture and I will store it safely inside LifeOS.",
    };
  }

  if (/(find file|look for file|open file|pick file|choose file)/i.test(lower)) {
    const file = await pickFile();
    if (!file) {
      return { actionType: "pick_file", success: false, spokenText: "No file selected." };
    }
    const text = await readTextFileMaybe(file.uri);
    if (text) {
      await createEvent({ type: "note", title: "Imported file", note: `${file.name}\n\n${text.slice(0, 1800)}` });
      return { actionType: "pick_file", success: true, spokenText: `Imported ${file.name}. I saved its text as a note.` };
    }
    await createEvent({ type: "note", title: "Picked file", note: `${file.name}\n${file.uri}` });
    return { actionType: "pick_file", success: true, spokenText: `I noted the file ${file.name}. I cannot read its contents safely, but I saved the reference.` };
  }

  const musicQuery = extractAfter(command, [/^play\s+(.+)$/i]);
  if (musicQuery || /^(play music|music)$/i.test(lower)) {
    await playMusic(musicQuery ?? undefined);
    return {
      actionType: "play_music",
      success: true,
      spokenText: musicQuery ? `Opening music for ${musicQuery}.` : "Opening music.",
    };
  }

  if (/voice settings|change voice|tts settings/i.test(lower)) {
    await openAssistantSystemSettings();
    return {
      actionType: "open_settings",
      success: true,
      spokenText: "Opening Android text to speech settings.",
    };
  }

  if (await llmAvailable()) {
    const snapshot = await getTodaySnapshot();
    const response = await llmChat(command, snapshot, hotword);
    if (response) {
      return {
        actionType: "answer",
        success: true,
        spokenText: response,
      };
    }
  }

  return {
    actionType: "answer",
    success: true,
    detail: knownApps().join(", "),
    spokenText: `I can help with planning, focus, logging, summaries, calls, music, and opening apps. Try: "${hotword}, what should I do now?"`,
  };
}
