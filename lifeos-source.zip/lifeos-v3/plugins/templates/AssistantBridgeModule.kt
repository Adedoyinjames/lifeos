package PACKAGE_PLACEHOLDER

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.WritableMap
import com.facebook.react.modules.core.DeviceEventManagerModule

class AssistantBridgeModule(reactContext: ReactApplicationContext)
    : ReactContextBaseJavaModule(reactContext) {

    companion object { const val NAME = "AssistantBridge" }
    override fun getName() = NAME

    init {
        AssistantForegroundService.onCommandReceived = { command ->
            emit("onBackgroundCommand",
                Arguments.createMap().apply { putString("command", command) })
        }
        AssistantForegroundService.onHotwordDetected = { hw ->
            emit("onHotwordDetected",
                Arguments.createMap().apply { putString("hotword", hw) })
        }
    }

    // ─── Service control ──────────────────────────────────────────────────────

    @ReactMethod
    fun startService(hotword: String, promise: Promise) {
        try {
            AssistantForegroundService.startInContext(reactApplicationContext, hotword)
            promise.resolve(true)
        } catch (e: Exception) { promise.reject("ERR_START", e.message) }
    }

    @ReactMethod
    fun stopService(promise: Promise) {
        try {
            AssistantForegroundService.stopInContext(reactApplicationContext)
            promise.resolve(true)
        } catch (e: Exception) { promise.reject("ERR_STOP", e.message) }
    }

    @ReactMethod
    fun setHotword(hotword: String, promise: Promise) {
        try {
            AssistantForegroundService.hotword = hotword
            val intent = Intent(reactApplicationContext, AssistantForegroundService::class.java)
                .setAction(AssistantForegroundService.ACTION_UPDATE_HOTWORD)
                .putExtra(AssistantForegroundService.EXTRA_HOTWORD, hotword)
            reactApplicationContext.startService(intent)
            promise.resolve(true)
        } catch (e: Exception) { promise.reject("ERR_HOTWORD", e.message) }
    }

    @ReactMethod
    fun speakBackground(text: String, promise: Promise) {
        try {
            val intent = Intent(reactApplicationContext, AssistantForegroundService::class.java)
                .setAction(AssistantForegroundService.ACTION_SPEAK)
                .putExtra(AssistantForegroundService.EXTRA_TEXT, text)
            reactApplicationContext.startService(intent)
            promise.resolve(true)
        } catch (e: Exception) { promise.reject("ERR_TTS", e.message) }
    }

    // ─── Battery optimisation exemption ───────────────────────────────────────
    /**
     * Returns true if already exempt.
     * Returns false and opens the system dialog that lets the user whitelist
     * LifeOS so Android does not kill the microphone in Doze mode.
     */
    @ReactMethod
    fun requestBatteryExemption(promise: Promise) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val pm = reactApplicationContext
                    .getSystemService(Context.POWER_SERVICE) as PowerManager
                if (!pm.isIgnoringBatteryOptimizations(reactApplicationContext.packageName)) {
                    val intent = Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:${reactApplicationContext.packageName}")
                    ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    reactApplicationContext.startActivity(intent)
                    promise.resolve(false)
                } else {
                    promise.resolve(true)   // already whitelisted
                }
            } else {
                promise.resolve(true)
            }
        } catch (e: Exception) { promise.reject("ERR_BATTERY", e.message) }
    }

    @ReactMethod
    fun isBatteryExempt(promise: Promise) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val pm = reactApplicationContext
                    .getSystemService(Context.POWER_SERVICE) as PowerManager
                promise.resolve(pm.isIgnoringBatteryOptimizations(reactApplicationContext.packageName))
            } else {
                promise.resolve(true)
            }
        } catch (e: Exception) { promise.reject("ERR_BATTERY", e.message) }
    }

    // ─── React Native event plumbing ──────────────────────────────────────────

    @ReactMethod fun addListener(eventName: String) {}
    @ReactMethod fun removeListeners(count: Int) {}

    private fun emit(event: String, params: WritableMap) {
        try {
            reactApplicationContext
                .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                .emit(event, params)
        } catch (e: Exception) {
            Log.e("AssistantBridge", "emit $event failed: ${e.message}")
        }
    }
}
