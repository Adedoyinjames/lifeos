import { NativeEventEmitter, NativeModules, PermissionsAndroid, Platform } from "react-native";
import type { Permission } from "react-native";
import * as FileSystem from "expo-file-system/legacy";
import * as Linking from "expo-linking";

// ─── Native bridge ────────────────────────────────────────────────────────────

interface Bridge {
  startService:             (hotword: string) => Promise<boolean>;
  stopService:              ()                => Promise<boolean>;
  isServiceRunning:         ()                => Promise<boolean>;
  speakBackground:          (text: string)    => Promise<boolean>;
  setVoskModelPath:         (path: string)    => Promise<boolean>;
  getVoskModelPath:         ()                => Promise<string | null>;
  requestBatteryExemption:  ()                => Promise<boolean>;
  isBatteryExempt:          ()                => Promise<boolean>;
  requestOverlayPermission: ()                => Promise<boolean>;
  hasOverlayPermission:     ()                => Promise<boolean>;
  requestExactAlarmPermission: ()             => Promise<boolean>;
  addListener:              (event: string)   => void;
  removeListeners:          (count: number)   => void;
}

const NativeBridge: Bridge | null =
  Platform.OS === "android" && NativeModules.AssistantBridge != null
    ? (NativeModules.AssistantBridge as Bridge)
    : null;

export const available = () => NativeBridge !== null;

// ─── Model paths ─────────────────────────────────────────────────────────────

const MODEL_DIR  = `${FileSystem.documentDirectory}lifeos-models/`;
const VOSK_DIR   = `${MODEL_DIR}vosk-model-small-en-us-0.15/`;
const VOSK_ZIP   = `${MODEL_DIR}vosk.zip`;
const VOSK_URL   = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip";

export async function isVoskInstalled(): Promise<boolean> {
  try {
    const info = await FileSystem.getInfoAsync(VOSK_DIR + "READY");
    return info.exists;
  } catch { return false; }
}

/**
 * Download + extract the Vosk small English model (~40 MB).
 * Progress 0-100 reported via onProgress callback.
 */
export async function downloadVoskModel(
  onProgress: (pct: number) => void
): Promise<void> {
  await FileSystem.makeDirectoryAsync(MODEL_DIR, { intermediates: true });

  // Download zip
  const dl = FileSystem.createDownloadResumable(VOSK_URL, VOSK_ZIP, {}, (p) => {
    if (p.totalBytesExpectedToWrite > 0)
      onProgress(Math.round(p.totalBytesWritten / p.totalBytesExpectedToWrite * 50));
  });
  const result = await dl.downloadAsync();
  if (!result?.uri) throw new Error("Vosk download failed");
  onProgress(50);

  // Unzip using expo-file-system (available in SDK 47+)
  // FileSystem.unzip is not available in legacy API — use workaround:
  // We rely on the native bridge to unzip, OR use fetch + manual extraction.
  // Here we use expo-file-system/legacy's directory create + a native Java unzip
  // via the AssistantBridgeModule (see extractZip below).
  // For now: mark ready and pass the zip path to Vosk (Vosk can load from zip on Android).
  await FileSystem.makeDirectoryAsync(VOSK_DIR, { intermediates: true });

  // On Android, Vosk can load directly from the zip if it has the right structure.
  // Write the zip path to prefs instead of extracting.
  const voskPath = VOSK_ZIP;   // Vosk Android accepts zip paths
  await NativeBridge?.setVoskModelPath(voskPath);

  // Mark installed
  await FileSystem.writeAsStringAsync(VOSK_DIR + "READY", "1");
  onProgress(100);
}

// ─── Permissions ──────────────────────────────────────────────────────────────

export interface PermissionStatus {
  microphone:    boolean;
  notifications: boolean;
  contacts:      boolean;
  phone:         boolean;
  sms:           boolean;
  battery:       boolean;
  overlay:       boolean;
  exactAlarm:    boolean;
}

/**
 * Request every permission the assistant needs.
 * Returns a status map so the UI can show which are still missing.
 */
export async function requestAllPermissions(): Promise<PermissionStatus> {
  if (!available()) {
    return { microphone: false, notifications: false, contacts: false,
             phone: false, sms: false, battery: false, overlay: false, exactAlarm: false };
  }

  // PermissionsAndroid is a value (singleton), not a namespace — Permission
  // must be imported as a standalone type (see import at top of file).
  const PERM_AUDIO    = PermissionsAndroid.PERMISSIONS.RECORD_AUDIO;
  const PERM_CONTACTS = PermissionsAndroid.PERMISSIONS.READ_CONTACTS;
  const PERM_PHONE    = PermissionsAndroid.PERMISSIONS.CALL_PHONE;
  const PERM_SMS      = PermissionsAndroid.PERMISSIONS.SEND_SMS;
  // POST_NOTIFICATIONS exists only on Android 13+ (API 33). Casting keeps the
  // array typed as Permission[] and is harmless on older OS versions.
  const PERM_NOTIF = "android.permission.POST_NOTIFICATIONS" as Permission;

  const androidVersion = parseInt(Platform.Version as string, 10);

  const runtimePerms: Permission[] = [
    PERM_AUDIO,
    PERM_CONTACTS,
    PERM_PHONE,
    PERM_SMS,
    ...(androidVersion >= 33 ? [PERM_NOTIF] : []),
  ];

  const results = await PermissionsAndroid.requestMultiple(runtimePerms);

  // Cast to Record<string, string> so dynamic Permission keys index correctly.
  // Runtime values are unchanged — this is purely a TS widening.
  const resultMap = results as Record<string, string>;
  const granted = (p: Permission) =>
    resultMap[p] === PermissionsAndroid.RESULTS.GRANTED;

  // Special permissions that need a Settings Intent (not requestMultiple)
  const battery = await NativeBridge!.isBatteryExempt().catch(() => false);
  const overlay = await NativeBridge!.hasOverlayPermission().catch(() => false);

  return {
    microphone:    granted(PERM_AUDIO),
    notifications: androidVersion >= 33 ? granted(PERM_NOTIF) : true,
    contacts:      granted(PERM_CONTACTS),
    phone:         granted(PERM_PHONE),
    sms:           granted(PERM_SMS),
    battery,
    overlay,
    exactAlarm:    true,   // checked separately via bridge
  };
}

export const requestBatteryExemption  = () => NativeBridge?.requestBatteryExemption()  ?? Promise.resolve(true);
export const requestOverlayPermission = () => NativeBridge?.requestOverlayPermission() ?? Promise.resolve(true);
export const requestExactAlarm        = () => NativeBridge?.requestExactAlarmPermission() ?? Promise.resolve(true);

// ─── Service control ──────────────────────────────────────────────────────────

let emitter: NativeEventEmitter | null = null;
let cmdSub: any = null;
let hwSub:  any = null;

export async function startAssistant(hotword: string): Promise<void> {
  if (!NativeBridge) return;

  emitter = emitter ?? new NativeEventEmitter(NativeModules.AssistantBridge);
  cmdSub?.remove();
  hwSub?.remove();

  cmdSub = emitter.addListener("onBackgroundCommand", (d: { command: string }) => {
    // When the app is open the UI can respond; the service already spoke the reply
    console.log("[Bob] command from background:", d.command);
  });
  hwSub = emitter.addListener("onHotwordDetected", () => {
    console.log("[Bob] hotword detected");
  });

  await NativeBridge.startService(hotword.toLowerCase());
}

export async function stopAssistant(): Promise<void> {
  cmdSub?.remove(); cmdSub = null;
  hwSub?.remove();  hwSub  = null;
  await NativeBridge?.stopService();
}

export async function isAssistantRunning(): Promise<boolean> {
  return NativeBridge?.isServiceRunning() ?? Promise.resolve(false);
}

export async function speakViaService(text: string): Promise<void> {
  await NativeBridge?.speakBackground(text);
}
