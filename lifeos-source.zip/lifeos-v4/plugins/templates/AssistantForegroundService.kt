package PACKAGE_PLACEHOLDER

import android.app.*
import android.content.*
import android.content.Intent.FLAG_ACTIVITY_NEW_TASK
import android.media.*
import android.net.Uri
import android.os.*
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.util.Log
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.*

/**
 * LifeOS Always-On Voice Assistant Service
 *
 * BREAKTHROUGH: Uses AudioRecord + Vosk instead of SpeechRecognizer.
 * AudioRecord is a low-level hardware API — not subject to Doze restrictions.
 * Vosk runs 100% in-process, no Google, no internet for recognition.
 * This is why the hotword works when the screen is off.
 *
 * THREE persistence methods:
 *   1. START_STICKY  — Android restarts us if killed
 *   2. onTaskRemoved — AlarmManager schedules restart when app is swiped
 *   3. WatchdogReceiver (set in startPersistenceWatchdog) — AlarmManager repeats every 3 min
 *
 * Fourth method (JobScheduler) is in AssistantWatchdogJob.kt
 */
class AssistantForegroundService : Service() {

    companion object {
        const val TAG            = "LifeOS"
        const val NOTIF_ID       = 7001
        const val CHANNEL_ID     = "lifeos_bg"
        const val ACTION_START   = "lifeos.START"
        const val ACTION_STOP    = "lifeos.STOP"
        const val ACTION_SPEAK   = "lifeos.SPEAK"
        const val PREFS          = "lifeos_assistant"
        const val KEY_VOSK       = "vosk_model_path"
        const val KEY_HOTWORD    = "hotword"
        const val SAMPLE_RATE    = 16000
        const val BUF_SIZE       = 4000   // ~250 ms at 16 kHz

        // Callbacks wired by AssistantBridgeModule so JS gets events when app is open
        @Volatile var onCommand  : ((String) -> Unit)? = null
        @Volatile var onHotword  : (() -> Unit)?       = null

        fun start(ctx: Context) {
            val i = Intent(ctx, AssistantForegroundService::class.java).setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(i)
            else ctx.startService(i)
        }

        fun stop(ctx: Context) =
            ctx.stopService(Intent(ctx, AssistantForegroundService::class.java))

        fun isRunning(ctx: Context): Boolean {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            @Suppress("DEPRECATION")
            return am.getRunningServices(50).any {
                it.service.className == AssistantForegroundService::class.java.name
            }
        }
    }

    // ── State ──────────────────────────────────────────────────────────────────
    private var voskModel    : Model?        = null
    private var hotwordRec   : Recognizer?   = null
    private var commandRec   : Recognizer?   = null
    private var audioRecord  : AudioRecord?  = null
    private var tts          : TextToSpeech? = null
    private var ttsReady     = false
    private val ttsQueue     = ArrayDeque<String>()
    private var wakeLock     : PowerManager.WakeLock? = null
    private var captureThread: Thread?       = null
    @Volatile private var running          = false
    @Volatile private var awaitingCommand  = false
    @Volatile private var speaking         = false
    @Volatile private var hotword          = "hey bob"

    // ── Lifecycle ──────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification("Booting voice engine…"))
        acquireWakeLock()
        initTts()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        hotword   = prefs.getString(KEY_HOTWORD, "hey bob")?.lowercase() ?: "hey bob"

        when (intent?.action) {
            ACTION_SPEAK -> {
                intent.getStringExtra("text")?.let { speakNow(it) }
                return START_STICKY
            }
            ACTION_STOP  -> { shutdown(); return START_NOT_STICKY }
        }

        if (!running) {
            running = true
            startPersistenceWatchdog()
            startCaptureThread()
        }
        return START_STICKY   // ← Android resurrects us if killed
    }

    /** Method 2 — reschedule via AlarmManager when app task is removed */
    override fun onTaskRemoved(rootIntent: Intent?) {
        rescheduleViaPendingIntent(1_500)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    // ── Shutdown ───────────────────────────────────────────────────────────────

    private fun shutdown() {
        running = false
        captureThread?.interrupt()
        captureThread = null
        audioRecord?.stop()
        audioRecord?.release()
        audioRecord = null
        hotwordRec?.close(); hotwordRec = null
        commandRec?.close(); commandRec = null
        voskModel?.close(); voskModel = null
        tts?.stop(); tts?.shutdown(); tts = null
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
    }

    // ── AudioRecord + Vosk capture thread ─────────────────────────────────────

    private fun startCaptureThread() {
        captureThread = Thread {
            try {
                initVosk()
                initAudio()
                audioRecord?.startRecording()
                updateNotification("Say \"Hey BOB\" — I'm listening")
                loop()
            } catch (e: InterruptedException) {
                Log.d(TAG, "Capture thread interrupted")
            } catch (e: Exception) {
                Log.e(TAG, "Capture error: ${e.message}", e)
                updateNotification("Voice engine error — retrying in 10 s")
                Thread.sleep(10_000)
                if (running) startCaptureThread()   // self-heal
            }
        }.apply { isDaemon = true; start() }
    }

    /**
     * Tight read loop.  AudioRecord.read() blocks until samples are ready —
     * this means the thread sleeps while waiting for audio, consuming ~0 CPU.
     * PARTIAL_WAKE_LOCK keeps the CPU alive so Vosk can run inference.
     */
    private fun loop() {
        val buf = ShortArray(BUF_SIZE)
        while (running) {
            if (speaking) { Thread.sleep(50); continue }   // pause while TTS is playing

            val read = audioRecord?.read(buf, 0, BUF_SIZE) ?: -1
            if (read <= 0) continue

            val rec = if (awaitingCommand) commandRec else hotwordRec
            val accepted = rec?.acceptWaveForm(buf, read) == true

            if (accepted) {
                val text = parseText(rec?.result) ?: continue
                if (text.isNotBlank()) handleSpeech(text)
            } else {
                // Check partial results for immediate hotword response
                if (!awaitingCommand) {
                    val partial = parseText(hotwordRec?.partialResult, key = "partial") ?: ""
                    if (partial.contains(hotword, ignoreCase = true)) {
                        triggerHotword(partial)
                    }
                }
            }
        }
    }

    // ── Speech handling ────────────────────────────────────────────────────────

    private fun handleSpeech(text: String) {
        val lower = text.lowercase().trim()
        Log.d(TAG, "Heard[${ if (awaitingCommand) "CMD" else "HW" }]: $lower")

        if (awaitingCommand) {
            awaitingCommand = false
            updateNotification("Processing…")
            val response = processCommand(lower)
            speakNow(response)
            onCommand?.invoke(lower)
            switchToHotwordMode()
        } else if (lower.contains(hotword, ignoreCase = true)) {
            val afterHotword = lower.substringAfter(hotword).trim().removePrefix(",").trim()
            if (afterHotword.isNotEmpty()) {
                updateNotification("Processing…")
                val response = processCommand(afterHotword)
                speakNow(response)
                onCommand?.invoke(afterHotword)
            } else {
                triggerHotword(lower)
            }
        }
    }

    private fun triggerHotword(heard: String) {
        if (awaitingCommand) return
        Log.d(TAG, "Hotword detected in: $heard")
        awaitingCommand = true
        onHotword?.invoke()
        speakNow("Yes?")
        switchToCommandMode()
        updateNotification("Listening for your command…")
    }

    private fun switchToHotwordMode() {
        commandRec?.close(); commandRec = null
        updateNotification("Say \"Hey BOB\" — I'm listening")
        awaitingCommand = false
    }

    private fun switchToCommandMode() {
        commandRec?.close()
        commandRec = voskModel?.let { Recognizer(it, SAMPLE_RATE.toFloat()) }
    }

    // ── Vosk initialisation ────────────────────────────────────────────────────

    private fun initVosk() {
        val prefs     = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val modelPath = prefs.getString(KEY_VOSK, null)
            ?: throw Exception("Vosk model not installed. Open LifeOS app to finish setup.")
        if (!File(modelPath).exists())
            throw Exception("Vosk model missing at $modelPath — please reinstall.")

        Log.d(TAG, "Loading Vosk from $modelPath")
        voskModel  = Model(modelPath)
        // Grammar-mode for hotword: only recognises "hey bob" + catch-all [unk]
        hotwordRec = Recognizer(voskModel, SAMPLE_RATE.toFloat(),
            "[\"hey bob\", \"bob\", \"[unk]\"]")
        Log.d(TAG, "Vosk ready")
    }

    // ── AudioRecord initialisation ─────────────────────────────────────────────

    private fun initAudio() {
        val minBuf = AudioRecord.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(BUF_SIZE * 2)

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf
        )
        check(audioRecord?.state == AudioRecord.STATE_INITIALIZED) {
            "AudioRecord failed to initialise — microphone permission may be denied"
        }
    }

    // ── TTS (Android built-in, best available voice) ───────────────────────────

    private fun initTts() {
        tts = TextToSpeech(this) { status ->
            if (status != TextToSpeech.SUCCESS) {
                Log.e(TAG, "TTS init failed: $status"); return@TextToSpeech
            }
            tts?.language = Locale.US
            selectBestVoice()
            tts?.setSpeechRate(0.88f)
            tts?.setPitch(0.95f)
            ttsReady = true
            ttsQueue.forEach { speakNow(it) }
            ttsQueue.clear()
        }
    }

    /**
     * Picks the highest-quality English voice the device has.
     * Prefers network-enabled voices (Google Neural TTS) when available —
     * they sound far more natural than offline voices on most devices.
     * Falls back to best offline voice if no network voice is available.
     */
    private fun selectBestVoice() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return
        val voices: Set<Voice> = tts?.voices ?: return
        val english = voices.filter { it.locale.language == "en" }

        val best = english.filter { it.isNetworkConnectionRequired }
                       .maxByOrNull { it.quality }
                   ?: english.filter { !it.isNetworkConnectionRequired }
                       .maxByOrNull { it.quality }
        best?.let { tts?.voice = it; Log.d(TAG, "TTS voice: ${it.name}") }
    }

    private fun speakNow(text: String) {
        if (!ttsReady) { ttsQueue.addLast(text); return }
        speaking = true
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u_${System.currentTimeMillis()}")
        // speaking flag cleared after utterance completes via setOnUtteranceProgressListener
        tts?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?)  { speaking = false }
            @Deprecated("Deprecated") override fun onError(id: String?) { speaking = false }
        })
    }

    // ── Command Processor (pure Kotlin, no LLM, no JS bridge needed) ──────────

    private fun processCommand(raw: String): String {
        // Strip hotword prefix if included in command text
        val cmd = raw.lowercase().trim()
            .removePrefix("hey bob").removePrefix("bob")
            .trim().removePrefix(",").trim()

        return when {
            // ── Time ──────────────────────────────────────────────────────────
            cmd.contains("time") || cmd == "clock" ->
                "It is ${fmt("h:mm a")}."

            // ── Date / Day ────────────────────────────────────────────────────
            cmd.contains("date") || cmd.contains("what day") || cmd.contains("today") ->
                "Today is ${fmt("EEEE, MMMM d, yyyy")}."

            // ── Greeting ──────────────────────────────────────────────────────
            cmd.matches(Regex("^(hi|hello|hey|good morning|good afternoon|good evening|howdy).*")) ->
                "${timeGreeting()}! I'm Bob, your personal assistant. How can I help?"

            // ── Identity ──────────────────────────────────────────────────────
            cmd.contains("who are you") || cmd.contains("your name") || cmd.contains("what are you") ->
                "I'm Bob, your personal life assistant built into LifeOS. I'm always listening for your commands, even when the screen is off."

            // ── Calculator ────────────────────────────────────────────────────
            isMath(cmd) -> {
                val result = tryCalc(normaliseMath(cmd))
                if (result != null) "That equals ${prettyNum(result)}."
                else "I couldn't calculate that. Try: what is 25 times 8."
            }

            // ── Alarm ─────────────────────────────────────────────────────────
            cmd.contains("alarm") || cmd.contains("wake me") ->
                setAlarm(cmd)

            // ── Reminder / Timer ──────────────────────────────────────────────
            cmd.contains("remind") || cmd.contains("timer") ->
                setReminder(cmd)

            // ── Add task ──────────────────────────────────────────────────────
            cmd.contains("add task") || cmd.contains("add a task") ||
            cmd.contains("remember to") || cmd.contains("note that") ||
            cmd.contains("don't forget") || cmd.contains("create task") ->
                addTask(cmd)

            // ── List tasks ────────────────────────────────────────────────────
            cmd.contains("my tasks") || cmd.contains("list tasks") ||
            cmd.contains("what do i have") || cmd.contains("tasks for today") ->
                listTasks()

            // ── Clear tasks ───────────────────────────────────────────────────
            cmd.contains("clear tasks") || cmd.contains("delete all tasks") ||
            cmd.contains("remove all tasks") ->
                clearTasks()

            // ── Navigate ──────────────────────────────────────────────────────
            cmd.contains("navigate to") || cmd.contains("directions to") ||
            cmd.contains("take me to") || cmd.contains("drive to") ->
                navigate(cmd)

            // ── Call ──────────────────────────────────────────────────────────
            cmd.startsWith("call ") || cmd.startsWith("dial ") || cmd.startsWith("phone ") ->
                makeCall(cmd)

            // ── SMS ───────────────────────────────────────────────────────────
            (cmd.contains("text ") || cmd.contains("message ") || cmd.contains("send ")) &&
            (cmd.contains(" saying ") || cmd.contains(" that ") || cmd.contains(" say ")) ->
                sendSms(cmd)

            // ── WhatsApp ──────────────────────────────────────────────────────
            cmd.contains("whatsapp") ->
                sendWhatsApp(cmd)

            // ── Search ────────────────────────────────────────────────────────
            cmd.startsWith("search ") || cmd.startsWith("google ") || cmd.startsWith("look up ") ->
                searchWeb(cmd)

            // ── Weather ───────────────────────────────────────────────────────
            cmd.contains("weather") || cmd.contains("temperature") || cmd.contains("forecast") ->
                openAndSpeak("https://www.google.com/search?q=weather+today",
                    "Opening weather forecast for you.")

            // ── Music ─────────────────────────────────────────────────────────
            cmd.startsWith("play ") || cmd == "play music" || cmd.contains("music") ->
                playMusic(cmd)

            // ── Open app ──────────────────────────────────────────────────────
            cmd.startsWith("open ") || cmd.startsWith("launch ") ->
                openApp(cmd.removePrefix("open ").removePrefix("launch ").trim())

            // ── Motivation / coaching ─────────────────────────────────────────
            cmd.contains("motivate") || cmd.contains("inspire") || cmd.contains("encourage") ->
                listOf(
                    "You've got this! One step at a time.",
                    "Progress is progress, no matter how small. Keep going.",
                    "Focus on the next right action. You can do this.",
                    "Every expert was once a beginner. Start now."
                ).random()

            // ── Help ──────────────────────────────────────────────────────────
            cmd.contains("help") || cmd.contains("what can you do") || cmd == "commands" ->
                "I can tell you the time and date, set alarms and reminders, add and list tasks, " +
                "calculate maths, navigate, call, send messages, search the web, open apps, and much more. " +
                "Just say Hey BOB followed by your command."

            // ── Stop service ──────────────────────────────────────────────────
            cmd.matches(Regex("^(stop|sleep|turn off|goodbye|bye|exit)[^a-z]*")) -> {
                speakNow("Going to sleep. Say Hey BOB to wake me.")
                Handler(Looper.getMainLooper()).postDelayed({ stop(this) }, 2_000)
                "Going to sleep."
            }

            else ->
                "I didn't catch that. Try: what time is it, set alarm for 7 A M, " +
                "add task, remind me in 30 minutes, or hey bob help."
        }
    }

    // ── Command helpers ────────────────────────────────────────────────────────

    private fun setAlarm(cmd: String): String {
        val pat = Regex(
            "(?:at|for)?\\s*(\\d{1,2})(?:[:\\s](\\d{2}))?\\s*(a\\.?m\\.?|p\\.?m\\.?)?",
            RegexOption.IGNORE_CASE
        )
        val m = pat.find(cmd) ?: return "I couldn't find a time. Try: set alarm for 7 AM."
        var hour = m.groupValues[1].toIntOrNull() ?: return "Invalid hour."
        val min  = m.groupValues[2].toIntOrNull() ?: 0
        val ampm = m.groupValues[3].lowercase().replace(".", "")
        if (ampm == "pm" && hour < 12) hour += 12
        if (ampm == "am" && hour == 12) hour = 0

        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, min)
            set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            if (before(Calendar.getInstance())) add(Calendar.DAY_OF_MONTH, 1)
        }

        // Try clock app intent first (shows alarm in phone's clock app)
        try {
            startActivity(Intent("android.intent.action.SET_ALARM").apply {
                putExtra("android.intent.extra.alarm.HOUR",    hour)
                putExtra("android.intent.extra.alarm.MINUTES", min)
                putExtra("android.intent.extra.alarm.SKIP_UI", true)
                addFlags(FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (_: Exception) {
            // Fallback: schedule via AlarmManager + our own trigger receiver
            scheduleExact(cal.timeInMillis, "Alarm", false)
        }

        val display  = SimpleDateFormat("h:mm a", Locale.US).format(cal.time)
        val tomorrow = !sameDay(cal, Calendar.getInstance())
        return "Alarm set for $display${if (tomorrow) " tomorrow" else " today"}."
    }

    private fun setReminder(cmd: String): String {
        val minMatch = Regex("(\\d+)\\s*(?:minute|min)").find(cmd)
        val hrMatch  = Regex("(\\d+)\\s*(?:hour|hr)").find(cmd)
        val secMatch = Regex("(\\d+)\\s*second").find(cmd)
        val totalMin = (minMatch?.groupValues?.get(1)?.toInt() ?: 0) +
                       (hrMatch?.groupValues?.get(1)?.toInt() ?: 0) * 60 +
                       (secMatch?.groupValues?.get(1)?.toInt() ?: 0).let {
                           if (it > 0) 1 else 0 // round seconds up to 1 min
                       }
        if (totalMin <= 0)
            return "Tell me how long. Try: remind me in 30 minutes to drink water."

        val labelMatch = Regex("(?:to|about|for)\\s+(.+?)(?:\\s+in\\s+|$)", RegexOption.IGNORE_CASE)
            .find(cmd)
        val label = labelMatch?.groupValues?.get(1)?.trim()?.let {
            if (it.length > 50) it.substring(0, 50) else it
        } ?: "Reminder"

        val triggerMs = SystemClock.elapsedRealtime() + totalMin * 60_000L
        scheduleExact(triggerMs, label, elapsed = true)

        val display = when {
            totalMin >= 60 -> "${totalMin / 60} hour${if (totalMin >= 120) "s" else ""}" +
                             if (totalMin % 60 > 0) " ${totalMin % 60} min" else ""
            else           -> "$totalMin minute${if (totalMin != 1) "s" else ""}"
        }
        return "Got it. I'll remind you about \"$label\" in $display."
    }

    private fun addTask(cmd: String): String {
        val title = cmd
            .replace(Regex("(?:add|create|remember(?:\\s+to)?|note(?:\\s+that)?|don't\\s+forget(?:\\s+to)?)\\s+(?:a\\s+)?(?:task\\s+)?", RegexOption.IGNORE_CASE), "")
            .trim().take(80)
        if (title.length < 2) return "What task should I add?"

        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val tasks = prefs.getStringSet("tasks", emptySet())?.toMutableSet() ?: mutableSetOf()
        tasks.add("${System.currentTimeMillis()}|$title")
        prefs.edit().putStringSet("tasks", tasks).apply()
        return "Added to your list: $title."
    }

    private fun listTasks(): String {
        val prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val items = prefs.getStringSet("tasks", emptySet())
            ?.sortedBy { it.substringBefore("|").toLongOrNull() ?: 0L }
            ?.mapNotNull { it.substringAfter("|", "").takeIf { s -> s.isNotBlank() } }
            ?: emptyList()
        if (items.isEmpty()) return "You have no tasks. Say: Hey BOB add task, then tell me what to add."
        val recent = items.takeLast(5)
        return "You have ${items.size} task${if (items.size != 1) "s" else ""}. " +
               "Most recent: ${recent.joinToString("; ")}."
    }

    private fun clearTasks(): String {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .remove("tasks").apply()
        return "All tasks cleared."
    }

    private fun navigate(cmd: String): String {
        val dest = cmd
            .replace(Regex("(?:navigate|directions?|take me|drive)\\s+to\\s+"), "")
            .trim()
        if (dest.isBlank()) return "Where would you like to go?"
        openUrl("google.navigation:q=${dest.enc()}")
        return "Opening navigation to $dest."
    }

    private fun makeCall(cmd: String): String {
        val name = cmd.removePrefix("call ").removePrefix("dial ").removePrefix("phone ").trim()
        if (name.isBlank()) return "Who would you like to call?"
        val number = name.replace(Regex("[^\\d+]"), "")
        return if (number.length >= 5) {
            openUrl("tel:$number")
            "Calling $name."
        } else {
            openUrl("tel:")
            "Please check your screen to select a contact."
        }
    }

    private fun sendSms(cmd: String): String {
        val m = Regex(
            "(?:text|message|send)\\s+(.+?)\\s+(?:saying|that|say)\\s+(.+)",
            RegexOption.IGNORE_CASE
        ).find(cmd)
        if (m == null) return "Try: text John saying I'm on my way."
        val to   = m.groupValues[1].trim()
        val body = m.groupValues[2].trim()
        val num  = to.replace(Regex("[^\\d+]"), "")
        openUrl(if (num.length >= 5) "sms:$num?body=${body.enc()}" else "sms:?body=${body.enc()}")
        return "Opening messages to $to. Check your screen to send."
    }

    private fun sendWhatsApp(cmd: String): String {
        val m = Regex("whatsapp\\s+(.+?)\\s+(?:saying|that|say)\\s+(.+)", RegexOption.IGNORE_CASE)
            .find(cmd)
        if (m == null) { openUrl("com.whatsapp"); return "Opening WhatsApp." }
        val to   = m.groupValues[1].trim()
        val body = m.groupValues[2].trim()
        val num  = to.replace(Regex("[^\\d]"), "")
        openUrl("whatsapp://send?phone=$num&text=${body.enc()}")
        return "Opening WhatsApp to $to."
    }

    private fun searchWeb(cmd: String): String {
        val q = cmd.removePrefix("search ").removePrefix("google ")
            .removePrefix("look up ").trim()
        openUrl("https://www.google.com/search?q=${q.enc()}")
        return "Searching for $q."
    }

    private fun playMusic(cmd: String): String {
        val query = cmd.removePrefix("play ").trim()
        return try {
            openUrl("spotify:search:$query")
            if (query.isEmpty() || query == "music") "Opening Spotify." else "Playing $query on Spotify."
        } catch (_: Exception) {
            openUrl("https://music.youtube.com/search?q=${query.enc()}")
            "Opening YouTube Music."
        }
    }

    private fun openApp(name: String): String {
        val pkg = APP_PACKAGES[name.lowercase()]
            ?: APP_PACKAGES.entries.firstOrNull { name.lowercase().contains(it.key) }?.value
        return if (pkg != null) {
            try {
                val intent = packageManager.getLaunchIntentForPackage(pkg)
                    ?.apply { addFlags(FLAG_ACTIVITY_NEW_TASK) }
                if (intent != null) { startActivity(intent); "Opening $name." }
                else "Couldn't find $name on your phone."
            } catch (_: Exception) { "Couldn't open $name." }
        } else {
            openUrl("https://play.google.com/store/search?q=${name.enc()}")
            "Searching for $name in the Play Store."
        }
    }

    private fun openAndSpeak(url: String, response: String): String {
        openUrl(url); return response
    }

    private fun openUrl(url: String) {
        try {
            val uri    = Uri.parse(url)
            val intent = Intent(Intent.ACTION_VIEW, uri).addFlags(FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (e: Exception) { Log.e(TAG, "openUrl($url): ${e.message}") }
    }

    // ── AlarmManager helpers ───────────────────────────────────────────────────

    private fun scheduleExact(timeMs: Long, label: String, elapsed: Boolean) {
        val intent = Intent(this, AlarmTriggerReceiver::class.java)
            .putExtra("label", label)
        val pi = PendingIntent.getBroadcast(
            this, (System.currentTimeMillis() % Int.MAX_VALUE).toInt(),
            intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val am   = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val type = if (elapsed) AlarmManager.ELAPSED_REALTIME_WAKEUP
                   else        AlarmManager.RTC_WAKEUP
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            am.setExactAndAllowWhileIdle(type, timeMs, pi)
        else
            am.setExact(type, timeMs, pi)
    }

    // ── Persistence watchdog (Method 3 — repeating alarm) ─────────────────────

    private fun startPersistenceWatchdog() {
        val pi = PendingIntent.getBroadcast(
            this, 8888,
            Intent(this, WatchdogReceiver::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        // Fires every 3 minutes; WatchdogReceiver restarts service if it stopped
        am.setRepeating(
            AlarmManager.ELAPSED_REALTIME_WAKEUP,
            SystemClock.elapsedRealtime() + 3 * 60_000L,
            3 * 60_000L,
            pi
        )
    }

    private fun rescheduleViaPendingIntent(delayMs: Long) {
        val pi = PendingIntent.getService(
            this, 9001,
            Intent(this, AssistantForegroundService::class.java).setAction(ACTION_START),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        (getSystemService(Context.ALARM_SERVICE) as AlarmManager)
            .set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + delayMs, pi)
    }

    // ── Wake lock ──────────────────────────────────────────────────────────────

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LifeOS::Mic").also {
            it.setReferenceCounted(false); it.acquire()
        }
    }

    // ── Notification ───────────────────────────────────────────────────────────

    private fun createNotificationChannel() {
        val ch = NotificationChannel(
            CHANNEL_ID, "LifeOS Assistant",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Always-on voice assistant";
            setShowBadge(false); enableVibration(false); setSound(null, null)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotification(text: String): Notification {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
            ?.apply { flags = Intent.FLAG_ACTIVITY_SINGLE_TOP }
        val pi = PendingIntent.getActivity(
            this, 0, launch,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("LifeOS — Bob")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true).setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIF_ID, buildNotification(text))
    }

    // ── Math evaluator ─────────────────────────────────────────────────────────

    private fun isMath(cmd: String) =
        Regex("\\d+\\s*(?:times|plus|minus|divided|multiplied|over|\\+|-|\\*|/)\\s*\\d+").containsMatchIn(cmd) ||
        cmd.startsWith("what is ") || cmd.startsWith("calculate ") || cmd.startsWith("compute ")

    private fun normaliseMath(cmd: String) = cmd
        .replace(Regex("(?:what(?:'s|\\s+is)?\\s+|calculate\\s+|compute\\s+|solve\\s+)"), "")
        .replace(Regex("\\btimes\\b"), "*").replace(Regex("\\bmultiplied by\\b"), "*")
        .replace(Regex("\\bdivided by\\b"), "/").replace(Regex("\\bover\\b"), "/")
        .replace(Regex("\\bplus\\b"), "+").replace(Regex("\\badd\\b"), "+")
        .replace(Regex("\\bminus\\b|\\bsubtract\\b|\\btake away\\b"), "-")
        .replace(Regex("[^0-9+\\-*/.() ]"), "").trim()

    private fun tryCalc(expr: String): Double? =
        runCatching { MathParser(expr.replace(" ", "")).parse() }.getOrNull()

    private fun prettyNum(d: Double): String =
        if (d == d.toLong().toDouble()) d.toLong().toString()
        else "%.6f".format(d).trimEnd('0').trimEnd('.')

    private inner class MathParser(private val s: String) {
        private var i = 0
        fun parse() = expr().also { check(i >= s.length) { "leftover at $i" } }
        private fun expr(): Double { var r = term(); while (i < s.length && s[i] in "+-") { val op = s[i++]; r = if (op == '+') r + term() else r - term() }; return r }
        private fun term(): Double { var r = factor(); while (i < s.length && s[i] in "*/") { val op = s[i++]; r = if (op == '*') r * factor() else r / factor() }; return r }
        private fun factor(): Double {
            while (i < s.length && s[i] == ' ') i++
            if (i >= s.length) throw Exception("eof")
            if (s[i] == '(') { i++; val r = expr(); if (i < s.length && s[i] == ')') i++; return r }
            if (s[i] == '-') { i++; return -factor() }
            if (s[i] == '+') { i++; return factor() }
            val start = i; while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            return s.substring(start, i).toDoubleOrNull() ?: throw Exception("bad num at $start")
        }
    }

    // ── Utilities ──────────────────────────────────────────────────────────────

    private fun fmt(pattern: String) = SimpleDateFormat(pattern, Locale.US).format(Date())

    private fun timeGreeting(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return when { h < 12 -> "Good morning"; h < 17 -> "Good afternoon"; else -> "Good evening" }
    }

    private fun sameDay(a: Calendar, b: Calendar) =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) &&
        a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)

    private fun String.enc() = URLEncoder.encode(this, "UTF-8")

    private fun parseText(json: String?, key: String = "text"): String? =
        json?.let { runCatching { JSONObject(it).getString(key).trim() }.getOrNull() }

    companion object {
        val APP_PACKAGES = mapOf(
            "spotify"         to "com.spotify.music",
            "whatsapp"        to "com.whatsapp",
            "instagram"       to "com.instagram.android",
            "youtube"         to "com.google.android.youtube",
            "youtube music"   to "com.google.android.apps.youtube.music",
            "gmail"           to "com.google.android.gm",
            "maps"            to "com.google.android.apps.maps",
            "chrome"          to "com.android.chrome",
            "twitter"         to "com.twitter.android",
            "x"               to "com.twitter.android",
            "facebook"        to "com.facebook.katana",
            "telegram"        to "org.telegram.messenger",
            "camera"          to "com.android.camera2",
            "calculator"      to "com.google.android.calculator",
            "calendar"        to "com.google.android.calendar",
            "settings"        to "com.android.settings",
            "clock"           to "com.google.android.deskclock",
            "photos"          to "com.google.android.apps.photos",
            "files"           to "com.google.android.apps.nbu.files",
            "netflix"         to "com.netflix.mediaclient",
            "tiktok"          to "com.zhiliaoapp.musically",
            "snapchat"        to "com.snapchat.android",
            "twitter"         to "com.twitter.android",
        )
    }
}
