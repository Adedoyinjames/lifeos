package PACKAGE_PLACEHOLDER

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import android.util.Log
import androidx.core.app.NotificationCompat
import java.util.Locale

/**
 * Always-on foreground service.
 *
 * Behaviour:
 *  • Holds a PARTIAL_WAKE_LOCK so the CPU stays on when the screen is off.
 *  • Runs Google SpeechRecognizer in a tight restart loop, retrying on every
 *    error so silence, Doze, or a busy recogniser never permanently stops it.
 *  • On ERROR_INSUFFICIENT_PERMISSIONS or ERROR_AUDIO (common when the screen
 *    turns off on some OEMs), backs off 4 s then retries — the phone OS will
 *    eventually grant the mic back.
 *  • START_STICKY ensures Android restarts us if we are killed.
 *  • stopWithTask=false in the manifest means closing the app task does NOT
 *    kill the service.
 *  • BootReceiver re-launches us after a reboot.
 *  • Picks the highest-quality offline TTS voice automatically for a
 *    realistic sounding response.
 */
class AssistantForegroundService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val TAG = "LifeOS/Svc"
        const val NOTIFICATION_ID = 7001
        const val CHANNEL_ID = "lifeos_assistant_bg"
        const val ACTION_START = "lifeos.START"
        const val ACTION_STOP = "lifeos.STOP"
        const val ACTION_SPEAK = "lifeos.SPEAK"
        const val ACTION_UPDATE_HOTWORD = "lifeos.HOTWORD"
        const val EXTRA_TEXT = "text"
        const val EXTRA_HOTWORD = "hotword"

        // Callbacks wired by AssistantBridgeModule so JS hears events
        @Volatile var onCommandReceived: ((String) -> Unit)? = null
        @Volatile var onHotwordDetected: ((String) -> Unit)? = null
        @Volatile var hotword: String = "james"

        fun startInContext(context: Context, hw: String = hotword) {
            hotword = hw
            val intent = Intent(context, AssistantForegroundService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_HOTWORD, hw)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopInContext(context: Context) {
            context.stopService(Intent(context, AssistantForegroundService::class.java))
        }
    }

    // ─── State ────────────────────────────────────────────────────────────────

    private val mainHandler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var isRunning = false
    private var awaitingCommand = false
    private var ttsReady = false
    private val ttsQueue = mutableListOf<String>()
    // Count consecutive STT errors so we can apply progressive back-off
    private var consecutiveErrors = 0

    // ─── Lifecycle ────────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Listening for \"${hotword.ucFirst()}\"…"))
        acquireWakeLock()
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                intent.getStringExtra(EXTRA_HOTWORD)?.also { hotword = it }
                if (!isRunning) {
                    isRunning = true
                    consecutiveErrors = 0
                    mainHandler.postDelayed({ listen() }, 800)
                }
            }
            ACTION_STOP -> { isRunning = false; stopSelf() }
            ACTION_SPEAK -> intent.getStringExtra(EXTRA_TEXT)?.let { speakNow(it) }
            ACTION_UPDATE_HOTWORD -> {
                hotword = intent.getStringExtra(EXTRA_HOTWORD) ?: hotword
                updateNotification("Listening for \"${hotword.ucFirst()}\"…")
            }
        }
        return START_STICKY   // ← OS will restart us if killed
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        // App swiped away — reschedule ourselves via AlarmManager so we come back
        // even if the OS also decides to clean up
        val pending = PendingIntent.getService(
            this, 9001,
            Intent(this, AssistantForegroundService::class.java).setAction(ACTION_START),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 2_000L, pending)
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        isRunning = false
        mainHandler.removeCallbacksAndMessages(null)
        recognizer?.destroy(); recognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
        wakeLock?.let { if (it.isHeld) it.release() }; wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ─── TTS — realistic voice ────────────────────────────────────────────────

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) {
            Log.e(TAG, "TTS init failed: $status")
            return
        }
        tts?.language = Locale.US
        selectBestVoice()
        ttsReady = true
        ttsQueue.toList().forEach { speakNow(it) }
        ttsQueue.clear()
    }

    /**
     * Picks the highest-quality English voice available offline.
     * Falls back to default if none found.  Sets rate + pitch for a natural,
     * clear sound — less robotic than the Android default.
     */
    private fun selectBestVoice() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            val voices: Set<Voice> = tts?.voices ?: emptySet()
            val best = voices
                .filter { v ->
                    !v.isNetworkConnectionRequired &&
                    (v.locale == Locale.US || v.locale.language == "en") &&
                    !v.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
                }
                .maxByOrNull { it.quality }
            if (best != null) {
                tts?.voice = best
                Log.d(TAG, "TTS voice: ${best.name} quality=${best.quality}")
            }
        }
        // Natural pacing: slightly slower than default, warmer pitch
        tts?.setSpeechRate(0.88f)
        tts?.setPitch(0.94f)
    }

    private fun speakNow(text: String) {
        if (!ttsReady) { ttsQueue.add(text); return }
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "lo_${System.currentTimeMillis()}")
    }

    // ─── Continuous STT loop ──────────────────────────────────────────────────

    private fun listen() {
        if (!isRunning) return

        // Keep CPU awake across the recogniser cycle
        if (wakeLock?.isHeld == false) acquireWakeLock()

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.w(TAG, "SpeechRecognizer not available — will retry in 10 s")
            updateNotification("Waiting for speech engine…")
            restart(10_000)
            return
        }

        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(Ear())

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            // Prefer offline recognition when available (avoids Doze network block)
            putExtra("android.speech.extra.PREFER_OFFLINE", true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 300L)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }

        try {
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            Log.e(TAG, "startListening threw: ${e.message}")
            restart(2_000)
        }
    }

    /**
     * Stop current recogniser, schedule a fresh [listen] call after [ms] ms.
     * Applies progressive back-off when consecutive errors pile up so we do
     * not hammer the system when it is refusing the microphone.
     */
    private fun restart(ms: Long = 200) {
        if (!isRunning) return
        recognizer?.destroy(); recognizer = null
        // Progressive back-off: cap at 8 s after many consecutive failures
        val delay = if (consecutiveErrors > 6) ms.coerceAtLeast(8_000) else ms
        mainHandler.postDelayed({ listen() }, delay)
    }

    // ─── Notifications ────────────────────────────────────────────────────────

    private fun createChannel() {
        val ch = NotificationChannel(
            CHANNEL_ID, "LifeOS Assistant",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Always-on voice assistant"
            setShowBadge(false)
            enableVibration(false)
            setSound(null, null)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNotification(text: String): Notification {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
            ?.apply { flags = Intent.FLAG_ACTIVITY_SINGLE_TOP }
        val pi = PendingIntent.getActivity(
            this, 0, launch,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("LifeOS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true)
            .setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java)
            .notify(NOTIFICATION_ID, buildNotification(text))
    }

    // ─── Wake lock ────────────────────────────────────────────────────────────

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LifeOS::Ear").also {
            it.setReferenceCounted(false)
            it.acquire()   // no timeout — we manage it ourselves
        }
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    private fun String.ucFirst() = replaceFirstChar { it.uppercaseChar() }

    // ─── RecognitionListener ──────────────────────────────────────────────────

    inner class Ear : RecognitionListener {

        override fun onReadyForSpeech(params: Bundle?) {
            consecutiveErrors = 0   // connection succeeded — reset error counter
            updateNotification(
                if (awaitingCommand) "Listening for your command…"
                else "Say \"${hotword.ucFirst()}\" to activate"
            )
        }

        override fun onBeginningOfSpeech() {}
        override fun onEndOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onResults(results: Bundle?) {
            val matches = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.map { it.trim().lowercase() }
                ?: run { restart(); return }

            consecutiveErrors = 0
            val best = matches.firstOrNull() ?: run { restart(); return }
            Log.d(TAG, "heard=[$best] awaiting=$awaitingCommand hw=$hotword")

            if (awaitingCommand) {
                awaitingCommand = false
                updateNotification("Processing…")
                onCommandReceived?.invoke(best)
                restart(600)
            } else {
                val hw = hotword.lowercase()
                // Accept hotword anywhere in the utterance (e.g. "hey james set alarm")
                if (matches.any { it.contains(hw) }) {
                    val afterHw = best.substringAfter(hw).trim()
                    onHotwordDetected?.invoke(hw)
                    if (afterHw.isNotEmpty()) {
                        updateNotification("Processing…")
                        onCommandReceived?.invoke(afterHw)
                        restart(600)
                    } else {
                        awaitingCommand = true
                        speakNow("Yes?")
                        restart(300)
                    }
                } else {
                    restart(100)
                }
            }
        }

        override fun onError(error: Int) {
            awaitingCommand = false
            consecutiveErrors++

            val (label, delayMs) = when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT  -> "no_match"   to 300L
                SpeechRecognizer.ERROR_CLIENT           -> "client"     to 500L
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY  -> "busy"       to 3_000L
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS,
                SpeechRecognizer.ERROR_AUDIO            -> "audio/perm" to 4_000L
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT  -> "network"    to 6_000L
                SpeechRecognizer.ERROR_SERVER           -> "server"     to 5_000L
                else                                    -> "err$error"  to 1_000L
            }

            Log.w(TAG, "STT error $label (consecutive=$consecutiveErrors)")

            // After many audio/permission errors the screen is probably off —
            // update notification so the user understands the service is alive.
            if (consecutiveErrors > 3 && (error == SpeechRecognizer.ERROR_AUDIO ||
                    error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS)) {
                updateNotification("Waiting for mic (screen-off mode)…")
            }

            restart(delayMs)
        }
    }
}
