package PACKAGE_PLACEHOLDER

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * Persistence Method 2 — AlarmManager repeating broadcast every 3 minutes.
 * Checks if the assistant service is alive; restarts it if not.
 * Also handles device boot so listening resumes after a reboot.
 */
class WatchdogReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action
        Log.d("LifeOS/Watchdog", "onReceive: $action")

        when (action) {
            Intent.ACTION_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON" -> {
                Log.d("LifeOS/Watchdog", "Boot completed — starting assistant")
                AssistantForegroundService.start(context)
            }
            else -> {
                // Repeating watchdog tick — ensure service is running
                if (!AssistantForegroundService.isRunning(context)) {
                    Log.d("LifeOS/Watchdog", "Service not running — restarting")
                    AssistantForegroundService.start(context)
                } else {
                    Log.d("LifeOS/Watchdog", "Service alive ✓")
                }
            }
        }
    }
}
