# Building LifeOS APK With GitHub Actions

This repository includes `.github/workflows/android-apk.yml`.

## No local Git required

1. Create a new empty GitHub repository.
2. Open the repository in your browser.
3. Use **Add file -> Upload files**.
4. Upload the project files and folders from this LifeOS folder. Do not upload `node_modules`.
5. Commit the upload.
6. Open the **Actions** tab.
7. Choose **Build Android APK**.
8. Click **Run workflow**.
9. When it finishes, download the `LifeOS-debug-apk` artifact.

The artifact contains `app-debug.apk`, which is installable on Android after enabling installs from unknown sources.

## Why debug APK?

The workflow builds a debug APK because it needs no private signing key. It is the easiest installable APK for testing. Later, you can add a release keystore and change the workflow to build a signed release APK.

## Requirements handled by GitHub

The workflow installs:

- Node.js 20.19.4
- Java 17
- Android SDK
- npm dependencies

Then it runs:

```bash
npm run typecheck
npx expo prebuild --platform android --clean --no-install
cd android
./gradlew assembleDebug --no-daemon
```
