import {
  createEvent,
  createPlanItem,
  finishFocusSession,
  getActiveFocusSession,
  listEvents,
  listFocusSessions,
  listPlanItems,
  startFocusSession,
} from "../db/repository";
import { getAccountabilityState } from "../services/accountabilityService";
import { buildDaySnapshot }        from "../services/timelineBuilder";
import {
  callContactOrNumber,
  evaluateMath,
  knownApps,
  listenOnce,
  navigateTo,
  openAssistantSystemSettings,
  openKnownApp,
  openWeather,
  pickFile,
  playMusic,
  readTextFileMaybe,
  searchMaps,
  searchWeb,
  sendSms,
  sendSmsToContact,
  sendWhatsApp,
  setSystemAlarm,
} from "../services/deviceActions";
import { scheduleAlarm, scheduleReminderIn } from "../services/notificationService";
import type { AssistantCommandResult, EventType } from "../types";
import { dateKey, formatDuration }               from "../utils/time";
import { assertTitle }                            from "../utils/validation";
import { analyzeDay }                             from "./offlineEngine";
import { getTodaySnapshot, llmAvailable, llmChat } from "./llmAssistant";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function cleanCommand(command: string, hotword: string): string {
  const trimmed = command.trim();
  const lower   = trimmed.toLowerCase();
  const hot     = hotword.toLowerCase();
  if (lower.startsWith(hot)) return trimmed.slice(hotword.length).replace(/^[,\s]+/, "");
  return trimmed;
}

function timeGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

function eventTypeFor(command: string): EventType {
  if (command.includes("break"))        return "break";
  if (command.includes("meeting"))      return "meeting";
  if (command.includes("distract"))     return "distraction";
  if (command.includes("switch"))       return "context_switch";
  if (command.includes("note"))         return "note";
  return "log";
}

function extractAfter(command: string, patterns: RegExp[]): string | null {
  for (const pattern of patterns) {
    const m = command.match(pattern);
    if (m?.[1]?.trim()) return m[1].trim();
  }
  return null;
}

// ─── Time parsing ─────────────────────────────────────────────────────────────

interface ParsedTime { hour: number; minute: number; }

function parseClockTime(text: string): ParsedTime | null {
  const t = text.trim().toLowerCase();

  const halfPast    = t.match(/half\s+past\s+(\d{1,2})/);
  if (halfPast)    return { hour: parseInt(halfPast[1], 10) % 24, minute: 30 };
  const quarterPast = t.match(/quarter\s+past\s+(\d{1,2})/);
  if (quarterPast) return { hour: parseInt(quarterPast[1], 10) % 24, minute: 15 };
  const quarterTo   = t.match(/quarter\s+to\s+(\d{1,2})/);
  if (quarterTo) {
    const h = parseInt(quarterTo[1], 10);
    return { hour: h === 0 ? 23 : (h - 1) % 24, minute: 45 };
  }

  const m = t.match(/^(\d{1,2})(?:[:\s](\d{2}))?\s*(am|pm)?$/);
  if (!m) return null;
  let hour   = parseInt(m[1], 10);
  const min  = m[2] ? parseInt(m[2], 10) : 0;
  const ampm = m[3];
  if (ampm === "pm" && hour < 12) hour += 12;
  if (ampm === "am" && hour === 12) hour = 0;
  if (hour < 0 || hour > 23 || min < 0 || min > 59) return null;
  return { hour, minute: min };
}

function parseRelativeMinutes(text: string): number | null {
  const t = text.toLowerCase().trim();
  const h = t.match(/(\d+)\s*hour/);  const hrs = h ? parseInt(h[1], 10) * 60 : 0;
  const m = t.match(/(\d+)\s*min/);   const min = m ? parseInt(m[1], 10) : 0;
  const s = t.match(/(\d+)\s*sec/);   const sec = s ? Math.ceil(parseInt(s[1], 10) / 60) : 0;
  const total = hrs + min + sec;
  return total > 0 ? total : null;
}

function formatAlarmTime(hour: number, minute: number): string {
  const h   = hour % 12 || 12;
  const m   = minute.toString().padStart(2, "0");
  const ampm = hour < 12 ? "AM" : "PM";
  return `${h}:${m} ${ampm}`;
}

function formatNumber(n: number): string {
  return Number.isInteger(n) ? n.toString() : parseFloat(n.toFixed(6)).toString();
}

// ─── Main command dispatcher ──────────────────────────────────────────────────

export async function runAssistantCommand(
  rawCommand: string,
  hotword:    string,
): Promise<AssistantCommandResult> {
  const command = cleanCommand(rawCommand, hotword);
  const lower   = command.toLowerCase().trim();
  const today   = dateKey();

  // ── Greeting / identity ───────────────────────────────────────────────────
  if (/^(hi|hello|hey|morning|afternoon|evening|howdy)[\s?!]*$/i.test(lower)) {
    return {
      actionType: "answer", success: true,
      spokenText: `${timeGreeting()}! I am ${hotword}. How can I help you today?`,
    };
  }

  if (/who are you|what are you|your name/i.test(lower)) {
    return {
      actionType: "answer", success: true,
      spokenText: `I am ${hotword}, your personal LifeOS assistant. I can manage your day, set alarms, send messages, navigate, search the web, and much more.`,
    };
  }

  // ── Date / time ───────────────────────────────────────────────────────────
  if (/(what|current|tell me the?)\s+(time|clock)/i.test(lower) || /^what time is it/i.test(lower)) {
    const now = new Date();
    return {
      actionType: "answer", success: true,
      spokenText: `It is ${now.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit", hour12: true })}.`,
    };
  }

  if (/(what|today'?s?|current)\s+(date|day)/i.test(lower) || /^what day is it/i.test(lower)) {
    const now = new Date();
    return {
      actionType: "answer", success: true,
      spokenText: `Today is ${now.toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}.`,
    };
  }

  // ── Calculator ────────────────────────────────────────────────────────────
  const calcMatch = command.match(
    /(?:what(?:'?s|\s+is)|calculate|compute|work out|solve)\s+(.+)/i,
  );
  if (calcMatch) {
    const result = evaluateMath(calcMatch[1]);
    if (result !== null) {
      return {
        actionType: "answer", success: true,
        spokenText: `The answer is ${formatNumber(result)}.`,
      };
    }
  }

  // Also handle bare math expressions like "15 times 7"
  const bareMath = evaluateMath(lower);
  if (
    bareMath !== null &&
    /(\d+)\s*(times|plus|minus|divided|multiplied|over|squared|cubed)\s*(\d+)/.test(lower)
  ) {
    return {
      actionType: "answer", success: true,
      spokenText: `That equals ${formatNumber(bareMath)}.`,
    };
  }

  // ── SMS ───────────────────────────────────────────────────────────────────
  // "send message/text to Ada saying/that Hey there"
  // "text Ada Hey there"
  const smsMatch = command.match(
    /(?:send\s+(?:a\s+)?(?:message|text|sms)|text)\s+(?:to\s+)?(.+?)\s+(?:saying|that|:)\s+(.+)/i,
  );
  if (smsMatch) {
    const recipient = smsMatch[1].trim();
    const body      = smsMatch[2].trim();
    const resolved  = await sendSmsToContact(recipient, body);
    return {
      actionType: "answer", success: true,
      spokenText: `Opening SMS to ${resolved} with your message.`,
    };
  }

  // ── WhatsApp ──────────────────────────────────────────────────────────────
  const waMatch = command.match(
    /(?:whatsapp|whats\s*app)\s+(?:to\s+)?(.+?)\s+(?:saying|that|:)\s+(.+)/i,
  );
  if (waMatch) {
    await sendWhatsApp(waMatch[1].trim(), waMatch[2].trim());
    return {
      actionType: "answer", success: true,
      spokenText: `Opening WhatsApp to send your message.`,
    };
  }

  // ── Navigation ────────────────────────────────────────────────────────────
  const navMatch = command.match(
    /(?:navigate|directions?|take me|drive|go)\s+(?:to\s+)?(.+)/i,
  );
  if (navMatch) {
    const dest = navMatch[1].trim();
    await navigateTo(dest);
    return {
      actionType: "answer", success: true,
      spokenText: `Opening navigation to ${dest}.`,
    };
  }

  // ── Maps search ───────────────────────────────────────────────────────────
  const mapsMatch = command.match(
    /(?:find|search|look for|where is|locate)\s+(.+?)\s+(?:on|in)\s+maps?/i,
  );
  if (mapsMatch) {
    await searchMaps(mapsMatch[1].trim());
    return {
      actionType: "answer", success: true,
      spokenText: `Searching maps for ${mapsMatch[1].trim()}.`,
    };
  }

  // Nearest X
  const nearestMatch = command.match(/nearest|closest|near me/i);
  if (nearestMatch) {
    await searchMaps(command);
    return {
      actionType: "answer", success: true,
      spokenText: `Searching maps for ${command}.`,
    };
  }

  // ── Web search ────────────────────────────────────────────────────────────
  const webMatch = command.match(
    /(?:search|google|look up|find out about|tell me about)\s+(.+)/i,
  );
  if (webMatch) {
    const query = webMatch[1].trim();
    await searchWeb(query);
    return {
      actionType: "answer", success: true,
      spokenText: `Searching for ${query}.`,
    };
  }

  // ── Weather ───────────────────────────────────────────────────────────────
  if (/(weather|temperature|forecast|rain|hot|cold|will it)/i.test(lower)) {
    const locationMatch = lower.match(/weather\s+in\s+(.+)/);
    await openWeather(locationMatch?.[1]);
    return {
      actionType: "answer", success: true,
      spokenText: locationMatch
        ? `Opening weather for ${locationMatch[1]}.`
        : "Opening today's weather forecast.",
    };
  }

  // ── What should I do / accountability coaching ────────────────────────────
  if (/(what should i|what.*next|priority|most important|what.*focus|coach)/i.test(lower)) {
    const snap  = buildDaySnapshot(
      today,
      await listPlanItems(today),
      await listEvents(today),
      await listFocusSessions(today),
    );
    const state = getAccountabilityState(snap);
    return {
      actionType: "answer", success: true,
      spokenText: state.questions[0]?.question
        ?? "Choose the smallest useful next action and start a focus session.",
    };
  }

  // ── Day summary ───────────────────────────────────────────────────────────
  if (/(summary|how did i do|report|today so far|review my day)/i.test(lower)) {
    const snap    = buildDaySnapshot(
      today,
      await listPlanItems(today),
      await listEvents(today),
      await listFocusSessions(today),
    );
    const insight = await analyzeDay(snap);
    return { actionType: "answer", success: true, spokenText: insight.summary };
  }

  // ── Alarms ────────────────────────────────────────────────────────────────
  const alarmMatch = command.match(
    /(?:set\s+(?:an?\s+)?alarm(?:\s+for)?|wake\s+me(?:\s+up)?(?:\s+at)?|alarm\s+(?:at|for))\s+(.+)/i,
  );
  if (alarmMatch) {
    const parsed = parseClockTime(alarmMatch[1].trim());
    if (parsed) {
      const label = extractAfter(command, [/(?:called|labelled|named|for)\s+["']?(.+?)["']?$/i]) ?? "Alarm";
      const { firesAt } = await scheduleAlarm(parsed.hour, parsed.minute, label);
      await setSystemAlarm(parsed.hour, parsed.minute, label);
      const tomorrow = firesAt.toDateString() !== new Date().toDateString();
      return {
        actionType: "answer", success: true,
        spokenText: `Alarm set for ${formatAlarmTime(parsed.hour, parsed.minute)}${tomorrow ? " tomorrow" : " today"}.`,
      };
    }
  }

  // ── Reminders / timers ────────────────────────────────────────────────────
  const reminderMatch = command.match(
    /(?:remind(?:\s+me)?|timer|alert\s+me|notify\s+me)\s+(?:in|after)\s+(.+)/i,
  );
  if (reminderMatch) {
    const minutes = parseRelativeMinutes(reminderMatch[1]);
    if (minutes && minutes > 0) {
      const labelMatch = command.match(/(?:to|about|for)\s+(.+?)(?:\s+in\s+|$)/i);
      const label      = labelMatch?.[1]?.trim() ?? "Reminder";
      await scheduleReminderIn(minutes, label);
      const display = minutes < 60
        ? `${minutes} minute${minutes !== 1 ? "s" : ""}`
        : formatDuration(minutes);
      return {
        actionType: "answer", success: true,
        spokenText: `Reminder set. I will notify you in ${display}.`,
      };
    }
  }

  // ── Add task ──────────────────────────────────────────────────────────────
  const taskTitle = extractAfter(command, [
    /^(?:add|create|remember|plan)\s+(?:a\s+)?(?:task|todo|commitment)\s+(?:to\s+)?(.+)$/i,
    /^remind me to\s+(.+)$/i,
    /^i need to\s+(.+)$/i,
    /^don'?t forget (?:to\s+)?(.+)$/i,
  ]);
  if (taskTitle) {
    const item = await createPlanItem({
      date:            today,
      title:           assertTitle(taskTitle),
      priority:        lower.includes("important") || lower.includes("urgent") ? "high" : "medium",
      kind:            "task",
      durationMinutes: 30,
      sortOrder:       Date.now(),
    });
    return {
      actionType: "add_task", success: true,
      spokenText: `Added "${item.title}" to today's plan.`,
    };
  }

  // ── Focus sessions ────────────────────────────────────────────────────────
  const focusTitle = extractAfter(command, [
    /^start\s+(?:a\s+)?focus\s+(?:session\s+)?(?:on\s+)?(.+)$/i,
    /^focus on\s+(.+)$/i,
    /^i'?m?\s+working on\s+(.+)$/i,
  ]);
  if (focusTitle || /^start focus$/i.test(command)) {
    const session = await startFocusSession(focusTitle ?? "Focused work", 25);
    return {
      actionType: "start_focus", success: true,
      spokenText: `Focus started for "${session.title}". I will check in with you in 25 minutes.`,
    };
  }

  if (/^(stop|end|finish|done with|complete)\s+focus/i.test(lower)) {
    const active = await getActiveFocusSession();
    if (!active) return { actionType: "stop_focus", success: false, spokenText: "No active focus session right now." };
    await finishFocusSession(active.id, true);
    return {
      actionType: "stop_focus", success: true,
      spokenText: `Focus session "${active.title}" marked complete. Well done!`,
    };
  }

  // ── Log event ─────────────────────────────────────────────────────────────
  const logText = extractAfter(command, [
    /^(?:log|record)\s+(.+)$/i,
    /^i (?:am|was)\s+(.+)$/i,
    /^i'?m\s+(.+)$/i,
    /^note\s+(.+)$/i,
    /^just finished\s+(.+)$/i,
  ]);
  if (logText) {
    const type = eventTypeFor(lower);
    await createEvent({
      type,
      title: type === "note" ? "Voice note" : logText,
      note:  type === "note" ? logText : "",
    });
    return { actionType: "log_event", success: true, spokenText: `Logged: ${logText}.` };
  }

  // ── Call ──────────────────────────────────────────────────────────────────
  const callTarget = extractAfter(command, [/^call\s+(.+)$/i, /^dial\s+(.+)$/i, /^phone\s+(.+)$/i]);
  if (callTarget) {
    const label = await callContactOrNumber(callTarget);
    return { actionType: "call", success: true, spokenText: `Calling ${label}.` };
  }

  // ── Open app ──────────────────────────────────────────────────────────────
  const appName = extractAfter(command, [/^open\s+(.+)$/i, /^launch\s+(.+)$/i, /^start\s+(.+)$/i]);
  if (appName) {
    try {
      await openKnownApp(appName);
      return { actionType: "open_app", success: true, spokenText: `Opening ${appName}.` };
    } catch {
      // fall through to LLM
    }
  }

  // ── Camera ────────────────────────────────────────────────────────────────
  if (/(take\s+(?:a\s+)?(?:picture|photo|selfie)|open\s+camera|camera)/i.test(lower)) {
    return {
      actionType: "open_camera", success: true,
      route:      "/camera",
      spokenText: "Opening the camera.",
    };
  }

  // ── Music ─────────────────────────────────────────────────────────────────
  const musicQuery = extractAfter(command, [/^play\s+(.+)$/i]);
  if (musicQuery || /^(play music|music)$/i.test(lower)) {
    await playMusic(musicQuery ?? undefined);
    return {
      actionType: "play_music", success: true,
      spokenText: musicQuery ? `Opening music for ${musicQuery}.` : "Opening music.",
    };
  }

  // ── File pick ─────────────────────────────────────────────────────────────
  if (/(find file|look for file|open file|pick file|choose file)/i.test(lower)) {
    const file = await pickFile();
    if (!file) return { actionType: "pick_file", success: false, spokenText: "No file selected." };
    const text = await readTextFileMaybe(file.uri);
    if (text) {
      await createEvent({ type: "note", title: "Imported file", note: `${file.name}\n\n${text.slice(0, 1800)}` });
      return { actionType: "pick_file", success: true, spokenText: `Imported ${file.name} and saved its contents as a note.` };
    }
    await createEvent({ type: "note", title: "Picked file", note: `${file.name}\n${file.uri}` });
    return { actionType: "pick_file", success: true, spokenText: `Noted the file ${file.name}.` };
  }

  // ── Voice / TTS settings ──────────────────────────────────────────────────
  if (/voice settings|change voice|tts settings|speech settings/i.test(lower)) {
    await openAssistantSystemSettings();
    return { actionType: "open_settings", success: true, spokenText: "Opening text-to-speech settings." };
  }

  // ── LLM free-form fallback ────────────────────────────────────────────────
  if (await llmAvailable()) {
    const snapshot = await getTodaySnapshot();
    const response = await llmChat(command, snapshot, hotword);
    if (response) return { actionType: "answer", success: true, spokenText: response };
  }

  return {
    actionType: "answer", success: true,
    detail:     knownApps().join(", "),
    spokenText: [
      `I can help with many things. Try:`,
      `"${hotword}, what time is it?"`,
      `"${hotword}, text Ada saying I'm on my way"`,
      `"${hotword}, navigate to Victoria Island"`,
      `"${hotword}, what is 25 times 8?"`,
      `"${hotword}, set alarm for 7 AM"`,
      `"${hotword}, search AI news"`,
      `"${hotword}, start focus on the report"`,
    ].join(" "),
  };
}
