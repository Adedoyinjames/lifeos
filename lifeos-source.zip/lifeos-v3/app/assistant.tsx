import { useRouter } from "expo-router";
import React, { useEffect, useState } from "react";
import {
  Alert, Pressable, StyleSheet, Switch, Text, View,
} from "react-native";
import { AppButton }    from "../src/components/AppButton";
import { Card }         from "../src/components/Card";
import { EmptyState }   from "../src/components/EmptyState";
import { Screen }       from "../src/components/Screen";
import { SectionHeader } from "../src/components/SectionHeader";
import { TextField }    from "../src/components/TextField";
import { colors, spacing } from "../src/components/theme";
import { runAssistantCommand }          from "../src/ai/assistantEngine";
import { getPreference, setPreference } from "../src/db/repository";
import { isBatteryExempt, nativeBridgeAvailable, requestBatteryExemption }
  from "../src/services/backgroundAssistant";
import { listenOnce, listVoices, speak } from "../src/services/deviceActions";
import {
  hasAssistantModel, importAssistantModel, removeAssistantModel,
} from "../src/services/llmModelService";
import { useAppContext } from "../src/data/AppContext";
import type { AssistantMessage, AssistantProfile } from "../src/types";
import { nowIso }   from "../src/utils/time";
import { createId } from "../src/utils/validation";

const HOTWORDS = ["James", "Bob", "Lizzy", "Carl", "Zappy"];

interface VoiceOption {
  identifier: string;
  name:       string;
  language?:  string;
}

function msg(role: AssistantMessage["role"], text: string): AssistantMessage {
  return { id: createId("msg"), role, text, createdAt: nowIso() };
}

export default function Assistant() {
  const router               = useRouter();
  const { backgroundActive, setBackgroundActive } = useAppContext();

  const [profile, setProfile]   = useState<AssistantProfile>({
    hotword: HOTWORDS[0], voiceIdentifier: null, speakReplies: true,
  });
  const [configured, setConfigured] = useState(false);
  const [voices,     setVoices]     = useState<VoiceOption[]>([]);
  const [modelReady, setModelReady] = useState(false);
  const [batteryOk,  setBatteryOk]  = useState(true);
  const [command,    setCommand]    = useState("");
  const [busy,       setBusy]       = useState(false);
  const [messages,   setMessages]   = useState<AssistantMessage[]>([
    msg("assistant",
      "I am ready. Say my hotword or type a command — I also listen in the background whenever the service is active."),
  ]);

  useEffect(() => {
    let mounted = true;
    async function init() {
      const [hotword, voice, speakPref, available] = await Promise.all([
        getPreference("assistantHotword",  ""),
        getPreference("assistantVoice",    ""),
        getPreference("assistantSpeak",    "true"),
        listVoices(),
      ]);
      if (!mounted) return;
      setProfile({
        hotword:         hotword || HOTWORDS[0],
        voiceIdentifier: voice   || null,
        speakReplies:    speakPref !== "false",
      });
      setConfigured(Boolean(hotword));
      setVoices(
        available
          .filter((v) => v.language?.toLowerCase().startsWith("en"))
          .slice(0, 10)
          .map((v) => ({ identifier: v.identifier, name: v.name, language: v.language })),
      );
      const [model, exempt] = await Promise.all([
        hasAssistantModel().catch(() => false),
        isBatteryExempt().catch(() => true),
      ]);
      setModelReady(model);
      setBatteryOk(exempt);
    }
    init().catch((e) => Alert.alert("Assistant setup failed", e.message));
    return () => { mounted = false; };
  }, []);

  async function saveProfile(next = profile) {
    await setPreference("assistantHotword", next.hotword);
    await setPreference("assistantVoice",   next.voiceIdentifier ?? "");
    await setPreference("assistantSpeak",   String(next.speakReplies));
    // Persist hotword for background service
    await setPreference("hotword",          next.hotword);
    if (backgroundActive) {
      const { updateBackgroundHotword } = await import("../src/services/backgroundAssistant");
      await updateBackgroundHotword(next.hotword).catch(() => {});
    }
    setConfigured(true);
  }

  async function submit(text = command) {
    const value = text.trim();
    if (!value) return;
    setBusy(true);
    setCommand("");
    setMessages((cur) => [msg("user", value), ...cur]);
    try {
      const result = await runAssistantCommand(value, profile.hotword);
      setMessages((cur) => [msg("assistant", result.spokenText), ...cur]);
      if (profile.speakReplies) await speak(result.spokenText, profile.voiceIdentifier);
      if (result.route) router.push(result.route as Parameters<typeof router.push>[0]);
    } catch (err) {
      const errText = err instanceof Error ? err.message : "I could not complete that command.";
      setMessages((cur) => [msg("assistant", errText), ...cur]);
      if (profile.speakReplies) await speak(errText, profile.voiceIdentifier);
    } finally {
      setBusy(false);
    }
  }

  async function listen() {
    try {
      setBusy(true);
      const heard = await listenOnce();
      setCommand(heard);
      await submit(heard);
    } catch (err) {
      Alert.alert("Voice command", err instanceof Error ? err.message : "I did not catch that.");
    } finally {
      setBusy(false);
    }
  }

  async function importModel() {
    try {
      setBusy(true);
      await importAssistantModel();
      setModelReady(await hasAssistantModel());
      Alert.alert("Model imported ✓", "On-device LLM is ready.");
    } catch (err) {
      Alert.alert("Import failed", err instanceof Error ? err.message : "Unknown error");
    } finally {
      setBusy(false);
    }
  }

  async function removeModel() {
    try {
      setBusy(true);
      await removeAssistantModel();
      setModelReady(false);
      Alert.alert("Model removed", "The assistant will use rule-based responses until you import a model again.");
    } catch (err) {
      Alert.alert("Removal failed", err instanceof Error ? err.message : "Unknown error");
    } finally {
      setBusy(false);
    }
  }

  async function handleBatteryExemption() {
    const exempt = await requestBatteryExemption().catch(() => false);
    setBatteryOk(exempt);
    if (!exempt) {
      Alert.alert(
        "Action needed",
        "LifeOS has opened the battery settings. Tap 'Don't optimise' or 'Unrestricted' to allow the assistant to listen in the background even when the screen is off.",
      );
    }
  }

  const EXAMPLES = [
    `${profile.hotword}, what time is it?`,
    `${profile.hotword}, text Ada saying I'm on my way`,
    `${profile.hotword}, navigate to Victoria Island`,
    `${profile.hotword}, what is 25 times 8?`,
    `${profile.hotword}, set alarm for 7 AM`,
    `${profile.hotword}, remind me in 30 minutes to drink water`,
    `${profile.hotword}, search latest AI news`,
    `${profile.hotword}, start focus on the project report`,
    `${profile.hotword}, what should I do now?`,
    `${profile.hotword}, play music`,
    `${profile.hotword}, call Mum`,
    `${profile.hotword}, log I am in a meeting`,
    `${profile.hotword}, navigate to the nearest pharmacy`,
    `${profile.hotword}, how did I do today?`,
  ];

  return (
    <Screen
      title="Assistant"
      subtitle={`${profile.hotword} is ${backgroundActive ? "active in the background" : "in-app only"}.`}
    >
      {/* ── Hotword & voice setup ── */}
      {!configured ? (
        <Card style={styles.stack}>
          <Text style={styles.title}>Choose your wake word</Text>
          <Text style={styles.body}>
            Say this word before any command — even when the screen is off.
          </Text>
          <View style={styles.pills}>
            {HOTWORDS.map((hw) => (
              <Pressable
                key={hw}
                style={[styles.pill, profile.hotword === hw && styles.pillActive]}
                onPress={() => setProfile((p) => ({ ...p, hotword: hw }))}
              >
                <Text style={[styles.pillText, profile.hotword === hw && styles.pillTextActive]}>
                  {hw}
                </Text>
              </Pressable>
            ))}
          </View>

          <Text style={styles.title}>Choose a voice</Text>
          <View style={styles.pills}>
            <Pressable
              style={[styles.pill, !profile.voiceIdentifier && styles.pillActive]}
              onPress={() => setProfile((p) => ({ ...p, voiceIdentifier: null }))}
            >
              <Text style={[styles.pillText, !profile.voiceIdentifier && styles.pillTextActive]}>
                System default
              </Text>
            </Pressable>
            {voices.map((v) => (
              <Pressable
                key={v.identifier}
                style={[styles.pill, profile.voiceIdentifier === v.identifier && styles.pillActive]}
                onPress={() => setProfile((p) => ({ ...p, voiceIdentifier: v.identifier }))}
              >
                <Text
                  style={[
                    styles.pillText,
                    profile.voiceIdentifier === v.identifier && styles.pillTextActive,
                  ]}
                >
                  {v.name}
                </Text>
              </Pressable>
            ))}
          </View>

          <View style={styles.setting}>
            <Text style={styles.body}>Speak replies aloud</Text>
            <Switch
              value={profile.speakReplies}
              onValueChange={(v) => setProfile((p) => ({ ...p, speakReplies: v }))}
            />
          </View>
          <AppButton label="Save Assistant" onPress={() => void saveProfile()} />
        </Card>
      ) : null}

      {/* ── Background service ── */}
      <SectionHeader title="Always-On Listening" />
      <Card style={styles.stack}>
        <View style={styles.setting}>
          <View style={{ flex: 1 }}>
            <Text style={styles.title}>
              {backgroundActive ? `Listening for "${profile.hotword}"` : "Background listening off"}
            </Text>
            <Text style={styles.body}>
              {backgroundActive
                ? "I hear your hotword even when the app is closed or the screen is off."
                : "Turn on to use voice commands without opening the app."}
            </Text>
          </View>
          <Switch
            value={backgroundActive}
            onValueChange={(v) => void setBackgroundActive(v)}
          />
        </View>

        {/* Battery optimisation warning — critical for screen-off listening */}
        {nativeBridgeAvailable() && !batteryOk ? (
          <View style={styles.warningBox}>
            <Text style={styles.warningText}>
              ⚠ Battery optimisation may block mic access when the screen is off.
            </Text>
            <AppButton
              label="Fix it — Disable Battery Optimisation"
              onPress={() => void handleBatteryExemption()}
            />
          </View>
        ) : null}
      </Card>

      {/* ── On-device brain ── */}
      <SectionHeader title="On-Device Brain" />
      <Card style={styles.stack}>
        <Text style={styles.title}>{modelReady ? "Local LLM ready ✓" : "No local LLM yet"}</Text>
        <Text style={styles.body}>
          Import a GGUF model for smarter free-form answers — everything runs offline, no cloud needed.
        </Text>
        <View style={styles.row}>
          <AppButton label="Import GGUF Model" onPress={() => void importModel()} disabled={busy} />
          <AppButton
            label="Remove Model"
            onPress={() => void removeModel()}
            disabled={busy || !modelReady}
            variant="secondary"
          />
        </View>
      </Card>

      {/* ── Command input ── */}
      <Card style={styles.stack}>
        <Text style={styles.title}>{profile.hotword}</Text>
        <Text style={styles.body}>
          Type or speak a command. Start with "{profile.hotword}" or just say what you need.
        </Text>
        <TextField
          label="Command"
          value={command}
          onChangeText={setCommand}
          placeholder={`${profile.hotword}, start focus on the report`}
          multiline
        />
        <View style={styles.row}>
          <AppButton
            label="Run Command"
            onPress={() => void submit()}
            disabled={busy || command.trim().length < 2}
          />
          <AppButton
            label="Listen"
            onPress={() => void listen()}
            disabled={busy}
            variant="secondary"
          />
        </View>
      </Card>

      {/* ── Command examples ── */}
      <SectionHeader title="What I Can Do" />
      <Card style={styles.stack}>
        {EXAMPLES.map((ex) => (
          <Pressable key={ex} onPress={() => setCommand(ex)}>
            <Text style={styles.example}>{ex}</Text>
          </Pressable>
        ))}
      </Card>

      {/* ── Conversation history ── */}
      <SectionHeader title="Conversation" />
      {messages.length ? (
        messages.map((item) => (
          <Card
            key={item.id}
            style={item.role === "user" ? styles.userMessage : styles.assistantMessage}
          >
            <Text style={styles.messageRole}>{item.role}</Text>
            <Text style={styles.messageText}>{item.text}</Text>
          </Card>
        ))
      ) : (
        <EmptyState
          title="No conversation yet"
          body="Run a command or say the hotword and I will reply here."
        />
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  stack:           { gap: spacing.md },
  title:           { color: colors.text, fontSize: 18, fontWeight: "900" },
  body:            { color: colors.muted, fontSize: 14, lineHeight: 21 },
  row:             { flexDirection: "row", flexWrap: "wrap", gap: spacing.sm },
  setting:         { flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: spacing.md },
  pills:           { flexDirection: "row", flexWrap: "wrap", gap: spacing.sm },
  pill:            { borderColor: colors.border, borderWidth: 1, borderRadius: 6, paddingHorizontal: spacing.md, paddingVertical: spacing.sm, backgroundColor: colors.surfaceSoft },
  pillActive:      { backgroundColor: colors.accent, borderColor: colors.accent },
  pillText:        { color: colors.text, fontWeight: "800" },
  pillTextActive:  { color: "#051018" },
  example:         { color: colors.accent, fontSize: 14, lineHeight: 22, fontWeight: "700" },
  userMessage:     { backgroundColor: colors.surfaceSoft },
  assistantMessage:{ borderColor: colors.accentStrong },
  messageRole:     { color: colors.muted, textTransform: "uppercase", fontWeight: "900", fontSize: 11, marginBottom: spacing.xs },
  messageText:     { color: colors.text, fontSize: 15, lineHeight: 22 },
  warningBox:      { backgroundColor: "#FF6B3520", borderRadius: 8, padding: spacing.md, gap: spacing.sm },
  warningText:     { color: "#FF6B35", fontSize: 13, lineHeight: 19 },
});
