package PACKAGE_PLACEHOLDER

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import androidx.core.app.NotificationCompat
import java.util.Locale

class AssistantForegroundService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val TAG = "LifeOSService"
        const val NOTIFICATION_ID = 7001
        const val CHANNEL_ID = "lifeos_assistant_bg"
        const val ACTION_START = "lifeos.START"
        const val ACTION_STOP = "lifeos.STOP"
        const val ACTION_SPEAK = "lifeos.SPEAK"
        const val ACTION_UPDATE_HOTWORD = "lifeos.HOTWORD"
        const val EXTRA_TEXT = "text"
        const val EXTRA_HOTWORD = "hotword"

        @Volatile var onCommandReceived: ((String) -> Unit)? = null
        @Volatile var onHotwordDetected: ((String) -> Unit)? = null
        @Volatile var hotword: String = "james"

        fun startInContext(context: Context, hw: String = hotword) {
            hotword = hw
            val intent = Intent(context, AssistantForegroundService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_HOTWORD, hw)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopInContext(context: Context) {
            context.stopService(Intent(context, AssistantForegroundService::class.java))
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var isRunning = false
    private var awaitingCommand = false
    private var ttsReady = false
    private val ttsQueue = mutableListOf<String>()

    // ─── Lifecycle ─────────────────────────────────────────────────────────

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, buildNote("Say \"${hotword.ucFirst()}\" to activate"))
        acquireWakeLock()
        tts = TextToSpeech(this, this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                intent.getStringExtra(EXTRA_HOTWORD)?.let { hotword = it }
                if (!isRunning) { isRunning = true; mainHandler.postDelayed({ listen() }, 600) }
            }
            ACTION_STOP -> stopSelf()
            ACTION_SPEAK -> intent.getStringExtra(EXTRA_TEXT)?.let { speakNow(it) }
            ACTION_UPDATE_HOTWORD -> {
                hotword = intent.getStringExtra(EXTRA_HOTWORD) ?: hotword
                notify("Say \"${hotword.ucFirst()}\" to activate")
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        isRunning = false
        mainHandler.removeCallbacksAndMessages(null)
        recognizer?.destroy(); recognizer = null
        tts?.stop(); tts?.shutdown(); tts = null
        wakeLock?.release(); wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    // ─── TTS ──────────────────────────────────────────────────────────────

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.language = Locale.US
            ttsReady = true
            ttsQueue.forEach { speakNow(it) }
            ttsQueue.clear()
        }
    }

    private fun speakNow(text: String) {
        if (!ttsReady) { ttsQueue.add(text); return }
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, "lo_${System.currentTimeMillis()}")
    }

    // ─── Continuous listening ─────────────────────────────────────────────

    private fun listen() {
        if (!isRunning) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            notify("Speech recognition not available on this device")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(Ear())

        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1800L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 400L)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        try {
            recognizer?.startListening(i)
        } catch (e: Exception) {
            Log.e(TAG, "startListening: ${e.message}")
            restart(2000)
        }
    }

    private fun restart(ms: Long = 300) {
        if (!isRunning) return
        recognizer?.destroy(); recognizer = null
        mainHandler.postDelayed({ listen() }, ms)
    }

    // ─── Notification ─────────────────────────────────────────────────────

    private fun createChannel() {
        val ch = NotificationChannel(CHANNEL_ID, "LifeOS Assistant", NotificationManager.IMPORTANCE_LOW)
            .apply { setShowBadge(false); enableVibration(false); setSound(null, null) }
        getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    private fun buildNote(text: String): Notification {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
            ?.apply { flags = Intent.FLAG_ACTIVITY_SINGLE_TOP }
        val pi = PendingIntent.getActivity(this, 0, launch,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("LifeOS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .setOngoing(true).setSilent(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun notify(text: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNote(text))
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "LifeOS:Ear")
            .also { it.setReferenceCounted(false); it.acquire() }
    }

    private fun String.ucFirst() = replaceFirstChar { it.uppercaseChar() }

    // ─── RecognitionListener ──────────────────────────────────────────────

    inner class Ear : RecognitionListener {
        override fun onReadyForSpeech(p: Bundle?) {
            notify(if (awaitingCommand) "Listening…" else "Say \"${hotword.ucFirst()}\"…")
        }
        override fun onBeginningOfSpeech() {}
        override fun onEndOfSpeech() {}
        override fun onRmsChanged(r: Float) {}
        override fun onBufferReceived(b: ByteArray?) {}
        override fun onPartialResults(r: Bundle?) {}
        override fun onEvent(t: Int, p: Bundle?) {}

        override fun onResults(results: Bundle?) {
            val matches = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.map { it.trim().lowercase() }
                ?: run { restart(); return }
            val best = matches.firstOrNull() ?: run { restart(); return }
            Log.d(TAG, "heard=[$best] awaiting=$awaitingCommand")

            if (awaitingCommand) {
                awaitingCommand = false
                notify("Processing…")
                onCommandReceived?.invoke(best)
                restart(800)
            } else {
                val hw = hotword.lowercase()
                if (best.contains(hw)) {
                    val afterHw = best.substringAfter(hw).trim()
                    onHotwordDetected?.invoke(hw)
                    if (afterHw.isNotEmpty()) {
                        notify("Processing…")
                        onCommandReceived?.invoke(afterHw)
                        restart(800)
                    } else {
                        awaitingCommand = true
                        speakNow("Yes?")
                        restart(400)
                    }
                } else {
                    restart(100)
                }
            }
        }

        override fun onError(error: Int) {
            awaitingCommand = false
            restart(when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 200L
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 3000L
                SpeechRecognizer.ERROR_AUDIO,
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> 2000L
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> 5000L
                else -> 1000L
            })
        }
    }
}
