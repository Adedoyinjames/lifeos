/**
 * Thin wrapper used by llmAssistant.ts to locate the active model file.
 * All download / extraction logic lives in modelDownloadService.ts.
 */
import { ASSISTANT_MODEL_URI, hasAssistantModel, removeModel } from "./modelDownloadService";

export { hasAssistantModel, removeModel as removeAssistantModel };

export function assistantModelUri(): string {
  return ASSISTANT_MODEL_URI;
}
