import AsyncStorage from "@react-native-async-storage/async-storage";
import { useRouter } from "expo-router";
import React, {
  createContext, useCallback, useContext, useEffect, useMemo, useState,
} from "react";
import { Alert } from "react-native";
import { initializeDatabase, resetDatabase } from "../db/client";
import { getPreference, setPreference }       from "../db/repository";
import { hasAssistantModel, extractBundledModel } from "../services/modelDownloadService";
import { configureNotifications }             from "../services/notificationService";
import {
  startAssistant,
  stopAssistant,
  available,
  requestBatteryExemption,
} from "../services/backgroundAssistant";

interface AppContextValue {
  ready:                  boolean;
  darkMode:               boolean;
  privacyLock:            boolean;
  backgroundActive:       boolean;
  setDarkMode:            (v: boolean) => Promise<void>;
  setPrivacyLock:         (v: boolean) => Promise<void>;
  setBackgroundActive:    (v: boolean) => Promise<void>;
  resetAllData:           () => Promise<void>;
  requestBatteryExemption: () => Promise<boolean>;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [ready,             setReady]             = useState(false);
  const [darkMode,          setDarkModeState]      = useState(true);
  const [privacyLock,       setPrivacyLockState]   = useState(false);
  const [backgroundActive,  setBackgroundActiveState] = useState(false);
  const router = useRouter();

  useEffect(() => {
    let mounted = true;

    async function startup() {
      // 1. Database
      await initializeDatabase();

      // 2. User preferences
      const [theme, lock, bgPref, hotword] = await Promise.all([
        getPreference("darkMode",            "true"),
        getPreference("privacyLock",         "false"),
        getPreference("backgroundAssistant", "true"),
        getPreference("hotword",             "james"),
      ]);
      if (!mounted) return;
      setDarkModeState(theme !== "false");
      setPrivacyLockState(lock === "true");

      // 3. Notifications
      await configureNotifications().catch(() => {});

      // 4. Model check — extractBundledModel now returns true immediately if a
      //    model is already installed, so this is safe to call every launch.
      const bundleOk   = await extractBundledModel().catch(() => false);
      const modelReady = bundleOk || (await hasAssistantModel().catch(() => false));

      if (!mounted) return;

      if (!modelReady) {
        // No model anywhere — send user to onboarding once
        setReady(true);
        router.replace("/onboarding");
        return;
      }

      // 5. Start background assistant
      if (bgPref !== "false" && available()) {
        setBackgroundActiveState(true);
        startAssistant(hotword).catch(() => {});
      }
    }

    startup()
      .catch((err) =>
        Alert.alert("LifeOS could not start", err instanceof Error ? err.message : String(err)),
      )
      .finally(() => { if (mounted) setReady(true); });

    return () => { mounted = false; };
  }, []);

  const setDarkMode = useCallback(async (v: boolean) => {
    setDarkModeState(v);
    await setPreference("darkMode", String(v));
  }, []);

  const setPrivacyLock = useCallback(async (v: boolean) => {
    setPrivacyLockState(v);
    await setPreference("privacyLock", String(v));
  }, []);

  const setBackgroundActive = useCallback(async (v: boolean) => {
    setBackgroundActiveState(v);
    await setPreference("backgroundAssistant", String(v));
    const hotword = await getPreference("hotword", "james");
    if (v) {
      await startAssistant(hotword).catch(() => {});
    } else {
      await stopAssistant().catch(() => {});
    }
  }, []);

  const handleRequestBatteryExemption = useCallback(() => requestBatteryExemption(), []);

  const resetAllData = useCallback(async () => {
    await resetDatabase();
    const keys = await AsyncStorage.getAllKeys();
    await AsyncStorage.multiRemove(keys.filter((k) => k.startsWith("lifeos:")));
    router.replace("/");
  }, [router]);

  const value = useMemo(
    () => ({
      ready,
      darkMode,
      privacyLock,
      backgroundActive,
      setDarkMode,
      setPrivacyLock,
      setBackgroundActive,
      resetAllData,
      requestBatteryExemption: handleRequestBatteryExemption,
    }),
    [
      ready, darkMode, privacyLock, backgroundActive,
      setDarkMode, setPrivacyLock, setBackgroundActive,
      resetAllData, handleRequestBatteryExemption,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useAppContext(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useAppContext must be inside AppProvider");
  return ctx;
}
