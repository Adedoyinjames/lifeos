import { NativeEventEmitter, NativeModules, Platform } from "react-native";
import { runAssistantCommand } from "../ai/assistantEngine";
import { getPreference } from "../db/repository";
import { speak } from "./deviceActions";

// ─── Native bridge typing ─────────────────────────────────────────────────────

interface AssistantBridgeType {
  startService:           (hotword: string) => Promise<boolean>;
  stopService:            ()                => Promise<boolean>;
  setHotword:             (hotword: string) => Promise<boolean>;
  speakBackground:        (text: string)    => Promise<boolean>;
  requestBatteryExemption: ()               => Promise<boolean>;
  isBatteryExempt:        ()                => Promise<boolean>;
  addListener:            (event: string)   => void;
  removeListeners:        (count: number)   => void;
}

const Bridge: AssistantBridgeType | null =
  Platform.OS === "android" &&
  NativeModules.AssistantBridge != null
    ? (NativeModules.AssistantBridge as AssistantBridgeType)
    : null;

export function nativeBridgeAvailable(): boolean {
  return Bridge !== null;
}

// ─── Event listener setup ─────────────────────────────────────────────────────

let emitter: NativeEventEmitter | null = null;
let commandSub: ReturnType<NativeEventEmitter["addListener"]> | null = null;
let hotwordSub: ReturnType<NativeEventEmitter["addListener"]> | null = null;

function ensureEmitter() {
  if (emitter || !Bridge) return;
  emitter = new NativeEventEmitter(NativeModules.AssistantBridge);
}

// ─── Background command handler ───────────────────────────────────────────────

async function handleBackgroundCommand(command: string) {
  try {
    const hotword = await getPreference("hotword", "james");
    const voiceId = await getPreference("assistantVoice", "");
    const result  = await runAssistantCommand(command, hotword);

    // Speak the response through the native TTS in the foreground service so
    // the phone speaks even when the screen is completely off.
    if (Bridge) {
      await Bridge.speakBackground(result.spokenText);
    } else {
      await speak(result.spokenText, voiceId || null);
    }
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Command failed.";
    Bridge?.speakBackground(msg).catch(() => {});
  }
}

// ─── Public API ───────────────────────────────────────────────────────────────

export async function startBackgroundAssistant(hotword: string): Promise<void> {
  if (!Bridge) return;
  ensureEmitter();

  // Attach command listener (idempotent — remove first if already attached)
  commandSub?.remove();
  hotwordSub?.remove();

  commandSub = emitter!.addListener("onBackgroundCommand", (data: { command: string }) => {
    void handleBackgroundCommand(data.command);
  });

  hotwordSub = emitter!.addListener("onHotwordDetected", (_data: { hotword: string }) => {
    // Hotword acknowledged — response handled when command arrives
  });

  await Bridge.startService(hotword);
}

export async function stopBackgroundAssistant(): Promise<void> {
  commandSub?.remove(); commandSub = null;
  hotwordSub?.remove(); hotwordSub = null;
  await Bridge?.stopService();
}

export async function updateBackgroundHotword(hotword: string): Promise<void> {
  if (!Bridge) return;
  await Bridge.setHotword(hotword);
}

/**
 * Requests the Android battery-optimisation exemption so the mic is not
 * killed when the screen turns off.  Opens the system dialog if not yet exempt.
 * Returns true if already exempt after the call.
 */
export async function requestBatteryExemption(): Promise<boolean> {
  if (!Bridge) return true;
  return Bridge.requestBatteryExemption();
}

export async function isBatteryExempt(): Promise<boolean> {
  if (!Bridge) return true;
  return Bridge.isBatteryExempt();
}
