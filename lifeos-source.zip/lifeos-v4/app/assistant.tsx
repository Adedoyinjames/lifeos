import { useFocusEffect, useRouter } from "expo-router";
import React, { useCallback, useEffect, useState } from "react";
import { Alert, PermissionsAndroid, Pressable, ScrollView, StyleSheet, Switch, Text, View } from "react-native";
import { AppButton }     from "../src/components/AppButton";
import { Card }          from "../src/components/Card";
import { Screen }        from "../src/components/Screen";
import { SectionHeader } from "../src/components/SectionHeader";
import { TextField }     from "../src/components/TextField";
import { colors, spacing } from "../src/components/theme";
import { useAppContext }  from "../src/data/AppContext";
import { getPreference, setPreference } from "../src/db/repository";
import {
  available,
  downloadVoskModel,
  isAssistantRunning,
  isVoskInstalled,
  requestAllPermissions,
  requestBatteryExemption,
  requestExactAlarm,
  requestOverlayPermission,
  speakViaService,
  startAssistant,
  stopAssistant,
  type PermissionStatus,
} from "../src/services/backgroundAssistant";
import { speak } from "../src/services/deviceActions";
import { createId } from "../src/utils/validation";
import { nowIso } from "../src/utils/time";

interface Msg { id: string; role: "user" | "bob"; text: string; }
function makeMsg(role: Msg["role"], text: string): Msg {
  return { id: createId("m"), role, text };
}

const HOTWORD = "hey bob";

export default function AssistantScreen() {
  const { backgroundActive, setBackgroundActive } = useAppContext();
  const router = useRouter();

  const [voskReady,   setVoskReady]   = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [dlProgress,  setDlProgress]  = useState(0);
  const [running,     setRunning]     = useState(false);
  const [perms,       setPerms]       = useState<PermissionStatus | null>(null);
  const [command,     setCommand]     = useState("");
  const [busy,        setBusy]        = useState(false);
  const [msgs,        setMsgs]        = useState<Msg[]>([
    makeMsg("bob", "I'm Bob. Complete setup below to enable always-on voice control."),
  ]);

  useFocusEffect(useCallback(() => {
    void refresh();
  }, []));

  async function refresh() {
    const [vosk, alive] = await Promise.all([
      isVoskInstalled(),
      isAssistantRunning(),
    ]);
    setVoskReady(vosk);
    setRunning(alive);
  }

  // ── Permission setup ───────────────────────────────────────────────────────

  async function doRequestPermissions() {
    const status = await requestAllPermissions();
    setPerms(status);
    if (!status.microphone) {
      Alert.alert(
        "Microphone Required",
        "Bob needs microphone access to hear your commands. Please grant it in Settings.",
      );
    }
  }

  const allCriticalGranted = () =>
    perms !== null && perms.microphone && perms.battery;

  // ── Vosk model download ────────────────────────────────────────────────────

  async function installVosk() {
    if (downloading) return;
    setDownloading(true);
    setDlProgress(0);
    try {
      await downloadVoskModel((pct) => setDlProgress(pct));
      setVoskReady(true);
      addMsg("bob", "Voice engine installed! Tap 'Start Listening' to activate Bob.");
    } catch (err) {
      Alert.alert("Download failed", err instanceof Error ? err.message : "Check your internet connection.");
    } finally {
      setDownloading(false);
    }
  }

  // ── Service control ────────────────────────────────────────────────────────

  async function toggleService(on: boolean) {
    if (on) {
      if (!voskReady) {
        Alert.alert("Voice Engine Missing", "Please install the voice engine first.");
        return;
      }
      if (!perms?.microphone) {
        Alert.alert("Microphone Required", "Grant microphone permission first.");
        return;
      }
      await startAssistant(HOTWORD);
      await setBackgroundActive(true);
      setRunning(true);
      addMsg("bob", "I'm listening. Say \"Hey BOB\" to activate me — even with the screen off.");
    } else {
      await stopAssistant();
      await setBackgroundActive(false);
      setRunning(false);
      addMsg("bob", "Stopped listening. Tap the switch to wake me again.");
    }
  }

  // ── In-app quick command ───────────────────────────────────────────────────

  async function runCommand() {
    const txt = command.trim();
    if (!txt) return;
    setCommand(""); setBusy(true);
    addMsg("user", txt);
    try {
      // Route through the service TTS so it uses the same voice as hotword responses
      if (available() && running) {
        await speakViaService(txt);   // service processes and speaks
      }
      // Also speak locally so user hears even if service isn't up
      await speak("Processing: " + txt, null);
    } catch (e) {
      addMsg("bob", "Command error: " + (e instanceof Error ? e.message : "unknown"));
    } finally {
      setBusy(false);
    }
  }

  function addMsg(role: Msg["role"], text: string) {
    setMsgs((m) => [makeMsg(role, text), ...m]);
  }

  const statusColour = running ? "#4CAF50" : colors.muted;
  const statusText   = running
    ? `Listening for "Hey BOB"`
    : voskReady ? "Ready to start" : "Setup required";

  return (
    <Screen
      title="Bob — Voice Assistant"
      subtitle="Always-on, works with screen off"
    >
      {/* ── Live status ── */}
      <Card style={styles.statusCard}>
        <View style={styles.statusRow}>
          <View style={[styles.dot, { backgroundColor: statusColour }]} />
          <Text style={[styles.statusText, { color: statusColour }]}>{statusText}</Text>
        </View>
        <Switch
          value={running}
          onValueChange={(v) => void toggleService(v)}
          disabled={!voskReady || !(perms?.microphone ?? true)}
        />
      </Card>

      {/* ── Step 1 — Permissions ── */}
      <SectionHeader title="Step 1 — Grant Permissions" />
      <Card style={styles.stack}>
        <Text style={styles.body}>
          Bob needs microphone, battery exemption, and overlay permissions to work when the screen is off.
        </Text>

        <AppButton label="Grant All Permissions" onPress={() => void doRequestPermissions()} />

        {perms && (
          <View style={styles.permGrid}>
            {[
              ["🎙", "Microphone",    perms.microphone],
              ["🔔", "Notifications", perms.notifications],
              ["🔋", "Battery Exempt",perms.battery],
              ["🪟", "Overlay",       perms.overlay],
              ["📞", "Phone Calls",   perms.phone],
              ["💬", "SMS",           perms.sms],
              ["👤", "Contacts",      perms.contacts],
            ].map(([icon, label, granted]) => (
              <View key={String(label)} style={styles.permRow}>
                <Text style={styles.permIcon}>{icon}</Text>
                <Text style={styles.permLabel}>{String(label)}</Text>
                <Text style={{ color: granted ? "#4CAF50" : "#FF6B35", fontWeight: "900" }}>
                  {granted ? "✓" : "✗"}
                </Text>
              </View>
            ))}
          </View>
        )}

        {/* Special permissions that need Settings Intent */}
        <View style={styles.row}>
          <AppButton
            label="Battery Exemption"
            onPress={() => void requestBatteryExemption().then(() => void refresh())}
            variant="secondary"
          />
          <AppButton
            label="Overlay Permission"
            onPress={() => void requestOverlayPermission().then(() => void refresh())}
            variant="secondary"
          />
        </View>
        <AppButton
          label="Exact Alarm Permission"
          onPress={() => void requestExactAlarm()}
          variant="secondary"
        />
      </Card>

      {/* ── Step 2 — Voice Engine ── */}
      <SectionHeader title="Step 2 — Install Voice Engine (40 MB)" />
      <Card style={styles.stack}>
        {voskReady ? (
          <Text style={styles.ready}>✓ Vosk offline voice engine installed</Text>
        ) : (
          <>
            <Text style={styles.body}>
              Downloads the Vosk offline speech engine (~40 MB). This is the app's own STT — no Google,
              no internet needed for recognition.
            </Text>
            {downloading ? (
              <>
                <View style={styles.progressBg}>
                  <View style={[styles.progressFg, { width: `${dlProgress}%` as any }]} />
                </View>
                <Text style={styles.body}>{dlProgress}% — please wait…</Text>
              </>
            ) : (
              <AppButton label="Download Voice Engine" onPress={() => void installVosk()} />
            )}
          </>
        )}
      </Card>

      {/* ── Step 3 — Start Bob ── */}
      <SectionHeader title="Step 3 — Activate Bob" />
      <Card style={styles.stack}>
        <Text style={styles.title}>Hey BOB</Text>
        <Text style={styles.body}>
          Once active, say "Hey BOB" anywhere — app closed, screen off, phone locked.
          Bob uses his own voice engine so he doesn't rely on Android or Google.
        </Text>
        <AppButton
          label={running ? "Stop Listening" : "Start Listening"}
          onPress={() => void toggleService(!running)}
          disabled={!voskReady}
        />
      </Card>

      {/* ── Try a command ── */}
      {running && (
        <>
          <SectionHeader title="Try a Command" />
          <Card style={styles.stack}>
            <TextField
              label="Type a command"
              value={command}
              onChangeText={setCommand}
              placeholder="what time is it"
              multiline={false}
            />
            <AppButton
              label="Run"
              onPress={() => void runCommand()}
              disabled={busy || command.trim().length < 2}
            />
          </Card>
        </>
      )}

      {/* ── What Bob can do ── */}
      <SectionHeader title="What Bob Can Do" />
      <Card style={styles.stack}>
        {[
          "Hey BOB, what time is it?",
          "Hey BOB, what day is it today?",
          "Hey BOB, set alarm for 7 AM",
          "Hey BOB, remind me in 30 minutes to drink water",
          "Hey BOB, add task finish the project report",
          "Hey BOB, what are my tasks?",
          "Hey BOB, what is 25 times 8?",
          "Hey BOB, navigate to Victoria Island",
          "Hey BOB, text Ada saying I'm on my way",
          "Hey BOB, call Mum",
          "Hey BOB, search latest tech news",
          "Hey BOB, open Spotify",
          "Hey BOB, play music",
          "Hey BOB, what's the weather?",
          "Hey BOB, motivate me",
          "Hey BOB, good morning",
        ].map((ex) => (
          <Pressable key={ex} onPress={() => setCommand(ex.replace("Hey BOB, ", ""))}>
            <Text style={styles.example}>{ex}</Text>
          </Pressable>
        ))}
      </Card>

      {/* ── Conversation log ── */}
      <SectionHeader title="Recent Responses" />
      {msgs.map((m) => (
        <Card key={m.id} style={m.role === "user" ? styles.userCard : styles.bobCard}>
          <Text style={styles.roleLabel}>{m.role === "user" ? "You" : "Bob"}</Text>
          <Text style={styles.msgText}>{m.text}</Text>
        </Card>
      ))}
    </Screen>
  );
}

const styles = StyleSheet.create({
  stack:       { gap: spacing.md },
  statusCard:  { flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: spacing.md },
  statusRow:   { flexDirection: "row", alignItems: "center", gap: spacing.sm, flex: 1 },
  dot:         { width: 10, height: 10, borderRadius: 5 },
  statusText:  { fontSize: 15, fontWeight: "900" },
  title:       { color: colors.text, fontSize: 20, fontWeight: "900" },
  body:        { color: colors.muted, fontSize: 14, lineHeight: 21 },
  ready:       { color: "#4CAF50", fontWeight: "900", fontSize: 15 },
  row:         { flexDirection: "row", flexWrap: "wrap", gap: spacing.sm },
  permGrid:    { gap: 6 },
  permRow:     { flexDirection: "row", alignItems: "center", gap: spacing.sm, paddingVertical: 2 },
  permIcon:    { fontSize: 16, width: 24 },
  permLabel:   { flex: 1, color: colors.text, fontSize: 13 },
  progressBg:  { height: 8, backgroundColor: colors.surfaceSoft, borderRadius: 4, overflow: "hidden" },
  progressFg:  { height: 8, backgroundColor: colors.accent, borderRadius: 4 },
  example:     { color: colors.accent, fontSize: 13, lineHeight: 22, fontWeight: "700" },
  userCard:    { backgroundColor: colors.surfaceSoft },
  bobCard:     { borderColor: colors.accentStrong },
  roleLabel:   { color: colors.muted, fontSize: 11, fontWeight: "900", textTransform: "uppercase", marginBottom: 4 },
  msgText:     { color: colors.text, fontSize: 14, lineHeight: 21 },
});
