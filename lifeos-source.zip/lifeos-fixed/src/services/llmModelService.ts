import * as DocumentPicker from "expo-document-picker";
import * as FileSystem from "expo-file-system/legacy";

const MODEL_DIR = `${FileSystem.documentDirectory}models/`;
const ASSISTANT_MODEL_URI = `${MODEL_DIR}assistant.gguf`;

// This is the path to the model bundled inside the Android APK assets.
// The GitHub Actions workflow downloads the model and copies it to
// android/app/src/main/assets/models/assistant.gguf after expo prebuild.
// FileSystem.bundleDirectory resolves to "asset:///" on Android.
const BUNDLED_MODEL_ASSET = `${FileSystem.bundleDirectory ?? "asset:///"}models/assistant.gguf`;

export function assistantModelUri(): string {
  return ASSISTANT_MODEL_URI;
}

export async function ensureModelDir(): Promise<void> {
  const info = await FileSystem.getInfoAsync(MODEL_DIR);
  if (!info.exists) {
    await FileSystem.makeDirectoryAsync(MODEL_DIR, { intermediates: true });
  }
}

export async function hasAssistantModel(): Promise<boolean> {
  const info = await FileSystem.getInfoAsync(ASSISTANT_MODEL_URI);
  return Boolean(info.exists && info.size && info.size > 1024 * 1024);
}

/**
 * Called at app startup. If the model is not yet in the writable documentDirectory
 * but IS bundled inside the APK assets, it copies it over automatically.
 * This is a one-time operation (~100 MB copy) that makes the LLM available
 * immediately after install without any manual file import.
 */
export async function initBundledModel(): Promise<void> {
  try {
    // Already extracted previously — nothing to do.
    if (await hasAssistantModel()) return;
    await ensureModelDir();
    // Check if the bundled asset exists (it does when the workflow bundled it).
    const bundledInfo = await FileSystem.getInfoAsync(BUNDLED_MODEL_ASSET);
    if (!bundledInfo.exists) return; // No bundled model, user must import manually.
    // Copy from APK assets → writable storage so llama.rn can load it.
    await FileSystem.copyAsync({ from: BUNDLED_MODEL_ASSET, to: ASSISTANT_MODEL_URI });
  } catch {
    // Non-fatal: the app works without the LLM; user can import manually.
  }
}

/**
 * Let the user pick their own GGUF model from device storage.
 * This is the fallback for sideloaded models or larger alternatives.
 */
export async function importAssistantModel(): Promise<void> {
  await ensureModelDir();
  const result = await DocumentPicker.getDocumentAsync({
    copyToCacheDirectory: true,
    multiple: false,
    type: "*/*",
  });
  if (result.canceled) return;
  const uri = result.assets[0]?.uri;
  const name = (result.assets[0]?.name ?? "").toLowerCase();
  if (!uri) throw new Error("No model file selected.");
  if (!name.endsWith(".gguf")) throw new Error("Select a GGUF model file ending in .gguf");
  await FileSystem.copyAsync({ from: uri, to: ASSISTANT_MODEL_URI });
}

export async function removeAssistantModel(): Promise<void> {
  const info = await FileSystem.getInfoAsync(ASSISTANT_MODEL_URI);
  if (info.exists) {
    await FileSystem.deleteAsync(ASSISTANT_MODEL_URI, { idempotent: true });
  }
}
