package PACKAGE_PLACEHOLDER

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.util.Log
import com.facebook.react.bridge.*
import com.facebook.react.modules.core.DeviceEventManagerModule

class AssistantBridgeModule(ctx: ReactApplicationContext)
    : ReactContextBaseJavaModule(ctx) {

    override fun getName() = "AssistantBridge"

    init {
        // Wire Kotlin callbacks → JS events so the UI updates when commands fire
        AssistantForegroundService.onCommand = { command ->
            emit("onBackgroundCommand",
                Arguments.createMap().apply { putString("command", command) })
        }
        AssistantForegroundService.onHotword = {
            emit("onHotwordDetected", Arguments.createMap())
        }
    }

    // ── Service control ───────────────────────────────────────────────────────

    @ReactMethod fun startService(hotword: String, promise: Promise) {
        try {
            val prefs = reactApplicationContext
                .getSharedPreferences(AssistantForegroundService.PREFS, Context.MODE_PRIVATE)
            prefs.edit().putString(AssistantForegroundService.KEY_HOTWORD, hotword).apply()
            AssistantForegroundService.start(reactApplicationContext)
            AssistantWatchdogJob.schedule(reactApplicationContext)
            promise.resolve(true)
        } catch (e: Exception) { promise.reject("ERR_START", e.message) }
    }

    @ReactMethod fun stopService(promise: Promise) {
        try { AssistantForegroundService.stop(reactApplicationContext); promise.resolve(true) }
        catch (e: Exception) { promise.reject("ERR_STOP", e.message) }
    }

    @ReactMethod fun isServiceRunning(promise: Promise) {
        promise.resolve(AssistantForegroundService.isRunning(reactApplicationContext))
    }

    @ReactMethod fun speakBackground(text: String, promise: Promise) {
        try {
            reactApplicationContext.startService(
                Intent(reactApplicationContext, AssistantForegroundService::class.java)
                    .setAction(AssistantForegroundService.ACTION_SPEAK)
                    .putExtra("text", text))
            promise.resolve(true)
        } catch (e: Exception) { promise.reject("ERR_TTS", e.message) }
    }

    // ── Vosk model path ───────────────────────────────────────────────────────

    @ReactMethod fun setVoskModelPath(path: String, promise: Promise) {
        try {
            reactApplicationContext
                .getSharedPreferences(AssistantForegroundService.PREFS, Context.MODE_PRIVATE)
                .edit().putString(AssistantForegroundService.KEY_VOSK, path).apply()
            promise.resolve(true)
        } catch (e: Exception) { promise.reject("ERR_VOSK", e.message) }
    }

    @ReactMethod fun getVoskModelPath(promise: Promise) {
        val path = reactApplicationContext
            .getSharedPreferences(AssistantForegroundService.PREFS, Context.MODE_PRIVATE)
            .getString(AssistantForegroundService.KEY_VOSK, null)
        promise.resolve(path)
    }

    // ── Battery optimisation exemption ────────────────────────────────────────

    @ReactMethod fun requestBatteryExemption(promise: Promise) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val pm = reactApplicationContext
                    .getSystemService(Context.POWER_SERVICE) as PowerManager
                if (!pm.isIgnoringBatteryOptimizations(reactApplicationContext.packageName)) {
                    reactApplicationContext.startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            Uri.parse("package:${reactApplicationContext.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    promise.resolve(false)
                } else promise.resolve(true)
            } else promise.resolve(true)
        } catch (e: Exception) { promise.reject("ERR_BATTERY", e.message) }
    }

    @ReactMethod fun isBatteryExempt(promise: Promise) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = reactApplicationContext
                .getSystemService(Context.POWER_SERVICE) as PowerManager
            promise.resolve(pm.isIgnoringBatteryOptimizations(reactApplicationContext.packageName))
        } else promise.resolve(true)
    }

    // ── Overlay (display over other apps) permission ──────────────────────────

    @ReactMethod fun requestOverlayPermission(promise: Promise) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                !Settings.canDrawOverlays(reactApplicationContext)) {
                reactApplicationContext.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${reactApplicationContext.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                promise.resolve(false)
            } else promise.resolve(true)
        } catch (e: Exception) { promise.reject("ERR_OVERLAY", e.message) }
    }

    @ReactMethod fun hasOverlayPermission(promise: Promise) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            promise.resolve(Settings.canDrawOverlays(reactApplicationContext))
        else promise.resolve(true)
    }

    // ── Exact alarm permission (Android 12+) ──────────────────────────────────

    @ReactMethod fun requestExactAlarmPermission(promise: Promise) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                reactApplicationContext.startActivity(
                    Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                promise.resolve(false)
            } else promise.resolve(true)
        } catch (e: Exception) { promise.reject("ERR_ALARM", e.message) }
    }

    // ── React Native boilerplate ──────────────────────────────────────────────

    @ReactMethod fun addListener(eventName: String) {}
    @ReactMethod fun removeListeners(count: Int) {}

    private fun emit(event: String, data: com.facebook.react.bridge.WritableMap) {
        try {
            reactApplicationContext
                .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                .emit(event, data)
        } catch (e: Exception) { Log.e("AssistantBridge", "emit $event: ${e.message}") }
    }
}
