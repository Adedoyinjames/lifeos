# LifeOS

LifeOS is an offline-first Expo/React Native Android app for planning the day, tracking actual time minute by minute, reconstructing a timeline, and generating local execution insights.

## Privacy and offline behavior

- No backend server.
- No cloud database.
- No runtime API calls.
- SQLite stores plans, events, focus sessions, and backups on the device.
- AsyncStorage stores lightweight preferences.
- The offline AI layer uses deterministic rules by default and exposes a small `LocalInferenceAdapter` interface for optional on-device inference. No model is bundled, so the app stays small and does not require a 300 MB download.

## Accountability features

- Fast daily capture turns one line per commitment into today's plan.
- Planned start-time reminders ask whether you are doing what you said you would do.
- Check-in nudges ask what you are doing during the day.
- End-of-day review nudges ask what finished, what slipped, and tomorrow's first move.
- The Today screen shows an Accountability Coach question based on due, overdue, and untracked commitments.
- Reports include an accountability score that rewards task completion and honest check-ins while penalizing untracked time.

## Setup

Use Node.js 20.19.4 or newer. Expo SDK 55 and React Native 0.83 require Node 20.19.4+, so Node 18 will print engine warnings and may fail during install or builds.

```bash
npm install
npx expo start
```

For Android development builds:

```bash
npx expo run:android
```

## Typecheck

```bash
npm run typecheck
```

## Build an installable APK

Install and authenticate EAS CLI, then run:

```bash
npm run build:android:apk
```

The `apk` profile in `eas.json` produces an internal distribution APK. The `production` profile produces an Android App Bundle.

## Build with GitHub Actions

This project includes `.github/workflows/android-apk.yml`, which can build an installable debug APK on GitHub. See `GITHUB_BUILD.md`.

If you do not have Git installed locally, use the generated upload pack from the parent folder:

- `/home/spot/coding/lifeos-upload-pack`
- `/home/spot/coding/lifeos-upload-pack.zip`

The upload pack contains fewer than 10 files/items and includes a workflow that builds from `lifeos-source.zip`.

## Project structure

- `app/` contains Expo Router screens.
- `src/db/` contains SQLite schema, connection, and repositories.
- `src/services/` contains timeline reconstruction, scoring, notifications, and backup import/export.
- `src/ai/` contains the local offline reasoning engine and deterministic fallback.
- `src/components/` contains reusable UI primitives.

## Optional local AI adapter

The app intentionally ships without a bundled model. To add a small local model later, implement `LocalInferenceAdapter` in `src/ai/offlineEngine.ts` and call `registerLocalInferenceAdapter(adapter)` during startup. Keep the adapter optional so deterministic insights continue to work on every device.
