# Building APKs With GitHub Actions

This repository includes two APK workflows:

- `.github/workflows/android-apk.yml` builds the LifeOS Expo assistant app as a signed release APK.
- `.github/workflows/truth-android-apk.yml` builds the native Truth accessibility app.

Use the LifeOS workflow for the personal assistant APK.

## No local Git required

1. Create a new empty GitHub repository.
2. Open the repository in your browser.
3. Use **Add file -> Upload files**.
4. Upload the project files and folders from this LifeOS folder. Do not upload `node_modules`.
5. Commit the upload.
6. Open the **Actions** tab.
7. Choose **Build Android APK**.
8. Click **Run workflow**.
9. When it finishes, download the `LifeOS-release-apk` artifact.

The artifact contains `app-release.apk`, which is installable on Android after enabling installs from unknown sources.

## Release signing

The LifeOS workflow generates a release signing key inside GitHub Actions and signs the APK during the build. This is enough for installing the APK on your phone. For long-term app updates, replace the generated key with a stable private keystore stored in GitHub Secrets so every release is signed with the same key.

## Requirements handled by GitHub

The LifeOS workflow installs:

- Node.js 20.19.4
- Java 17
- Android SDK

Then it runs:

```bash
npm install
npm run typecheck
npx expo prebuild --platform android --clean --no-install
cd android
./gradlew assembleRelease --no-daemon
```

## Truth phone setup

After installing the APK:

1. Open the `Truth` app.
2. Tap `Open Accessibility Settings`.
3. Enable `Truth Policy Detector`.
4. Open Chrome on a signup page that contains `Privacy Policy` or `Terms of Service`.
5. Tap the floating `Truth` button when it appears.

The app sends the policy URL or visible policy text to:

```text
https://adedoyinjames-truth.hf.space/v1/summarize
```
