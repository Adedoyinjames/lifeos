import { useRouter } from "expo-router";
import React, { useEffect, useState } from "react";
import { Alert, Pressable, StyleSheet, Switch, Text, View } from "react-native";
import { AppButton } from "../src/components/AppButton";
import { Card } from "../src/components/Card";
import { EmptyState } from "../src/components/EmptyState";
import { Screen } from "../src/components/Screen";
import { SectionHeader } from "../src/components/SectionHeader";
import { TextField } from "../src/components/TextField";
import { colors, spacing } from "../src/components/theme";
import { runAssistantCommand } from "../src/ai/assistantEngine";
import { getPreference, setPreference } from "../src/db/repository";
import { listenOnce, listVoices, speak } from "../src/services/deviceActions";
import { hasAssistantModel, importAssistantModel, removeAssistantModel } from "../src/services/llmModelService";
import type { AssistantMessage, AssistantProfile } from "../src/types";
import { nowIso } from "../src/utils/time";
import { createId } from "../src/utils/validation";

const HOTWORDS = ["James", "Bob", "Lizzy", "Carl", "Zappy"];

interface VoiceOption {
  identifier: string;
  name: string;
  language?: string;
}

function message(role: AssistantMessage["role"], text: string): AssistantMessage {
  return { id: createId("msg"), role, text, createdAt: nowIso() };
}

export default function Assistant() {
  const router = useRouter();
  const [profile, setProfile] = useState<AssistantProfile>({
    hotword: HOTWORDS[0],
    voiceIdentifier: null,
    speakReplies: true,
  });
  const [configured, setConfigured] = useState(false);
  const [voices, setVoices] = useState<VoiceOption[]>([]);
  const [modelReady, setModelReady] = useState(false);
  const [command, setCommand] = useState("");
  const [busy, setBusy] = useState(false);
  const [messages, setMessages] = useState<AssistantMessage[]>([
    message("assistant", "I am ready. Ask me what to do next, tell me what to remember, or ask me to open an app."),
  ]);

  useEffect(() => {
    let mounted = true;
    Promise.all([getPreference("assistantHotword", ""), getPreference("assistantVoice", ""), getPreference("assistantSpeak", "true"), listVoices()])
      .then(([hotword, voice, speakReplies, available]) => {
        if (!mounted) return;
        setProfile({ hotword: hotword || HOTWORDS[0], voiceIdentifier: voice || null, speakReplies: speakReplies !== "false" });
        setConfigured(Boolean(hotword));
        setVoices(
          available
            .filter((item) => item.language?.toLowerCase().startsWith("en"))
            .slice(0, 8)
            .map((item) => ({ identifier: item.identifier, name: item.name, language: item.language })),
        );
      })
      .catch((error) => Alert.alert("Assistant setup failed", error instanceof Error ? error.message : "Unknown error"));
    hasAssistantModel().then(setModelReady).catch(() => setModelReady(false));
    return () => {
      mounted = false;
    };
  }, []);

  async function saveProfile(next = profile) {
    await setPreference("assistantHotword", next.hotword);
    await setPreference("assistantVoice", next.voiceIdentifier ?? "");
    await setPreference("assistantSpeak", String(next.speakReplies));
    setConfigured(true);
  }

  async function submit(text = command) {
    const value = text.trim();
    if (!value) return;
    setBusy(true);
    setCommand("");
    setMessages((current) => [message("user", value), ...current]);
    try {
      const result = await runAssistantCommand(value, profile.hotword);
      setMessages((current) => [message("assistant", result.spokenText), ...current]);
      if (profile.speakReplies) await speak(result.spokenText, profile.voiceIdentifier);
      if (result.route) router.push(result.route as any);
    } catch (error) {
      const textError = error instanceof Error ? error.message : "I could not complete that command.";
      setMessages((current) => [message("assistant", textError), ...current]);
      if (profile.speakReplies) await speak(textError, profile.voiceIdentifier);
    } finally {
      setBusy(false);
    }
  }

  async function listen() {
    try {
      setBusy(true);
      const heard = await listenOnce();
      setCommand(heard);
      await submit(heard);
    } catch (error) {
      Alert.alert("Voice command", error instanceof Error ? error.message : "I did not catch that.");
    } finally {
      setBusy(false);
    }
  }

  async function importModel() {
    try {
      setBusy(true);
      await importAssistantModel();
      setModelReady(await hasAssistantModel());
      Alert.alert("Model imported", "On-device LLM is ready.");
    } catch (error) {
      Alert.alert("Model import failed", error instanceof Error ? error.message : "Unknown error");
    } finally {
      setBusy(false);
    }
  }

  async function removeModel() {
    try {
      setBusy(true);
      await removeAssistantModel();
      setModelReady(false);
      Alert.alert("Model removed", "The assistant will use lightweight rules until you import a model again.");
    } catch (error) {
      Alert.alert("Model removal failed", error instanceof Error ? error.message : "Unknown error");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Screen title="Assistant" subtitle="A time-conscious command center for planning, focus, check-ins, calls, apps, and music.">
      {!configured ? (
        <Card style={styles.stack}>
          <Text style={styles.title}>Choose how to wake me</Text>
          <Text style={styles.body}>Inside the app, press Listen and say your hotword before a command, or type the command directly.</Text>
          <View style={styles.pills}>
            {HOTWORDS.map((hotword) => (
              <Pressable key={hotword} onPress={() => setProfile((current) => ({ ...current, hotword }))} style={[styles.pill, profile.hotword === hotword && styles.pillActive]}>
                <Text style={[styles.pillText, profile.hotword === hotword && styles.pillTextActive]}>{hotword}</Text>
              </Pressable>
            ))}
          </View>
          <Text style={styles.title}>Choose a voice</Text>
          <View style={styles.pills}>
            <Pressable onPress={() => setProfile((current) => ({ ...current, voiceIdentifier: null }))} style={[styles.pill, !profile.voiceIdentifier && styles.pillActive]}>
              <Text style={[styles.pillText, !profile.voiceIdentifier && styles.pillTextActive]}>System default</Text>
            </Pressable>
            {voices.map((voice) => (
              <Pressable key={voice.identifier} onPress={() => setProfile((current) => ({ ...current, voiceIdentifier: voice.identifier }))} style={[styles.pill, profile.voiceIdentifier === voice.identifier && styles.pillActive]}>
                <Text style={[styles.pillText, profile.voiceIdentifier === voice.identifier && styles.pillTextActive]}>{voice.name}</Text>
              </Pressable>
            ))}
          </View>
          <View style={styles.setting}>
            <Text style={styles.body}>Speak replies aloud</Text>
            <Switch value={profile.speakReplies} onValueChange={(value) => setProfile((current) => ({ ...current, speakReplies: value }))} />
          </View>
          <AppButton label="Save Assistant" onPress={() => void saveProfile()} />
        </Card>
      ) : null}

      <SectionHeader title="On-Device Brain" />
      <Card style={styles.stack}>
        <Text style={styles.title}>{modelReady ? "Local LLM ready" : "No local LLM yet"}</Text>
        <Text style={styles.body}>
          Import a GGUF model to enable smarter free-form conversation offline. A small, safe default is SmolLM2-135M-Instruct Q4_K_M (~105MB).
        </Text>
        <View style={styles.row}>
          <AppButton label="Import GGUF Model" onPress={() => void importModel()} disabled={busy} />
          <AppButton label="Remove Model" onPress={() => void removeModel()} disabled={busy || !modelReady} variant="secondary" />
        </View>
      </Card>

      <Card style={styles.stack}>
        <Text style={styles.title}>{profile.hotword}</Text>
        <Text style={styles.body}>Try: “{profile.hotword}, what should I do now?” or “{profile.hotword}, add task call Ada”.</Text>
        <TextField label="Command" value={command} onChangeText={setCommand} placeholder={`${profile.hotword}, start focus on studying`} multiline />
        <View style={styles.row}>
          <AppButton label="Run Command" onPress={() => void submit()} disabled={busy || command.trim().length < 2} />
          <AppButton label="Listen" onPress={() => void listen()} disabled={busy} variant="secondary" />
        </View>
      </Card>

      <SectionHeader title="Command Examples" />
      <Card style={styles.stack}>
        {[
          `${profile.hotword}, what should I do now?`,
          `${profile.hotword}, add task review my notes`,
          `${profile.hotword}, start focus on writing`,
          `${profile.hotword}, log I am in a meeting`,
          `${profile.hotword}, call 08012345678`,
          `${profile.hotword}, open YouTube`,
          `${profile.hotword}, play music`,
          `${profile.hotword}, how did I do today?`,
        ].map((example) => (
          <Pressable key={example} onPress={() => setCommand(example)}>
            <Text style={styles.example}>{example}</Text>
          </Pressable>
        ))}
      </Card>

      <SectionHeader title="Conversation" />
      {messages.length ? (
        messages.map((item) => (
          <Card key={item.id} style={item.role === "user" ? styles.userMessage : styles.assistantMessage}>
            <Text style={styles.messageRole}>{item.role}</Text>
            <Text style={styles.messageText}>{item.text}</Text>
          </Card>
        ))
      ) : (
        <EmptyState title="No conversation yet" body="Run a command and I will answer here." />
      )}
    </Screen>
  );
}

const styles = StyleSheet.create({
  stack: {
    gap: spacing.md,
  },
  title: {
    color: colors.text,
    fontSize: 18,
    fontWeight: "900",
  },
  body: {
    color: colors.muted,
    fontSize: 14,
    lineHeight: 21,
  },
  row: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: spacing.sm,
  },
  setting: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: spacing.md,
  },
  pills: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: spacing.sm,
  },
  pill: {
    borderColor: colors.border,
    borderWidth: 1,
    borderRadius: 6,
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
    backgroundColor: colors.surfaceSoft,
  },
  pillActive: {
    backgroundColor: colors.accent,
    borderColor: colors.accent,
  },
  pillText: {
    color: colors.text,
    fontWeight: "800",
  },
  pillTextActive: {
    color: "#051018",
  },
  example: {
    color: colors.accent,
    fontSize: 15,
    lineHeight: 22,
    fontWeight: "800",
  },
  userMessage: {
    backgroundColor: colors.surfaceSoft,
  },
  assistantMessage: {
    borderColor: colors.accentStrong,
  },
  messageRole: {
    color: colors.muted,
    textTransform: "uppercase",
    fontWeight: "900",
    fontSize: 11,
    marginBottom: spacing.xs,
  },
  messageText: {
    color: colors.text,
    fontSize: 15,
    lineHeight: 22,
  },
});
