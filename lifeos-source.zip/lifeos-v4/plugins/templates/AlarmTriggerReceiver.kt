package PACKAGE_PLACEHOLDER

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat

/**
 * Fired by AlarmManager when an alarm or reminder goes off.
 * Shows a heads-up notification with sound — works even when screen is off.
 */
class AlarmTriggerReceiver : BroadcastReceiver() {

    companion object { const val CHANNEL_ID = "lifeos_alarms" }

    override fun onReceive(context: Context, intent: Intent?) {
        val label = intent?.getStringExtra("label") ?: "LifeOS"
        val type  = intent?.getStringExtra("type")  ?: "alarm"

        val nm  = context.getSystemService(NotificationManager::class.java)
        val uri = RingtoneManager.getDefaultUri(
            if (type == "reminder") RingtoneManager.TYPE_NOTIFICATION
            else                    RingtoneManager.TYPE_ALARM
        )

        val ch = NotificationChannel(
            CHANNEL_ID, "Alarms & Reminders",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            setSound(uri, AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM).build())
            enableVibration(true)
        }
        nm.createNotificationChannel(ch)

        val notif = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(if (type == "reminder") "⏰ Reminder" else "⏰ Alarm")
            .setContentText(label)
            .setSound(uri)
            .setVibrate(longArrayOf(0, 400, 200, 400))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .build()

        nm.notify(System.currentTimeMillis().toInt(), notif)

        // Also speak through Bob if service is running
        val speak = Intent(context, AssistantForegroundService::class.java)
            .setAction(AssistantForegroundService.ACTION_SPEAK)
            .putExtra("text", "$label. $label.")
        context.startService(speak)
    }
}
